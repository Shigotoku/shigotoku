# ちょこっとワークス「音声入力（文字起こし）」引き継ぎ資料

> 目的: ちょこっとワークスの音声入力のしくみを、社内の他システムにも載せるために、
> 開発を担当するAI／エンジニアへ渡す資料です。
> 同じフォルダの `ソース/` に、関係するソースをそのままコピーしてあります（読むための複製。元は下記パス）。

- 元のリポジトリ: `meditoku-works-main`
  - アプリ本体: `chokotto-works/voice-dictation`（Electron / TypeScript、v0.1.105 時点）
  - 共通の音声部品: `packages/speech-common`（`@meditoku/speech-common`）
- この資料は、実際のコードを読んで書いています。推測は「※推測」と書きました。

---

## 1. 一言でいうと

**ブラウザ（Chrome / Edge）に内蔵された音声認識（Web Speech API）の「端末内（オンデバイス）モード」で文字にして、
そのあとに、日本語・医療向けの整形を自前のコードで行い、入力先に流し込む**、という3段構えです。
音声認識エンジンそのものは自作していません（クラウドの文字起こしAPIも使っていません）。

```
 マイク
   │
   ▼
┌───────────────────────────────┐
│ ① 認識層  speech-common            │  Web Speech API（Chrome/Edge のオンデバイス日本語）
│    startLiveSpeech()               │  途中結果(interim) と 確定結果(final) が出てくる
└───────────────┬───────────────┘
                ▼
┌───────────────────────────────┐
│ ② 整形層  textPostprocess ほか     │  空白除去・言いよどみ除去・句読点・医療用語・数値・音声コマンド
│    （純粋な関数が中心）             │  ← ここが一番の資産。Web でも使い回せる
└───────────────┬───────────────┘
                ▼
┌───────────────────────────────┐
│ ③ 入力層  typer.ts / paste.ts      │  Windows のデスクトップ専用
│    他アプリのカーソル位置へ入力      │  ＝ Web システムには不要（入力欄に直接入れればよい）
└───────────────────────────────┘
```

**他システムへ載せるときに使い回せるのは ①②。③はデスクトップアプリ専用**です。

---

## 2. 載せる先ごとの進め方（まずここを決める）

| 載せる先 | 使うもの | 難しさ |
|---|---|---|
| **A. Web システム（React など）の入力欄に音声ボタンを付ける** | `@meditoku/speech-common`（`VoiceInputButton` / `startLiveSpeech`）。**すでに社内の複数システムで使用中** | 低 |
| **B. A に加えて、医療用語・数値・句読点の整形も同じ品質にしたい** | A ＋ `textPostprocess.ts` と `shared/*` の関数群（②）を取り込む | 中 |
| **C. Windows のデスクトップアプリから、他アプリへ音声入力したい** | ちょこっとワークスと同じ構成（③＋Chrome ウィンドウとの橋渡し）。または**ちょこっとワークス自体を併用** | 高 |

### すでに `@meditoku/speech-common` を使っている社内システム（参考にできる実装）

`gairai-works/medical-checkup/web`（`ExamVoiceMemoModal.tsx` ほか）、`gairai-works/reception-list/web`
（`VisitMemoModal.tsx` など）、`gairai-works/online-booking/patient`、`gairai-works/reportalk/client`、
`innai-works/back-office`、`commercial/lead-management`。

---

## 3. ① 認識層（`speech-common/src/speechRecognition.ts`）

### 3.1 基本のしくみ
- ブラウザの `SpeechRecognition` / `webkitSpeechRecognition` を使う。`lang = 'ja-JP'`、`continuous = true`、`interimResults = true`。
- `startLiveSpeech(options)` が入口。`onInterim`（話している途中）と `onFinal`（確定）が返る。
- **プライバシーモードが2種類**（診療でのいちばん大事な設計）:
  - `clinical` … **端末内認識だけ**。日本語の音声パックが入っていない／使えないときも、**クラウドへ切り替えず、エラーにして導入を案内する**。患者さんの会話はPCの外へ出ない。
  - `general` … 端末内が使えればそれを使い、無ければクラウド認識でもよい（受付メモなど）。
- ちょこっとワークスの音声入力は、**常に `clinical`**（`speech.ts` の `privacyMode: 'clinical'`）。

### 3.2 実際に困った点と、入っている対策（引き継ぎで特に大事）
1. **Chrome は continuous でも認識を短く切る** → `onend` で、ユーザーが止めるまで **80ms後に自動で再開**する。
2. **日本語の音声パック**（オンデバイス）は、初回にダウンロードが必要 → `ensureOnDeviceSpeechReady()` が
   `SpeechRecognition.available()` → 必要なら `install()` を呼ぶ。状態は `available / downloadable / downloading / unavailable / unsupported`。
3. **Chrome 155 以降は `quality` を指定すると `unavailable` になる環境がある** → `quality: 'default'`（＝指定しない）にして、
   指定ありで `unavailable` だったら指定なしで再確認する。
4. **医学用語を優先して聞き取らせる**（`localPhrases` → `SpeechRecognitionPhrase(用語, boost=3)`）。未対応のChromeでは `phrases-not-supported` を受けて自動で外す。
5. **認識候補（n-best）から選ぶ**（`scoreAlternative`）: 最大5候補を取り、**1位より医学用語の一致が +1 以上多い候補**があればそちらを採用（僅差なら1位のまま）。
6. **マイクの事前確保**（`audioTrack`）: マイクを開きっぱなしにしておき、`rec.start(track)` に渡して「話し始めの取りこぼし」を減らす（設定でオン／オフ。未対応ブラウザは通常開始に切替）。
7. **マイク許可の確認**（`ensureMicrophonePermission`）: Permissions API で許可済みなら `getUserMedia` を呼ばない（ダイアログを減らす）。iOS の「ホーム画面アプリ」では Web Speech が必ず失敗するため、最初から「キーボードの音声入力」案内にする（`detectSpeechSupport`）。
8. エラー文言は `speechErrorMessage(code)` に集約（日本語）。

### 3.3 語彙（`vocabulary/`）
`general / soap / checkup / gi` の4種。確定文に対する**医療用語の読み仮名補正**（`medicalTermPostProcess.ts`）の辞書。
ちょこっとワークスは `vocabulary: 'soap'`。

### 3.4 React 用の部品
`VoiceInputButton.tsx`: `value / onChange` を渡すだけで、入力欄に音声入力できるボタン。
`multiline`（確定文ごとに改行）、`punctuate`（無音で「、」・停止時に「。」）、`privacyMode`、`vocabulary` を指定できる。
日本語の連結は `speechTextFormat.ts`（`appendJapaneseSpeechSegment` など）。

---

## 4. ② 整形層（ここが一番の資産）

### 4.1 1発話ごとの整形（`textPostprocess.ts` の `cleanSegment`）
実行順（内側から外側）:

1. `removeJapaneseSpaces` … **日本語の文字間の空白を除去**（端末内認識は単語ごとに空白を返すため）。英数字どうしの空白は残す。
2. `applySpokenPunctuation` … 「句点」「読点」「改行」、読み上げ括弧を記号に。
3. `applyUserDictionary` … ユーザー辞書（誤り→正）。**医療用語補正より優先**。
4. `applyMedicalReadings` … 医療用語の読み仮名→表記（4文字以上の読みだけ。誤爆防止）＋ かな連続の漢字化（`kanaSegment`）＋ 薬剤名・病名の補正（`drugMatch` / `diseaseMatch`）。
5. `applyMedicalNumbers`（`medicalFormat.ts`） … 血圧「130の80」→`130/80`、体温「36度5分」→`36.5℃`、単位（ミリグラム→mg など）。**数字の直後のときだけ**変換。
6. `removeFillers` … 「えっと」「あのー」等の除去。
7. `insertInnerPunctuation` … 長く続けて話して1結果になったときの、文の途中の句点・疑問符。

### 4.2 文をつなぐ・仕上げる
- `joinSegment(base, seg)` … 前の文が文末表現なら「。」「？」、そうでなければ「、」でつなぐ。
- `finalizeText(text)` … **文末表現がはっきりしているときだけ**句点を付ける。判断できなければ付けない（名前・単語だけの入力など）。
- `rephraseText`（`shared/rephrase.ts`） … 言い直し「火曜日、いや水曜日」→「水曜日」。**医療モードでは、数値・左右は「違う」「訂正」など明示的な訂正語のときだけ**置き換える（「50mg、いや100mg」を取り違えると危険なので、両方残して本人に見せる）。

### 4.3 音声コマンド（発話全体がコマンドのときだけ働く。文の一部なら普通の文章）
- 編集（`shared/voiceCommands.ts`）: 「いまの取り消し」「全部消して」「3文字消して」「入力終了」
- 書式（`shared/formatCommands.ts`）: 箇条書き・番号リスト（「次」で次の項目）・段落・言い直し（「○○を△△に訂正」）
- 見出しテンプレート: 「SOAP」→ `S)` `O)` `A)` `P)`、「内視鏡モード」→ `部位：` `病変：` `処置：` `診断：`。**モードの間だけ**見出し名が有効（普段の「評価」で誤爆しない）。
- 日付・時刻の挿入: 「今日の日付」（令和表記）
- 定型文の呼び出し: 「定型 ○○」（スニペット機能と連携。一致しなければ普通の文章として入力）

### 4.4 設定（アプリ本体 → 認識ウィンドウへ渡す）
`PostprocessConfig`（`textPostprocess.ts`）:
`dictionary`（ユーザー辞書）/ `specialty`（診療科）/ `medicalTerms`（医療用語補正のオン・オフ）/ `snippetNames` / `warmMic` / `terms`（専門用語フォルダ）。
音声入力の開始ごとに最新を取得する（`speech.ts` の `refreshConfig`）。

### 4.5 診療科パック・辞書
`shared/specialties.ts`（診療科別の読み→表記）、`shared/medicalDict.ts`、`shared/clinicTerms.ts`、
`shared/drugNames.ts`（薬剤名・約90KB）、`shared/diseaseNames.ts`（病名・**約1.5MB、スクリプトで生成したデータ**。`scripts/fetch-disease-names.mjs`）。
**Web に取り込むときは、バンドルサイズに注意**（病名辞書は遅延読み込みなどを検討）。

---

## 5. 認識ウィンドウ（`renderer/speech.ts`）— 状態管理の中心

話している間の状態は次の3つ:
- `buffer` … 確定済みの文章。
- `interim` … 話している途中の文。
- `tailRaw` … 末尾が「定型文／見出し」のとき true（その直後の発話に句読点を足さない）。

流れ:
1. `onInterim(raw)` → `cleanSegment` → コマンドなら画面に出さない／文章なら `interim` に。`broadcastOverlay()` で「確定＋途中」を全文プレビューとして送る。
2. `onFinal(raw)` → 編集コマンド → 書式コマンド → 見出し → 日付挿入 → 定型文 → それ以外は `buffer = finalizeText(appendSeg(buffer, seg))`。
3. 終了（Enter／ショートカット／音声「入力終了」／10分無音）→ `stopEngine()` で最後の途中結果も含めて確定 → `sendCommit(text)`。

そのほかの設計:
- **自動終了はしない**（長文で考えながら話しても切れない）。ただし**10分無音なら安全のため終了**（Enter キーを奪ったままにしない）。
- **間（ポーズ）の自動句読点**（設定 `pausePunct`、既定オフ）: 1.0秒空いたら「、」、さらに空いて6文字以上なら「。」に変える。
- **マイク診断**（`runMicCheck`）: 静かな2秒＋話す5秒の音量・雑音・クリップ率を測り、結果を本体へ。判定は `shared/micCheck.ts`。
- 訂正の**自動学習**: 声で言い直した語（`sendLearn`）のうち、正が確かな医学用語なら、辞書へ自動追加（`index.ts` の `isSafeLearnPair`）。

---

## 6. なぜ「別の Chrome ウィンドウ」で認識しているか（デスクトップ版のしくみ）

- **Electron 内蔵のブラウザは、日本語のオンデバイス音声パックを導入できない**ため、認識エンジン本体は
  **Chrome（なければ Edge）の「アプリウィンドウ」**で動かしている（`main/bridge.ts` の `findEdgeOrChrome` / `openSpeechPage`）。
  Chrome を優先する理由: 日本語オンデバイス認識は Chrome が対応（Edge は未対応の版がある）。
- 専用プロファイル（`--user-data-dir`、拡張機能なし）で起動 → マイク許可・日本語音声パックがそのプロファイルに保存される。
- 本体との通信は **`127.0.0.1` のローカルHTTP**（`SpeechBridge`、ポートは 47821 から空いている所）:
  - 認証: 起動ごとのランダムな `token`（`?t=`）。違うと403。
  - `GET /api/events` … **SSE**（本体→認識ウィンドウ。`speech:start / stop / flush / check-ready / mic-check`）。新しいページが接続したら古いページに `replaced` を送って閉じさせる。
  - `POST /api/send` … 認識ウィンドウ→本体（`speech:status / preview / commit / error / learn / ready-result / mic-*`）。
  - `GET /api/config` … 辞書・診療科などの設定を取得。 `GET /api/snippet?name=` … 「定型 ○○」用に展開済みの定型文を取得。
  - チャネル名の一覧は `shared/ipc.ts` の `SPEECH_*`。
- 認識ウィンドウは準備完了後、**PowerShell（user32）で画面外（-32000,-32000）へ移し、タスクバー・Alt+Tab から消す**（閉じてはいない＝認識は動き続ける）。起動時から画面外で開く（一瞬見えるのを防ぐ）。
- **「古い認識ウィンドウが残って古いポートを見に行く」問題** → 前回が正常終了でなかった／更新直後は、起動前に専用プロファイルの Chrome をすべて終了させる（`closeEngineBrowsers`）。

> **Web システムに載せる場合、この橋渡しは不要**です。ページ自体がブラウザなので、`startLiveSpeech` をそのページで呼べば済みます（A / B）。

---

## 7. ③ 入力層（デスクトップ専用 — Web では不要）

- **ライブ入力**（`main/typer.ts`）: 常駐 PowerShell が `SendInput`（Unicode）で、**話しながらカーソル位置へキー入力**する。クリップボードを使わない。
  途中結果が書き換わったら、**共通する先頭までバックスペースで戻して打ち直す（差分入力）**。
- **誤入力を防ぐ安全策**:
  - 入力先ウィンドウを開始時に固定。**別のウィンドウに変わったら入力を止める**（入力済みの文字は残す）。
  - **マウスクリック・矢印キー等を検知**したら、書き直し（バックスペース）をやめて「続きを打つだけ」にする（誤削除の防止）。
- **貼り付け方式**（`main/paste.ts`）: ライブ入力が使えないアプリ（例: Qt製の LINE など。1文字ずつだと文字化け・無反応）は、話すのを止めたら文ごとに貼り付ける。入力先アプリごとに方式を切り替える。
- **確認モード**: 入力前に確認画面で直してから入れる（設定／アプリごとの規則）。
- **入力直前のAI校正（任意）**: PC内のAIが直前の入力を文脈つきで見て医学用語を直す。**3秒で間に合わなければ校正せずそのまま入力**。
- 本体側の制御は `main/index.ts`（`startListening` / `commitText` / `registerBridgeHandlers`）。

---

## 8. 設計上の大事な判断・落とし穴（再発防止）

1. **患者さんの会話は院外に出さない**: `clinical` モードはクラウドへ絶対に切り替えない。「端末内が使えない」はエラーとして案内する。
2. **医療の数値は慎重に**: 左右・薬の量の言い直しは、明示的な訂正語のときだけ置き換える。血圧・体温・単位は「数字の直後」「範囲内」のときだけ変換（「屈曲40度」は体温にしない）。
3. **句点は確信があるときだけ**: 迷ったら付けない。
4. **コマンドは発話全体が一致したときだけ**: 文章の一部は普通の入力にする（誤爆防止）。
5. **ユーザー辞書は医療用語補正より先**: 施設ごとの言い換えを優先する。
6. **読み仮名補正は4文字以上**: 短い日常語を壊さない。
7. **Chrome のバージョン差**で挙動が変わる（`quality` 指定、`phrases`）。変更時は実機（Chrome最新版）で確認する。
8. **入力先を固定し、変わったら止める**（デスクトップ版）。
9. 院内のネットワークルール: ここの音声機能自体は外部通信しないが、**認証APIを呼ぶ処理を足すときは、リポジトリの `.cursor/rules/rate-limit-clinic-nat.mdc`（院内NATのレート制限）に従う**。
10. データ互換: 辞書ファイル（ユーザー辞書／スニペット）の形式は既存ユーザーのデータなので、**読み書きの形式を変えない**（`.cursor/rules/data-compatibility.mdc`）。

---

## 9. 他システムへ載せる手順（チェックリスト）

### A. Web システムに音声入力を付ける
1. `@meditoku/speech-common` を依存に追加（`"@meditoku/speech-common": "file:../../packages/speech-common"` のようにリポジトリ内パスで。既存の `medical-checkup/web` の `package.json`・`vite.config.ts` を参考にする）。
2. 入力欄の横に `<VoiceInputButton value={...} onChange={...} privacyMode="clinical" vocabulary="soap" />` を置く。
3. 患者情報を含む入力は **`privacyMode="clinical"`**（端末内のみ）。受付メモなど個人情報が無い場合だけ `general`。
4. 利用者の PC は **Chrome（推奨）か Edge の最新版**。初回に日本語音声パックのダウンロードとマイク許可が必要（`ensureOnDeviceSpeechReady` / `ensureMicrophonePermission` で案内を出す）。
5. iPhone/iPad のホーム画面アプリでは使えない（`detectSpeechSupport()` が `keyboard-dictation` を返すので、キーボードのマイク案内に切り替える）。

### B. 整形も同じ品質にする
1. `ソース/chokotto-works/src/renderer/textPostprocess.ts` と、そこから `import` している `src/shared/*` を、**そのまま**取り込む（DOM に依存しない純粋関数が中心。`speech.ts` のような画面操作は含まれない）。
2. 認識の `onFinal` の中で `cleanSegment(raw)` → `joinSegment` → `finalizeText` を通す（`speech.ts` の `onFinal` を参考）。
3. 起動時に `setPostprocessConfig({ dictionary, specialty, medicalTerms, terms, snippetNames })` を呼ぶ。辞書・診療科の保存先は、載せる先のシステムに合わせて用意する。
4. `getMedicalPhraseHints()` と `medicalScore` を `startLiveSpeech` の `localPhrases` / `scoreAlternative` に渡すと、医学用語の聞き取り精度が上がる。
5. 病名辞書（`diseaseNames.ts` 約1.5MB）は重いので、必要なら遅延読み込みにする。
6. 取り込み後、`ソース/chokotto-works/scripts/voice.test.mjs` と `format.test.mjs` の考え方でテストを作る（下記 §11）。

### C. デスクトップアプリで他アプリへ入力したい
- 新しく作るより、**ちょこっとワークスを併用**するのが最短（`Ctrl+Shift+Space` でどのアプリへも入力できる）。
- 自前で作る場合は §6・§7 の構成を踏襲する。

---

## 10. フォルダの中身（`ソース/`）

| パス | 役割 |
|---|---|
| `speech-common/src/speechRecognition.ts` | **認識層の本体**（Web Speech API ラッパー）。web でも使う |
| `speech-common/src/VoiceInputButton.tsx` | React の音声ボタン |
| `speech-common/src/speechTextFormat.ts` / `medicalTermPostProcess.ts` / `vocabulary/*` | 日本語連結・語彙別の医療用語補正 |
| `chokotto-works/src/renderer/speech.ts` | **認識ウィンドウ**（状態管理・コマンド・設定取得・マイク診断） |
| `chokotto-works/src/renderer/textPostprocess.ts` | **整形の入口**（`cleanSegment` ほか） |
| `chokotto-works/src/shared/` | 整形の部品（`voiceCommands` / `formatCommands` / `rephrase` / `medicalFormat` / `punctInfer` / `kanaSegment` / `drugMatch` / `diseaseMatch` / `medicalDict` / `clinicTerms` / `specialties` / `corrections` / `micCheck` / `ipc` ほか） |
| `chokotto-works/src/main/bridge.ts` | Chrome ウィンドウとの橋渡し（ローカルHTTP/SSE） |
| `chokotto-works/src/main/typer.ts` / `paste.ts` | 入力層（ライブ入力・貼り付け）。デスクトップ専用 |
| `chokotto-works/src/main/index.ts` | アプリ本体（参考。音声関連は `startListening` / `commitText` / `registerBridgeHandlers` / `bridge.setConfigProvider`）。**巨大なので全部は読まなくてよい** |
| `chokotto-works/index.html` / `engine.css` | 認識ウィンドウのページ |
| `chokotto-works/DOCS.md` | 機能の詳しい仕様書（ライブ入力・整形・コマンド・スニペット等） |
| `chokotto-works/scripts/*.test.mjs` | 整形・コマンド・差分入力のテスト |
| `chokotto-works/package.json` ほか設定 | ビルド・依存の確認用 |
| `_files.txt` | コピーしたファイルの一覧 |

※ `diseaseNames.ts`（1.5MB）と `drugNames.ts` は生成データです。読むのは不要で、型と使い方は `diseaseMatch.ts` / `drugMatch.ts` を見れば足ります。

---

## 11. 動作確認・テスト

- ちょこっとワークス側: `npm test`（`voice.test.mjs` が数値整形・音声コマンド・訂正の学習・マイク判定、`format.test.mjs` が書式コマンド、`typerMove.test.mjs` が差分入力、`voiceStyle.test.mjs`）。**整形ロジックを変えたら必ず実行**。
- テストは `tsc` でビルドした `dist/shared/*.js` を読み込む作り（`createRequire(...)('../dist/shared/medicalFormat.js')`）。
- 整形ロジックを変えるときは、`textPostprocess.ts` の関数単位で入出力を確認する（`DOCS.md` の注意書きどおり）。
- 実機確認（自動テストでは確認できない）: Chrome 最新版での日本語パックの導入、マイク許可、長文を続けて話したときの句点、医学用語の聞き取り。

---

## 12. 前提・制約まとめ

- ブラウザ: **Chrome 推奨 / Edge**（オンデバイス日本語認識に対応した版）。Firefox・Safari は不可（iOS は別案内）。
- 初回にマイク許可＋日本語音声パックのダウンロード（ネット接続が必要）。以降は端末内で完結。
- ③ライブ入力・貼り付けは **Windows 専用**（PowerShell と user32 を使用）。
- 音声コマンド・整形は日本語向け（`ja-JP` 固定）。他言語は未対応。
- 診療科パック・辞書は、現状は `shared/` の静的データ＋施設ごとのユーザー辞書（`%APPDATA%\chokotto-voice-dictation\`）。院内共有（LAN）で辞書をそろえる機能もある（`index.ts` の `refreshShared`）。

---

## 13. AI への依頼文（そのまま貼って使えます）

```
添付の「ちょこっとワークス_音声入力_引き継ぎ資料」フォルダを読んでください（まず README.md）。
ちょこっとワークスの音声入力（文字起こし）のしくみを、次のシステムにも載せたいです。

載せたいシステム: （ここにシステム名と、音声を入れたい画面・入力欄を書く）
使う端末: （例: 院内のWindows PC の Chrome / スマホ など）
扱う情報: （患者さんの個人情報を含む ／ 含まない）

お願い:
1. README の §2 に沿って、A（音声ボタンだけ）/ B（整形も同じ品質）のどちらが合うか判断してください。
2. 患者情報を扱う場合は privacyMode="clinical"（端末内のみ・クラウドへ切り替えない）にしてください。
3. 整形ロジックを取り込む場合は、ソース/ の該当ファイルをそのまま使い、書き換えず、
   変更が必要なときは理由を説明してください。
4. 完了条件: 日本語音声パックの導入案内・マイク許可・端末内認識で入力できること、
   voice.test.mjs 相当のテストが通ること。
```
