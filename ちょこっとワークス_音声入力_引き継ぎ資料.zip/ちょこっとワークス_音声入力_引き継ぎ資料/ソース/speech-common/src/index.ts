export {
  detectSpeechSupport,
  isIosDevice,
  isStandaloneDisplay,
  supportsOnDeviceSpeech,
  getOnDeviceSpeechStatus,
  ensureOnDeviceSpeechReady,
  ensureMicrophonePermission,
  speechErrorMessage,
  startLiveSpeech,
  composeWithInterim,
  type SpeechSupport,
  type SpeechPrivacyMode,
  type OnDeviceSpeechStatus,
  type LiveSpeechOptions,
} from './speechRecognition';

export { VoiceInputButton, type VoiceInputButtonProps } from './VoiceInputButton';

export {
  applyMedicalTermCorrections,
  buildSpeechPhraseHints,
  applySpeechPhraseHints,
  type SpeechPhraseHint,
} from './medicalTermPostProcess';

export {
  normalizeSpeechSegment,
  appendJapaneseSpeechSegment,
  finalizeJapaneseSpeechText,
  composeJapaneseInterim,
} from './speechTextFormat';

export { getVocabulary, type SpeechVocabulary, type VocabularyDefinition } from './vocabulary';
