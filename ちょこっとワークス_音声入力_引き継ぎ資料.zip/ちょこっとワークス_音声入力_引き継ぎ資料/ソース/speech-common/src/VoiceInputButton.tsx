import { useCallback, useEffect, useRef, useState } from 'react';
import {
  composeWithInterim,
  detectSpeechSupport,
  speechErrorMessage,
  startLiveSpeech,
  type SpeechPrivacyMode,
  type SpeechSupport,
} from './speechRecognition';
import {
  appendJapaneseSpeechSegment,
  composeJapaneseInterim,
  finalizeJapaneseSpeechText,
  normalizeSpeechSegment,
} from './speechTextFormat';
import type { SpeechVocabulary } from './vocabulary';

export interface VoiceInputButtonProps {
  value: string;
  onChange: (next: string) => void;
  /** 確定文の区切りに改行を入れる（複数行 textarea 向け） */
  multiline?: boolean;
  /** multiline=false 時、無音区切りで「、」を入れ停止時に「。」で終える */
  punctuate?: boolean;
  /** clinical = ローカルのみ（診察会話） / general = クラウド STT 優先 */
  privacyMode?: SpeechPrivacyMode;
  /** 医療用語バイアス・確定文後処理 */
  vocabulary?: SpeechVocabulary;
  disabled?: boolean;
  className?: string;
  activeClassName?: string;
  label?: string;
  activeLabel?: string;
}

export function VoiceInputButton({
  value,
  onChange,
  multiline = true,
  punctuate = false,
  privacyMode = 'general',
  vocabulary = 'general',
  disabled = false,
  className = '',
  activeClassName = 'voice-input-btn--active',
  label = '🎤 音声',
  activeLabel = '⏹ 停止',
}: VoiceInputButtonProps) {
  const [support] = useState<SpeechSupport>(() => detectSpeechSupport());
  const [listening, setListening] = useState(false);
  const [preparing, setPreparing] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [isLocal, setIsLocal] = useState(false);
  const baseRef = useRef('');
  const stopRef = useRef<(() => void) | null>(null);
  const wantListeningRef = useRef(false);

  const stopListening = useCallback(() => {
    wantListeningRef.current = false;
    stopRef.current?.();
    stopRef.current = null;

    if (punctuate && baseRef.current) {
      const finalized = finalizeJapaneseSpeechText(baseRef.current);
      baseRef.current = finalized;
      onChange(finalized);
    }

    setListening(false);
    setPreparing(false);
    setIsLocal(false);
  }, [onChange, punctuate]);

  useEffect(() => () => stopListening(), [stopListening]);

  const beginListening = useCallback(async () => {
    setStatus(null);
    baseRef.current = value.trimEnd();
    const joinNl = multiline;
    wantListeningRef.current = true;

    setPreparing(true);
    try {
      const handle = await startLiveSpeech({
        privacyMode,
        vocabulary,
        onPreparing: (msg) => setStatus(msg),
        onInterim: (t) => {
          const next = punctuate
            ? composeJapaneseInterim(baseRef.current, t)
            : composeWithInterim(baseRef.current, normalizeSpeechSegment(t), joinNl);
          onChange(next);
        },
        onFinal: (t) => {
          const next = punctuate
            ? appendJapaneseSpeechSegment(baseRef.current, t)
            : joinNl && baseRef.current
              ? `${baseRef.current}\n${normalizeSpeechSegment(t)}`
              : baseRef.current
                ? `${baseRef.current}${normalizeSpeechSegment(t)}`
                : normalizeSpeechSegment(t);
          baseRef.current = next;
          onChange(next);
        },
        onError: (code) => {
          if (!wantListeningRef.current) return;
          setStatus(speechErrorMessage(code));
          stopListening();
        },
        onEnd: () => {
          stopRef.current = null;
          if (wantListeningRef.current) {
            setStatus((prev) => prev || '音声入力が終了しました。もう一度「音声」を押してください');
          }
          wantListeningRef.current = false;
          setListening(false);
          setPreparing(false);
        },
      });

      if (!wantListeningRef.current) {
        setPreparing(false);
        return;
      }

      setPreparing(false);

      if (!handle) {
        setStatus((prev) =>
          prev && !prev.includes('確認中') && prev !== '準備中…'
            ? prev
            : '音声認識を開始できませんでした'
        );
        wantListeningRef.current = false;
        setListening(false);
        return;
      }

      setStatus(null);
      stopRef.current = handle.stop;
      setIsLocal(handle.local);
      setListening(true);
    } catch {
      wantListeningRef.current = false;
      setPreparing(false);
      setListening(false);
      setStatus('音声認識を開始できませんでした');
    }
  }, [multiline, onChange, privacyMode, punctuate, stopListening, value, vocabulary]);

  const toggle = useCallback(() => {
    if (disabled || preparing) return;

    if (listening) {
      stopListening();
      return;
    }

    if (support !== 'web-speech') {
      setStatus(
        support === 'keyboard-dictation'
          ? 'キーボードのマイクボタンで話してください'
          : 'このブラウザでは音声入力に対応していません'
      );
      return;
    }

    void beginListening();
  }, [beginListening, disabled, listening, preparing, stopListening, support]);

  if (support === 'keyboard-dictation') {
    return (
      <span className="voice-input-hint" style={{ fontSize: '0.75rem', color: '#6b7280' }}>
        キーボードの🎤で入力
      </span>
    );
  }

  if (support === 'audio-only') {
    return null;
  }

  const buttonLabel = preparing ? '準備中…' : listening ? activeLabel : label;
  const listeningHint = listening
    ? isLocal
      ? '端末内で聞き取り中…'
      : '聞き取り中… 話しかけてください'
    : '';

  return (
    <span
      className="voice-input-wrap"
      style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '4px' }}
    >
      <button
        type="button"
        className={`voice-input-btn ${listening ? activeClassName : ''} ${className}`.trim()}
        onClick={toggle}
        disabled={disabled || preparing}
        aria-pressed={listening}
        title={
          listening
            ? isLocal
              ? '端末内音声認識中（停止）'
              : '音声入力を停止'
            : privacyMode === 'clinical'
              ? '端末内音声入力'
              : '音声入力'
        }
        style={{
          padding: '4px 10px',
          fontSize: '0.8rem',
          border: '1px solid #d1d5db',
          borderRadius: '6px',
          background: listening ? (isLocal ? '#dcfce7' : '#fef3c7') : '#fff',
          cursor: disabled || preparing ? 'not-allowed' : 'pointer',
        }}
      >
        {listening && isLocal ? '🔒 ' : ''}
        {buttonLabel}
      </button>
      {listeningHint && !status && (
        <span style={{ fontSize: '0.75rem', color: '#059669' }}>{listeningHint}</span>
      )}
      {status && (
        <span
          style={{
            fontSize: '0.75rem',
            color: '#dc2626',
            maxWidth: '100%',
            textAlign: 'right',
            lineHeight: 1.4,
          }}
          role="alert"
        >
          {status}
        </span>
      )}
    </span>
  );
}
