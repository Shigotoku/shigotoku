import { CHECKUP_VOCABULARY } from './checkup';
import { GENERAL_VOCABULARY } from './general';
import { GI_VOCABULARY } from './gi';
import { SOAP_VOCABULARY } from './soap';
import type { SpeechVocabulary, VocabularyDefinition } from './types';

export type { SpeechVocabulary, VocabularyDefinition } from './types';

const VOCABULARIES: Record<SpeechVocabulary, VocabularyDefinition> = {
  general: GENERAL_VOCABULARY,
  soap: SOAP_VOCABULARY,
  checkup: CHECKUP_VOCABULARY,
  gi: GI_VOCABULARY,
};

export function getVocabulary(id: SpeechVocabulary): VocabularyDefinition {
  return VOCABULARIES[id];
}
