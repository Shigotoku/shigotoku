/** サービス別の医療用語セット */
export type SpeechVocabulary = 'general' | 'soap' | 'checkup' | 'gi';

export interface VocabularyDefinition {
  /** Web Speech API phrases 用（正式名称を優先） */
  phraseTerms: string[];
  /** 正式名称 → 誤認識しやすい表記・読み */
  corrections: Record<string, string[]>;
}
