import { initHomeEmbed } from './homeEmbed';
import { SPECIALTIES } from '../shared/specialties';
import { fitHeight } from './warmWindow';
import {
  app,
  BrowserWindow,
  Notification,
  clipboard,
  dialog,
  globalShortcut,
  ipcMain,
  powerMonitor,
  screen,
  shell,
} from 'electron';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { randomUUID } from 'crypto';
import { IPC, type SpeechStatus } from '../shared/ipc';
import {
  captureForegroundWindow,
  logPaste,
  pasteToActiveWindow,
  setFastPaster,
  setPasteFailedHandler,
} from './paste';
import { LiveTyper } from './typer';
import { buildTrayMenu, createAppTray, createTrayIcon, type TrayOptions } from './tray';
import {
  appendDictionaryEntries,
  loadDictionary,
  learnedDictionaryPath,
  ensureAiInstructionFile,
  loadSettings,
  openDictionary,
  readDictionaryText,
  writeDictionaryText,
  saveSettings,
  type AppSettings,
} from './settings';
import { isLocalUrl, loadAi, needsCloudAck, setCloudAck } from './aiClient';
import { applyVoiceStyle, type VoiceStyle } from './aiVoice';
import { pickVoiceAiSample } from '../shared/voiceAiSamples';
import { newPartAfter } from '../shared/leadMarks';
import { describeAiRun, lastAiRun, recordAiRun, runBadge } from '../shared/aiRun';
import { describeChange } from '../shared/proofread';
import { applyDictShare, initDictAdmin } from './dictAdmin';
import { normalizeChatUrl } from '../shared/aiChatLink';
import {
  contributePairs,
  setContribution,
  setGlobalDictEnabled,
  startGlobalDictRefresh,
} from './globalDict';
import { isSafeLearnPair } from '../shared/vocab';
import { decodeImeFile, parseImeDictionary } from '../shared/imeDict';
import {
  aiProofreadAvailable,
  learnFromProofread,
  proofreadDetailed,
  proofreadMedical,
  queueLearning,
  setVoiceAiMode,
} from './aiProofread';
import { MEDICAL_EXTRA_READINGS } from '../shared/medicalDict';
import { CLINIC_TERMS } from '../shared/clinicTerms';
import { evaluateMic, type MicMeasurement } from '../shared/micCheck';
import { draftSoap, soapToText } from '../shared/soapDraft';
import { soapNoteLine } from '../shared/soapAi';
import { DEFAULT_SOAP_FORMAT, formatSoapWith, sanitizeSoapFormat } from '../shared/soapFormat';
import { aiSoapAvailable, generateSoapDetailed, generateSoapWithAi } from './aiSoap';
import { aiReportAvailable, generateReportWithAi } from './aiReport';
import { aiEchoAvailable, polishAbdomen, type PolishItem } from './aiEcho';
import { resolveAppBehavior, stripFinalPeriod, type AppBehavior } from '../shared/appProfiles';
import { expandSnippet, extractPrompts, validateSnippets, type Snippet } from '../shared/snippets';
import {
  bumpUsage,
  loadAllSnippets,
  loadUsage,
  loadSnippets,
  openSnippetFile,
  saveSnippets,
  snippetFilePath,
} from './snippetStore';
import {
  appendSharedDictionary,
  hasSharedFolder,
  openSharedFile,
  refreshShared,
  setSharedFolder,
  startSharedRefresh,
  stopSharedRefresh,
} from './sharedFiles';
import { TriggerWatcher } from './triggerWatcher';
import { disposeSchedule, initSchedule, openSchedule, warmUpSchedule } from './scheduleService';
import { initBoard, openBoard, refreshBoardSource, warmUpBoard } from './boardService';
import { initGoogleCalendar, openGoogleSettings } from './googleCalendar';
import { sharedFolderUsable } from './scheduleStore';
import { initDeck, openDeck, refreshDeck, stopDeckWatch } from './deckService';
import { initDeckWeb, stopDeckWeb } from './deckWeb';
import { startLocalAiWatch } from './innaiUpdate';
import { initSeats, openLicenseWindow } from './seats';
import { initLanShare, openLanSettings, stopLanShare } from './lanShare';
import { initStorage, openStorage } from './storageService';
import { initManual, openManual, refreshManualSource, warmUpManual } from './manualService';
import { initLists, openList, refreshListWatchers, warmUpLists } from './listService';
import { getRemindPrefs, initTaskReminder, setRemindPrefs } from './taskReminder';
import { initForm, listTemplates, openForm } from './formService';
import {
  CONTRACT_SYNC_ENABLED,
  LICENSE_ENFORCED,
  currentLicenseNotice,
  isToolLicensed,
  loadLicense,
  type ToolId,
} from './license';
import { noticeText } from '../shared/licenseState';
import { createContractSync, type ContractSync } from './contractSync';
import { createLinkStorage } from './contractStore';
import { HOME_APPS } from '../shared/homeApps';
import { runVoiceCommand } from './deckService';
import { parseVoiceCommand } from '../shared/deck';
import { disposePdfRenamer, initPdfRenamer, openPdfRenamer, warmUpPdfRenamer } from './pdfRenamer';
import { initPdfMerge, openPdfMerge } from './pdfMerge';
import { initPdfTools, openPdfTools } from './pdfTools';
import { ensureTermFolder, loadTermFolder, openTermFolder } from './termFolder';
import { triggerKey } from '../shared/triggerKey';
import { initDock, isDockVisible, setDockListening, showDock, toggleDock } from './dockService';
import {
  checkForUpdates,
  disposeUpdater,
  downloadUpdateNow,
  getUpdateStatus,
  initUpdater,
  installUpdateNow,
  setAutoUpdate,
} from './updater';
import {
  SpeechBridge,
  closeEngineBrowsers,
  findEdgeOrChrome,
  minimizeSpeechWindow,
  openSpeechPage,
} from './bridge';

const HOTKEY = 'Control+Shift+Space';
const LAUNCHER_HOTKEY = 'Control+Alt+Space';
const SCHEDULE_HOTKEY = 'Control+Alt+K';
const TASKS_HOTKEY = 'Control+Alt+T';
const BOARD_HOTKEY = 'Control+Alt+B';
const MANUAL_HOTKEY = 'Control+Alt+M';
const STOCK_HOTKEY = 'Control+Alt+I';
const PDF_HOTKEY = 'Control+Alt+P';
const DOCK_HOTKEY = 'Control+Alt+D';
// Ctrl+Alt+S は Windows 側のショートカットと競合するため、会話の「H」に変更（2026-10）
const SOAP_HOTKEY = 'Control+Alt+H';
const REPORT_HOTKEY = 'Control+Alt+E'; // 内視鏡（Endoscopy）レポート下書き
const ECHO_HOTKEY = 'Control+Alt+U'; // エコー（Ultrasound）レポート: 画面を開いて話す／話している最中は止める
const CORRECTION_HOTKEY = 'Control+Alt+R';
const SETUP_FLAG = 'setup-complete.json';
const ENGINE_WINDOW_SIZE = { width: 460, height: 300 };

let overlayWindow: BrowserWindow | null = null;
let setupWindow: BrowserWindow | null = null;
let launcherWindow: BrowserWindow | null = null;
let homeWindow: BrowserWindow | null = null;
let launcherTarget = 0;
let tray: ReturnType<typeof createAppTray> | null = null;
let bridge: SpeechBridge | null = null;

let settings: AppSettings = {
  specialty: 'general',
  medicalTerms: true,
  autoStart: true,
  autoUpdate: true,
  typeInBackground: true,
  typeHopCompat: false,
  pasteOnlyApps: [],
  inlineTriggers: true,
  sharedFolder: '',
  confirmBeforeInput: false,
  showListeningText: false,
  appRules: [],
  readyBeep: true,
  warmMic: false,
  aiProofread: false,
  aiProofreadLive: false,
  aiChatUrl: 'https://gemini.google.com/',
  soapDirect: true,
  soapFormat: DEFAULT_SOAP_FORMAT,
  voiceAiMode: 'off',
  aiVoiceStyle: 'plain',
  pausePunct: false,
  useGlobalDict: true,
  contributeDict: false,
  contributeUrl: '',
  dictShareFolder: '',
  dictSharePublicKey: '',
};
const typer = new LiveTyper();
setFastPaster((h, caretBack) => typer.pasteKeys(h, caretBack));
setPasteFailedHandler(() => {
  if (!Notification.isSupported()) return;
  new Notification({
    title: 'ちょこっとワークス',
    body: '入力先に貼り付けできませんでした。文章はコピーしてあります。入力したい場所で Ctrl+V を押してください。',
  }).show();
});
const elevatedNotified = new Set<string>();
typer.onElevated = (proc) => {
  const key = proc || '?';
  if (elevatedNotified.has(key) || !Notification.isSupported()) return;
  elevatedNotified.add(key);
  new Notification({
    title: 'ちょこっとワークス',
    body: `${proc || 'このアプリ'} は管理者権限で動いているため、そのままでは入力できません。ちょこっとワークスも「管理者として実行」で起動すると入力できます。`,
  }).show();
};
typer.onUnsupported = (proc) => {
  if (!proc) return;
  if (settings.pasteOnlyApps.some((n) => n.toLowerCase() === proc.toLowerCase())) return;
  settings = { ...settings, pasteOnlyApps: [...settings.pasteOnlyApps, proc] };
  saveSettings(settings);
};
let liveSession = false;
let lastPreviewSeq = 0;
let listening = false;
let status: SpeechStatus = 'idle';
let statusMessage: string | null = null;
let onDeviceReady = false;
let engineConnected = false;
let lastReadyStatus = '';
let lastMic = '';
let targetWindow: Promise<number> = Promise.resolve(0);

// 表示名（ちょこっとワークス）を変えても、設定・辞書・ライセンス等の保存場所が変わらないよう固定する
app.setPath('userData', path.join(app.getPath('appData'), 'chokotto-voice-dictation'));

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
}

function userDataFlagPath(): string {
  return path.join(app.getPath('userData'), SETUP_FLAG);
}

function isSetupComplete(): boolean {
  try {
    return fs.existsSync(userDataFlagPath());
  } catch {
    return false;
  }
}

function markSetupComplete(): void {
  fs.writeFileSync(
    userDataFlagPath(),
    JSON.stringify({ completedAt: new Date().toISOString() }),
    'utf-8'
  );
}

function rendererDir(): string {
  return path.join(__dirname, '../renderer');
}

function rendererPath(file: string): string {
  return path.join(rendererDir(), file);
}

function createOverlayWindow(): BrowserWindow {
  const win = new BrowserWindow({
    width: 360,
    height: 120,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: false,
    focusable: false,
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
      backgroundThrottling: false, // 隠していても開始・終了の合図音を確実に鳴らす
    },
  });
  void win.loadFile(rendererPath('overlay.html'));
  win.setIgnoreMouseEvents(true);
  return win;
}

/** ちょこっとワークスのホーム画面（全ツールの一覧）を開く */
function openHome(): void {
  if (homeWindow) {
    if (homeWindow.isMinimized()) homeWindow.restore();
    homeWindow.show();
    homeWindow.focus();
    return;
  }
  homeWindow = new BrowserWindow({
    width: 980,
    // 全ツールが1画面に収まる高さ（小さい画面では画面の高さに合わせ、足りない分はスクロール）
    height: Math.min(860, screen.getPrimaryDisplay().workArea.height - 40),
    minWidth: 700,
    minHeight: 500,
    autoHideMenuBar: true,
    title: 'ちょこっとワークス',
    icon: path.join(__dirname, '../../assets/icon.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  homeWindow.removeMenu();
  void homeWindow.loadFile(rendererPath('home.html'));
  homeWindow.on('closed', () => {
    homeWindow = null;
  });
}

/** 院内の共有フォルダを開く。未設定なら、設定できる「予定」画面を開く */
function openSharedFolder(): void {
  // 置き場所が決まっていて届くときは、そのフォルダをエクスプローラーで開く。決まっていないときは、設定の「共有フォルダ」へ
  const folder = settings.sharedFolder;
  if (folder && sharedFolderUsable()) {
    void shell.openPath(folder).then((err) => {
      if (err) openHomeAt('folder');
    });
    return;
  }
  openHomeAt('folder');
}

/** ホーム（設定）の指定のページを開く */
function openHomeAt(page: string, tab?: string): void {
  openHome();
  const send = (): void => {
    homeWindow?.webContents.send(IPC.HOME_GOTO, { page, tab });
  };
  if (homeWindow?.webContents.isLoading()) homeWindow.webContents.once('did-finish-load', send);
  else send();
}

/** 他のアプリがすでに使っているショートカットは登録できない。黙って効かないままにせず、1回だけ知らせる */
const failedHotkeys: string[] = [];
let hotkeyNoticeTimer: ReturnType<typeof setTimeout> | null = null;
function reportHotkeyFailure(accelerator: string): void {
  console.error(`Failed to register hotkey: ${accelerator}`);
  if (!failedHotkeys.includes(accelerator)) failedHotkeys.push(accelerator);
  if (hotkeyNoticeTimer) clearTimeout(hotkeyNoticeTimer);
  hotkeyNoticeTimer = setTimeout(() => {
    if (!Notification.isSupported() || failedHotkeys.length === 0) return;
    new Notification({
      title: 'ちょこっとワークス',
      body: `ほかのアプリが使っているため、次のショートカットは使えません: ${failedHotkeys.join('、')}（PochiRunやトレイのメニューからは使えます）`,
    }).show();
    failedHotkeys.length = 0;
  }, 2000);
}
/** 「アップデートを確認」の結果を、画面に出せる文章で返す（押しても何も起きないように見えないため） */
async function runUpdateAction(): Promise<string> {
  const now = getUpdateStatus();
  if (now.state === 'ready') {
    installUpdateNow();
    return '更新を適用して再起動します。管理者権限の確認が出たら「はい」を押してください。';
  }
  if (now.state === 'available') {
    downloadUpdateNow();
    return `新しいバージョン ${now.version ?? ''} のダウンロードを始めました。終わると「今すぐ更新して再起動」が出ます。`;
  }
  if (now.state === 'disabled') return '開発版のため、アップデートの確認はしません。';
  if (now.state === 'checking') return '確認中です。しばらくお待ちください…';
  if (now.state === 'downloading') {
    return `新しいバージョン ${now.version ?? ''} をダウンロード中です。終わると「今すぐ更新して再起動」が出ます。`;
  }
  await checkForUpdates(true);
  const s = getUpdateStatus();
  switch (s.state) {
    case 'downloading':
      return `新しいバージョン ${s.version ?? ''} が見つかりました。ダウンロードしています…（終わると「今すぐ更新して再起動」が出ます）`;
    case 'available':
      return `新しいバージョン ${s.version ?? ''} があります。「更新をダウンロード」を押してください。`;
    case 'ready':
      return `新しいバージョン ${s.version ?? ''} の準備ができました。「今すぐ更新して再起動」を押してください。`;
    case 'error':
      return `アップデートを確認できませんでした（${s.error ?? '通信エラー'}）。ネットワークを確認して、もう一度お試しください。`;
    default:
      return `最新バージョンです（バージョン ${app.getVersion()}）。`;
  }
}

/**
 * ご契約中のホームアプリID。null = 制限なし（ライセンス強制をしていない間は、すべて使える）。
 */
let contractSyncInst: ContractSync | null = null;
/** 契約状態の取得（CONTRACT_SYNC_ENABLED が false の間は使わない） */
function contractSync(): ContractSync {
  if (!contractSyncInst) {
    contractSyncInst = createContractSync({
      apiBase: process.env.CHOKOTTO_API_BASE || 'https://api.meditoku-cockpit.meditoku.com',
      storage: createLinkStorage(),
      fetchFn: (url, init) => fetch(url, init),
    });
  }
  return contractSyncInst;
}

function contractedAppIds(): string[] | null {
  if (CONTRACT_SYNC_ENABLED) {
    const v = contractSync().view();
    if (v) return v.contracted;
  }
  if (!LICENSE_ENFORCED) return null;
  const st = loadLicense();
  return HOME_APPS.filter((a) => a.license === null || isToolLicensed(st, a.license as ToolId)).map(
    (a) => a.id
  );
}

function runHomeAction(id: string): void {
  switch (id) {
    case 'voice':
      toggleListening();
      break;
    case 'snippets':
      void toggleLauncher();
      break;
    case 'snippets-edit':
      openEditor();
      break;
    case 'soap':
      toggleConversation();
      break;
    case 'report':
      toggleConversation('report');
      break;
    case 'echo':
      toggleEcho();
      break;
    case 'schedule':
      openSchedule();
      break;
    case 'tasks':
      openList('tasks');
      break;
    case 'board':
      openBoard();
      break;
    case 'manual':
      openManual();
      break;
    case 'lan':
      openLanSettings();
      break;
    case 'deck':
      openDeck();
      break;
    case 'chat':
      // 施設が使っているAI（ChatGPT・Gemini など）を、ブラウザですぐ開く
      void shell.openExternal(normalizeChatUrl(settings.aiChatUrl) ?? 'https://gemini.google.com/');
      break;
    case 'guide':
      void shell.openExternal('https://meditoku.com/setup/chokotto-works/#manual');
      break;
    case 'guide-local-ai':
      void shell.openExternal('https://meditoku.com/setup/chokotto-works/#local-ai');
      break;
    case 'home':
      openHome();
      break;
    case 'form':
      openForm();
      break;
    case 'folder':
      openSharedFolder();
      break;
    case 'storage':
      openStorage();
      break;
    case 'google':
      openGoogleSettings();
      break;
    case 'stock':
      openList('stock');
      break;
    case 'pdf':
      openPdfRenamer();
      break;
    case 'pdfmerge':
      openPdfMerge();
      break;
    case 'pdftools':
      openPdfTools();
      break;
    case 'dock':
      toggleDockAndRefresh();
      break;
    case 'correction':
      openCorrection();
      break;
    case 'terms':
      openTermFolder();
      break;
    case 'dictionary':
      void openDictionary();
      break;
    case 'mic':
      startMicCheck();
      break;
    case 'setup':
      openSetup();
      break;
    case 'update': {
      // 状態に合わせて1つのボタンで「確認 → ダウンロード → 更新して再起動」まで進める
      const u = getUpdateStatus().state;
      if (u === 'ready') installUpdateNow();
      else if (u === 'available') downloadUpdateNow();
      else void checkForUpdates(true);
      break;
    }
  }
}

function createLauncherWindow(): BrowserWindow {
  const win = new BrowserWindow({
    width: 600,
    height: fitHeight(540),
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: false,
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  void win.loadFile(rendererPath('launcher.html'));
  // 他の場所をクリックしたら閉じる
  win.on('blur', () => win.hide());
  return win;
}

/** スニペットのランチャーを開く（開く直前にフォーカスしていたウィンドウを入力先として覚える） */
async function toggleLauncher(query = ''): Promise<void> {
  if (!launcherWindow) return;
  if (launcherWindow.isVisible()) {
    launcherWindow.hide();
    return;
  }
  launcherTarget = await (typer.available ? typer.captureForeground() : captureForegroundWindow());
  const { width } = launcherWindow.getBounds();
  const display = screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  launcherWindow.setPosition(
    Math.round(display.workArea.x + (display.workArea.width - width) / 2),
    Math.round(display.workArea.y + display.workArea.height * 0.2)
  );
  launcherWindow.webContents.send(IPC.LAUNCHER_OPEN, {
    snippets: loadAllSnippets(),
    usage: loadUsage(),
    clipboard: clipboard.readText(),
    query,
  });
  launcherWindow.show();
  launcherWindow.focus();
}

// ---- 呼び名の即展開（キーボード監視。設定で ON のときだけ起動）----
const watcher = new TriggerWatcher((trigger) => void onTriggerMatched(trigger));

/** 監視に渡すのは「入力方式に依存しないキー」（ee1 / ええ１ / EE1 を同じ扱いにする） */
function snippetTriggers(): string[] {
  return [
    ...new Set(
      loadAllSnippets()
        .map((s) => (s.trigger ? triggerKey(s.trigger) : ''))
        .filter(Boolean)
    ),
  ];
}

function syncTriggerWatcher(): void {
  if (settings.inlineTriggers) {
    watcher.start(snippetTriggers());
  } else {
    watcher.stop();
  }
}

async function onTriggerMatched(trigger: string): Promise<void> {
  const snippet = loadAllSnippets().find((s) => s.trigger && triggerKey(s.trigger) === trigger);
  if (!snippet) return;
  const t0 = Date.now();
  // 入力欄({input:…}等)を含む定型文でも、画面は出さずその場に展開する（入力欄は空欄になる）
  launcherTarget = await (typer.available ? typer.captureForeground() : captureForegroundWindow());
  watcher.setEnabled(false);
  try {
    await insertSnippet(snippet.id, {});
    logPaste(`snippet inline total=${Date.now() - t0}ms`);
  } finally {
    watcher.setEnabled(true);
  }
}

// ---- スニペット編集画面 ----
let editorWindow: BrowserWindow | null = null;

function openEditor(): void {
  if (editorWindow) {
    editorWindow.show();
    editorWindow.focus();
    return;
  }
  editorWindow = new BrowserWindow({
    width: 920,
    height: fitHeight(680),
    minWidth: 640,
    minHeight: 420,
    autoHideMenuBar: true,
    title: 'ちょこっとスニペット - 編集',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  editorWindow.removeMenu();
  void editorWindow.loadFile(rendererPath('editor.html'));
  editorWindow.on('closed', () => {
    editorWindow = null;
  });
}

async function insertSnippet(id: string, inputs: Record<string, string>): Promise<void> {
  const snippet = loadAllSnippets().find((s) => s.id === id);
  const launcherWasOpen = launcherWindow?.isVisible() ?? false;
  launcherWindow?.hide();
  if (!snippet) return;
  bumpUsage(snippet.name);
  const { text, caretBack } = expandSnippet(snippet.text, {
    now: new Date(),
    clipboard: clipboard.readText(),
    inputs,
    library: loadAllSnippets(),
  });
  // ランチャーが閉じて入力先に操作が戻るのを待つ
  // （呼び名で即展開したときはランチャーが開いていないので待たない）
  if (launcherWasOpen) await new Promise((r) => setTimeout(r, 120));
  try {
    await pasteToActiveWindow(text, launcherTarget, { raw: true, caretBack });
  } catch (e) {
    logPaste(`snippet insert failed: ${String(e)}`);
  }
}

// ---- 訂正を辞書に育てる（直近の入力はメモリ上にだけ置く。ファイルには保存しない） ----
const RECENT_MAX = 5;
const RECENT_TTL_MS = 30 * 60 * 1000;
let recentInputs: Array<{ text: string; at: number }> = [];
let correctionWindow: BrowserWindow | null = null;

function rememberInput(text: string): void {
  if (!text.trim()) return;
  recentInputs = [{ text, at: Date.now() }, ...recentInputs].slice(0, RECENT_MAX);
}

function recentInputTexts(): string[] {
  const limit = Date.now() - RECENT_TTL_MS;
  recentInputs = recentInputs.filter((r) => r.at >= limit);
  return recentInputs.map((r) => r.text);
}

// ---- 診察会話 → SOAP 下書き（完全ローカル。会話の文章はメモリ上にだけ置く）----
let soapWindow: BrowserWindow | null = null;
let conversationSession = false;
/** 記録の種類: soap=診察会話→SOAP / report=内視鏡の発話→所見（レポートーク） */
let conversationKind: 'soap' | 'report' | 'echo' = 'soap';
let soapTarget = 0;

let soapAiSeq = 0;

/** ローカルAIでSOAP下書きを作り、できたら確認画面へ知らせる（失敗しても従来の下書きはそのまま） */
function startAiSoap(transcript: string): void {
  if (!aiSoapAvailable()) {
    // 使えない理由を、確認画面に出す（黙って従来の下書きだけにしない）
    soapWindow?.webContents.send(IPC.SOAP_AI, { state: 'none', reason: unavailableAiReason() });
    return;
  }
  const seq = ++soapAiSeq;
  soapWindow?.webContents.send(IPC.SOAP_AI, { state: 'working' });
  void generateSoapWithAi(transcript).then((draft) => {
    if (seq !== soapAiSeq || !soapWindow) return; // 新しい会話が開かれた/画面が閉じられた
    const run = lastAiRun();
    soapWindow.webContents.send(
      IPC.SOAP_AI,
      draft ? { state: 'ready', draft, ms: run?.ms } : { state: 'none', reason: run?.reason }
    );
  });
}

/** 院内AIが使えない理由（確認画面の説明用） */
function unavailableAiReason(): string {
  try {
    if (!isLocalUrl(loadAi().baseUrl))
      return '院外AIが選ばれています。「設定」→「AI設定」で院内AIを選んでください';
  } catch {
    /* 読めない */
  }
  return 'AI機能が利用できる状態ではありません（ライセンス・AI設定を確認）';
}

/** AIが「まとめ作成中」であることを画面下に出す間だけ true */
let composePhase = false;

/** 入力後の「お知らせ」を画面下に出している間 true */
let noticePhase = false;
let noticeTimer: ReturnType<typeof setTimeout> | null = null;
function showNotice(message: string, ms = 8000): void {
  if (noticeTimer) clearTimeout(noticeTimer);
  noticePhase = true;
  overlayNote = message;
  showOverlay(true);
  noticeTimer = setTimeout(() => {
    noticeTimer = null;
    noticePhase = false;
    overlayNote = '';
    if (!listening) hideOverlay();
  }, ms);
}

/**
 * トークラーク: 診察が終わったら、画面を開かずにSOAPをカーソル位置へ入力する。
 * 会話は決して捨てない:
 *  - AIの下書きは、照合で気になる点があっても入力し、気になる点は「※要確認」の1行で添える。
 *  - AIが使えない・失敗したときは、話した言葉をそのまま振り分けた下書きを入力し、理由を画面下に出す。
 *  - 入力先へ入力できなかったときだけ、確認画面に下書きを出す。
 */
async function soapDirectInsert(transcript: string, target: number): Promise<void> {
  composePhase = true;
  const tStart = Date.now();
  overlayNote = '経過 0秒';
  showOverlay(true);
  const composeTimer = setInterval(() => {
    overlayNote = `経過 ${Math.floor((Date.now() - tStart) / 1000)}秒`;
    sendOverlayUpdate(lastOverlayText);
  }, 1000);
  let res: Awaited<ReturnType<typeof generateSoapDetailed>> = null;
  try {
    res = await generateSoapDetailed(transcript);
  } finally {
    clearInterval(composeTimer);
    overlayNote = '';
    composePhase = false;
    hideOverlay();
  }
  let text: string;
  let notice = '';
  if (res) {
    text = formatSoapWith(res.draft, settings.soapFormat);
    const line = soapNoteLine(res.notes);
    if (line) {
      text += '\n' + line;
      notice = '気になる点があるため、末尾に「※要確認」を付けました。確認して直してください';
    }
  } else {
    text = formatSoapWith(soapToText(draftSoap(transcript)), settings.soapFormat);
    notice = `AIを使えなかったため、話した言葉をそのまま振り分けて入力しました（${lastAiRun()?.reason || '理由不明'}）`;
  }
  try {
    await pasteToActiveWindow(text, target, { raw: true });
    if (notice) showNotice(notice);
  } catch (e) {
    logPaste(`soap direct insert failed: ${String(e)}`);
    openSoapReview(transcript, '入力先へ入力できませんでした（下書きを確認画面に出しています）');
  }
}
function openSoapReview(transcript: string, aiFailedReason?: string): void {
  const payload = {
    transcript,
    draft: soapToText(draftSoap(transcript)),
    format: settings.soapFormat,
  };
  const send = () => {
    soapWindow?.webContents.send(IPC.SOAP_OPEN, payload);
    if (aiFailedReason !== undefined) {
      soapWindow?.webContents.send(IPC.SOAP_AI, { state: 'none', reason: aiFailedReason });
    } else startAiSoap(transcript);
  };
  if (soapWindow) {
    soapWindow.show();
    soapWindow.focus();
    send();
    return;
  }
  soapWindow = new BrowserWindow({
    width: 880,
    height: fitHeight(700),
    minWidth: 680,
    minHeight: 520,
    autoHideMenuBar: true,
    title: 'ちょこっとワークス - トークラーク',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  soapWindow.removeMenu();
  void soapWindow.loadFile(rendererPath('soap.html'));
  soapWindow.webContents.once('did-finish-load', send);
  soapWindow.on('closed', () => {
    soapWindow = null;
  });
}

// ---- レポートーク: 内視鏡の発話 → 所見の表とまとめ文（確認画面で直してから入力）----
let reportWindow: BrowserWindow | null = null;
let reportAiSeq = 0;

/** ローカルAIで所見の表を作り、できたら確認画面へ知らせる（失敗しても手入力で使える） */
function startAiReport(transcript: string): void {
  if (!aiReportAvailable()) {
    reportWindow?.webContents.send(IPC.REPORT_AI, { state: 'none', reason: unavailableAiReason() });
    return;
  }
  const seq = ++reportAiSeq;
  reportWindow?.webContents.send(IPC.REPORT_AI, { state: 'working' });
  void generateReportWithAi(transcript).then((findings) => {
    if (seq !== reportAiSeq || !reportWindow) return; // 新しい発話が開かれた/画面が閉じられた
    const run = lastAiRun();
    reportWindow.webContents.send(
      IPC.REPORT_AI,
      findings ? { state: 'ready', findings, ms: run?.ms } : { state: 'none', reason: run?.reason }
    );
  });
}

function openReportReview(transcript: string): void {
  const payload = { transcript, aiEnabled: aiReportAvailable() };
  const send = () => {
    reportWindow?.webContents.send(IPC.REPORT_OPEN, payload);
    startAiReport(transcript);
  };
  if (reportWindow) {
    reportWindow.show();
    reportWindow.focus();
    send();
    return;
  }
  reportWindow = new BrowserWindow({
    width: 980,
    height: fitHeight(720),
    minWidth: 760,
    minHeight: 540,
    autoHideMenuBar: true,
    title: 'ちょこっとワークス - 内視鏡レポート下書き',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  reportWindow.removeMenu();
  void reportWindow.loadFile(rendererPath('report.html'));
  reportWindow.webContents.once('did-finish-load', send);
  reportWindow.on('closed', () => {
    reportWindow = null;
  });
}

// ---- エコーレポート: 心エコー（項目名＋数値）／腹部エコー（所見のある臓器だけ）を話して、その場で表に反映 ----
let echoWindow: BrowserWindow | null = null;
let echoKind: 'cardiac' | 'abdomen' = 'cardiac';
/** 結果を入力するアプリ（エコー画面を開く直前にフォーカスがあったウィンドウ） */
let echoTarget = 0;

function sendEchoMic(state: 'idle' | 'preparing' | 'listening' | 'error', message?: string): void {
  echoWindow?.webContents.send(IPC.ECHO_MIC, { state, message });
}

function echoMicActive(): boolean {
  return listening && conversationSession && conversationKind === 'echo';
}

function startEchoMic(): void {
  if (listening) return;
  conversationKind = 'echo';
  conversationSession = true;
  sendEchoMic('preparing');
  startListening();
  if (!listening) {
    conversationSession = false; // セットアップ画面へ回された場合
    sendEchoMic('idle');
  }
}

/** Ctrl+Alt+U: 画面が無ければ開いて話し始める。開いていて話している最中なら止める。開いていて止まっていれば話し始める */
function toggleEcho(): void {
  if (echoWindow && !echoWindow.isDestroyed()) {
    if (echoMicActive()) flushListening();
    else if (!listening) startEchoMic();
    return;
  }
  void (async () => {
    // 入力先は、この画面を開く前にフォーカスがあったウィンドウ（開いた後は取れない）
    echoTarget = await (typer.available ? typer.captureForeground() : captureForegroundWindow());
    openEchoWindow(true);
  })();
}

function openEchoWindow(autoStart: boolean): void {
  const payload = { kind: echoKind, aiEnabled: aiEchoAvailable(), autoStart };
  echoWindow = new BrowserWindow({
    width: 1020,
    height: fitHeight(780),
    minWidth: 820,
    minHeight: 560,
    autoHideMenuBar: true,
    title: 'ちょこっとワークス - エコーレポート',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  echoWindow.removeMenu();
  void echoWindow.loadFile(rendererPath('echo.html'));
  echoWindow.webContents.once('did-finish-load', () => {
    echoWindow?.webContents.send(IPC.ECHO_OPEN, payload);
    if (autoStart) startEchoMic();
  });
  echoWindow.on('closed', () => {
    echoWindow = null;
    if (echoMicActive()) stopListening(); // 画面を閉じたら録音も止める
  });
}

/** 診察会話の記録を始める/終える（記録中はカーソル位置へは入力せず、終了後に確認画面を出す） */
function toggleConversation(kind: 'soap' | 'report' = 'soap'): void {
  if (listening) {
    flushListening();
    return;
  }
  conversationKind = kind;
  conversationSession = true;
  startListening();
  if (!listening) conversationSession = false; // セットアップ画面へ回された場合
}

// ---- 入力前の確認（確認モード / 入力先アプリの規則で有効になる）----
let confirmWindow: BrowserWindow | null = null;
let confirmSession = false;
let confirmTarget = 0;
let sessionBehavior: AppBehavior = {
  noFinalPeriod: false,
  confirm: false,
  chatNewline: false,
  label: '',
};

function openConfirm(text: string): void {
  const payload = { text, label: sessionBehavior.label };
  const send = () => confirmWindow?.webContents.send(IPC.CONFIRM_OPEN, payload);
  if (confirmWindow) {
    confirmWindow.show();
    confirmWindow.focus();
    send();
    return;
  }
  const display = screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  const width = 560;
  const height = 330;
  confirmWindow = new BrowserWindow({
    width,
    height,
    x: Math.round(display.workArea.x + (display.workArea.width - width) / 2),
    y: Math.round(display.workArea.y + display.workArea.height * 0.3),
    autoHideMenuBar: true,
    alwaysOnTop: true,
    title: 'ちょこっとワークス - 入力前の確認',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  confirmWindow.removeMenu();
  void confirmWindow.loadFile(rendererPath('confirm.html'));
  confirmWindow.webContents.once('did-finish-load', send);
  confirmWindow.on('closed', () => {
    confirmWindow = null;
  });
}

function openCorrection(): void {
  const send = () =>
    correctionWindow?.webContents.send(IPC.CORRECTION_OPEN, {
      recent: recentInputTexts(),
      shared: hasSharedFolder(),
    });
  if (correctionWindow) {
    correctionWindow.show();
    correctionWindow.focus();
    send();
    return;
  }
  correctionWindow = new BrowserWindow({
    width: 780,
    height: fitHeight(600),
    minWidth: 640,
    minHeight: 480,
    autoHideMenuBar: true,
    title: 'ちょこっとワークス - 認識の間違いを辞書に登録',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  correctionWindow.removeMenu();
  void correctionWindow.loadFile(rendererPath('correction.html'));
  correctionWindow.webContents.once('did-finish-load', send);
  correctionWindow.on('closed', () => {
    correctionWindow = null;
  });
}

// ---- マイク診断 ----
let micCheckRunning = false;
let micCheckTimer: ReturnType<typeof setTimeout> | null = null;

function finishMicCheck(): void {
  micCheckRunning = false;
  if (micCheckTimer) clearTimeout(micCheckTimer);
  micCheckTimer = null;
  hideOverlay();
}

function startMicCheck(): void {
  if (micCheckRunning) return;
  if (listening) {
    void dialog.showMessageBox({
      type: 'info',
      title: 'マイク診断',
      message: '音声入力の途中です。終了してからもう一度お試しください。',
    });
    return;
  }
  if (!engineConnected || !bridge) {
    openSetup();
    return;
  }
  micCheckRunning = true;
  showOverlay(true);
  sendOverlayUpdate('マイク診断を準備中…');
  bridge.emit(IPC.SPEECH_MIC_CHECK);
  // 認識ウィンドウから応答が無いときの安全策
  micCheckTimer = setTimeout(() => {
    if (!micCheckRunning) return;
    finishMicCheck();
    void dialog.showMessageBox({
      type: 'warning',
      title: 'マイク診断',
      message: 'マイクを診断できませんでした。',
      detail: '音声認識ウィンドウが応答しません。セットアップで準備を確認してください。',
    });
  }, 25000);
}

function onMicResult(payload: { measurement?: MicMeasurement; error?: string }): void {
  if (!micCheckRunning) return;
  finishMicCheck();
  if (!payload.measurement) {
    void dialog.showMessageBox({
      type: 'warning',
      title: 'マイク診断',
      message: 'マイクを診断できませんでした。',
      detail: payload.error ?? '',
    });
    return;
  }
  const verdict = evaluateMic(payload.measurement);
  void dialog.showMessageBox({
    type: verdict.level === 'poor' ? 'warning' : 'info',
    title: 'マイク診断',
    message: verdict.title,
    detail: verdict.lines.join('\n'),
  });
}

function createSetupWindow(): BrowserWindow {
  const win = new BrowserWindow({
    width: 520,
    height: 380,
    useContentSize: true,
    autoHideMenuBar: true,
    title: 'ちょこっとワークス - セットアップ',
    resizable: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  win.removeMenu();
  void win.loadFile(rendererPath('setup.html'));
  win.on('closed', () => {
    setupWindow = null;
  });
  return win;
}

function appState() {
  return {
    engineConnected,
    onDeviceReady,
    readyStatus: lastReadyStatus,
    mic: lastMic,
    browserFound: Boolean(findEdgeOrChrome()),
  };
}

function notifySetup(): void {
  setupWindow?.webContents.send(IPC.APP_STATE_CHANGED, appState());
}

/**
 * 聞き取り中だけ Enter キーを奪って「音声入力の終了」にする。
 * 聞き取りが終わったら必ず解放する（updateTray は状態が変わるたびに呼ばれる）。
 * 注意: 聞き取り中の Enter は入力先アプリには届かない（終了のみ。改行は入らない）。
 */
let enterCaptured = false;
function syncEnterCapture(): void {
  if (listening && !enterCaptured) {
    enterCaptured = globalShortcut.register('Enter', () => flushListening());
    if (!enterCaptured) logPaste('Enter shortcut registration failed');
  } else if (!listening && enterCaptured) {
    globalShortcut.unregister('Enter');
    enterCaptured = false;
  }
}

/** 音声入力のAI利用方針を切り替える。クラウドを選ぶときは、外部送信の注意を確認してから */
async function selectVoiceAiMode(mode: 'off' | 'local' | 'cloud'): Promise<void> {
  if (mode === 'cloud' && needsCloudAck()) {
    const r = await dialog.showMessageBox({
      type: 'warning',
      buttons: ['理解して使う', 'やめる'],
      defaultId: 1,
      cancelId: 1,
      title: '音声入力のAI（クラウド）について',
      message: '話した文章が、設定したAIサービス（外部）に送られます',
      detail:
        '患者さんの氏名・病名などの個人情報が含まれる場合があります。院内の方針とAIサービスの規約を確認のうえ、ご自身のAPIキーでお使いください。\nAIの接続先とAPIキーは、ちょこっとワークスの「設定」→「AI設定」で選びます。個人情報が心配な場合は「院内のAI」を選んでください。',
    });
    if (r.response !== 0) {
      updateTray();
      return;
    }
    setCloudAck();
  }
  setVoiceSetting({ voiceAiMode: mode });
}

/** カルテ文体・SOAP を使う設定で、院内AIにつながる状態か（このときは確認画面を経て入力する） */
function rewriteStyleActive(): boolean {
  try {
    return (
      settings.voiceAiMode !== 'off' &&
      settings.aiVoiceStyle !== 'plain' &&
      isLocalUrl(loadAi().baseUrl)
    );
  } catch {
    return false;
  }
}

/** 確認画面を経由する入力で、AIが整えるスタイル（使わないなら null） */
function activeVoiceStyle(): VoiceStyle | null {
  if (settings.voiceAiMode === 'off') return null;
  if (rewriteStyleActive()) return settings.aiVoiceStyle;
  return settings.aiProofreadLive ? 'plain' : null;
}

function voiceAiHints(): string[] {
  return [
    ...loadDictionary().map((d) => d.to),
    ...loadTermFolder().terms,
    ...Object.keys(MEDICAL_EXTRA_READINGS),
    ...Object.keys(CLINIC_TERMS),
  ];
}

/** ホーム画面の「AIによる校正」の選択状態 */
function voiceAiChoice(): 'off' | 'live' | 'learn' | 'chart' | 'soap' {
  if (settings.voiceAiMode === 'off') return 'off';
  if (settings.aiVoiceStyle !== 'plain') return settings.aiVoiceStyle;
  if (settings.aiProofreadLive) return 'live';
  return settings.aiProofread ? 'learn' : 'off';
}

/** いま実際にAIが使われる状態か、使われないならなぜか（画面の説明用） */
function voiceAiStatusText(): string {
  if (voiceAiChoice() === 'off') return 'AIは使っていません。';
  if (settings.aiVoiceStyle !== 'plain' && !rewriteStyleActive()) {
    return 'カルテ文体・SOAPは院内AIだけで動きます。「設定」→「AI設定」で院内AIを選んでください。';
  }
  if (!aiProofreadAvailable()) {
    return 'AI設定の接続先が使えない状態です（院外AIは、APIキーと確認が必要です）。「設定」→「AI設定」を確認してください。';
  }
  return isLocalUrl(loadAi().baseUrl)
    ? '院内AIで校正します（文章は院内から出ません）。'
    : '院外AIで校正します（文章が外部のAIサービスに送られます）。';
}

/** 画面の処理状況カード（接続先・モデル・処理時間・結果）。本文は含めない */
function voiceAiCard(): {
  host: string;
  model: string;
  badge: string;
  tone: string;
  ms: number | null;
  reason: string;
} {
  const run = lastAiRun();
  let host = '';
  let model = '';
  try {
    const c = loadAi();
    host = new URL(c.baseUrl).host;
    model = c.model;
  } catch {
    /* 未設定 */
  }
  const b = runBadge(run);
  return {
    host,
    model,
    badge: b.label,
    tone: b.tone,
    ms: run ? run.ms : null,
    reason: run?.reason ?? '',
  };
}

/** 前回の試験で使った架空の文章（次は違う文章を選ぶため） */
let lastVoiceAiSample: string | null = null;

function setVoiceSetting(patch: Partial<AppSettings>): void {
  settings = { ...settings, ...patch };
  applyLearningSettings();
  saveSettings(settings);
  updateTray();
}

/** IMEの単語登録の書き出しファイルを選んでもらい、「読み→単語」をユーザー辞書へ追加する */
async function importImeDictionary(): Promise<void> {
  const r = await dialog.showOpenDialog({
    title: '日本語入力(IME)の単語登録の書き出しファイルを選んでください',
    properties: ['openFile'],
    filters: [{ name: '単語登録ファイル', extensions: ['txt', 'dic', 'csv', 'tsv'] }],
  });
  if (r.canceled || !r.filePaths[0]) return;
  try {
    const pairs = parseImeDictionary(decodeImeFile(fs.readFileSync(r.filePaths[0])));
    const added = pairs.length
      ? appendDictionaryEntries(pairs.map((p) => `${p.reading}→${p.word}`))
      : 0;
    await dialog.showMessageBox({
      type: 'info',
      title: '単語登録の取り込み',
      message: pairs.length
        ? `${added}件をユーザー辞書に追加しました（読み込んだ単語 ${pairs.length}件）`
        : '取り込める単語が見つかりませんでした',
      detail:
        '次の音声入力から反映されます。\n読みが3文字未満の単語や、同じ登録の重複は取り込みません。\n※Microsoft IME は「IMEツール」→「単語の登録」→「ユーザー辞書ツール」→「ツール」→「テキストファイルへの登録」で書き出せます。',
    });
  } catch (e) {
    logPaste(`ime import failed: ${String(e)}`);
    void dialog.showMessageBox({
      type: 'error',
      message: '取り込めませんでした。ファイルを確認してください。',
    });
  }
}

/** AI利用方針・みんなの辞書の設定を、各部へ反映する */
function applyLearningSettings(): void {
  setVoiceAiMode(settings.voiceAiMode);
  setGlobalDictEnabled(settings.useGlobalDict);
  setContribution({
    enabled: settings.contributeDict,
    url: settings.contributeUrl,
    version: app.getVersion(),
  });
}

function updateTray(): void {
  setDockListening(listening);
  syncEnterCapture();
  if (!tray) return;
  tray.setToolTip(
    listening
      ? 'ちょこっとワークス - 聞き取り中 (Ctrl+Shift+Space)'
      : 'ちょこっとワークス (音声入力: Ctrl+Shift+Space)'
  );
  tray.setContextMenu(buildTrayMenu(trayOptions()));
}

/** Windows ログイン時の自動起動（インストール版のみ有効。開発実行 `electron .` では登録しない） */
function applyAutoStart(enabled: boolean): void {
  if (!app.isPackaged) return;
  try {
    app.setLoginItemSettings({ openAtLogin: enabled, args: ['--hidden'] });
  } catch (e) {
    logPaste(`setLoginItemSettings failed: ${String(e)}`);
  }
}

function toggleDockAndRefresh(): void {
  toggleDock();
  updateTray();
}

function updateTrayItem(): TrayOptions['update'] {
  const u = getUpdateStatus();
  switch (u.state) {
    case 'ready':
      return {
        label: `今すぐ更新して再起動（v${u.version}）`,
        enabled: true,
        onClick: () => installUpdateNow(),
      };
    case 'available':
      return {
        label: `アップデートをダウンロード（v${u.version}）`,
        enabled: true,
        onClick: () => downloadUpdateNow(),
      };
    case 'checking':
      return { label: 'アップデートを確認中…', enabled: false, onClick: () => undefined };
    case 'downloading':
      return {
        label: `アップデートをダウンロード中（v${u.version}）…`,
        enabled: false,
        onClick: () => undefined,
      };
    default:
      return {
        label: `アップデートを確認（現在 v${app.getVersion()}）`,
        enabled: true,
        onClick: () => void checkForUpdates(true),
      };
  }
}

function trayOptions(): TrayOptions {
  return {
    listening,
    onToggle: () => toggleListening(),
    onSetup: () => openSetup(),
    onQuit: () => app.quit(),
    onOpenHome: () => openHome(),
    voiceAi: {
      current: settings.voiceAiMode,
      onSelect: (mode) => {
        void selectVoiceAiMode(mode);
      },
    },
    specialty: {
      current: settings.specialty,
      onSelect: (id) => {
        settings = { ...settings, specialty: id };
        saveSettings(settings);
        updateTray();
      },
    },
    medicalTerms: {
      enabled: settings.medicalTerms,
      onToggle: (enabled) => {
        settings = { ...settings, medicalTerms: enabled };
        saveSettings(settings);
        updateTray();
      },
    },
    listeningText: {
      enabled: settings.showListeningText,
      onToggle: (enabled) => {
        settings = { ...settings, showListeningText: enabled };
        saveSettings(settings);
        updateTray();
      },
    },
    confirmBeforeInput: {
      enabled: settings.confirmBeforeInput,
      onToggle: (enabled) => {
        settings = { ...settings, confirmBeforeInput: enabled };
        saveSettings(settings);
        updateTray();
      },
    },
    onOpenSchedule: () => openSchedule(),
    onOpenTasks: () => openList('tasks'),
    onOpenBoard: () => openBoard(),
    onOpenManual: () => openManual(),
    onOpenGoogle: () => openGoogleSettings(),
    onOpenLan: () => openLanSettings(),
    onOpenDeck: () => openDeck(),
    onOpenGuide: () => void shell.openExternal('https://meditoku.com/setup/chokotto-works/#manual'),
    onOpenLicense: () => openLicenseWindow(),
    onOpenStock: () => openList('stock'),
    onOpenPdf: () => openPdfRenamer(),
    onOpenPdfMerge: () => openPdfMerge(),
    onOpenPdfTools: () => openPdfTools(),
    onOpenForm: () => openForm(),
    formTemplates: listTemplates(),
    onOpenFormTemplate: (name) => openForm(undefined, name),
    onToggleDock: () => toggleDockAndRefresh(),
    dockVisible: isDockVisible(),
    update: updateTrayItem(),
    onOpenTerms: () => openTermFolder(),
    onOpenDictionary: () => void openDictionary(),
    onOpenCorrection: () => openCorrection(),
    onConversation: () => toggleConversation(),
    onReport: () => toggleConversation('report'),
    onEcho: () => toggleEcho(),
    shared: hasSharedFolder()
      ? {
          onOpenDictionary: () => void openSharedFile('dictionary'),
          onOpenSnippets: () => void openSharedFile('snippets'),
        }
      : null,
    onMicCheck: () => startMicCheck(),
    snippets: {
      onOpen: () => void toggleLauncher(),
      onEdit: () => openEditor(),
      inline:
        process.platform === 'win32'
          ? {
              enabled: settings.inlineTriggers,
              onToggle: (enabled) => {
                settings = { ...settings, inlineTriggers: enabled };
                saveSettings(settings);
                syncTriggerWatcher();
                updateTray();
              },
            }
          : null,
    },
    autoStart: {
      enabled: settings.autoStart,
      onToggle: (enabled) => {
        settings = { ...settings, autoStart: enabled };
        saveSettings(settings);
        applyAutoStart(enabled);
        updateTray();
      },
    },
    appMethod: lastTargetProc
      ? {
          app: lastTargetProc,
          paste:
            lastTargetAuto ||
            settings.pasteOnlyApps.some((n) => n.toLowerCase() === lastTargetProc.toLowerCase()),
          locked: lastTargetAuto,
          onToggle: (on) => {
            const key = lastTargetProc.toLowerCase();
            const rest = settings.pasteOnlyApps.filter((n) => n.toLowerCase() !== key);
            settings = { ...settings, pasteOnlyApps: on ? [...rest, lastTargetProc] : rest };
            saveSettings(settings);
            updateTray();
          },
        }
      : undefined,
    onCopyLast: () => {
      const last = recentInputs[0]?.text;
      if (last) clipboard.writeText(last);
    },
    onOpenLog: () => void shell.openPath(path.join(app.getPath('userData'), 'paste.log')),
    onOpenLearned: () => {
      const file = learnedDictionaryPath();
      if (!fs.existsSync(file))
        fs.writeFileSync(file, '\uFEFF# AI が見つけた誤認識の修正（自動で貯まります）\n', 'utf-8');
      void shell.openPath(file);
    },
    onImportIme: () => {
      void importImeDictionary();
    },
    onOpenAiInstruction: () => {
      void shell.openPath(ensureAiInstructionFile());
    },
    voiceToggles: [
      {
        label: '話の間が空いたとき、自動で「、」「。」を付ける',
        enabled: settings.pausePunct,
        onToggle: (enabled) => setVoiceSetting({ pausePunct: enabled }),
      },
      {
        label: '話し始められる合図に音を鳴らす',
        enabled: settings.readyBeep,
        onToggle: (enabled) => setVoiceSetting({ readyBeep: enabled }),
      },
      {
        label: 'マイクを待機状態にして話し始めを速くする（マイク使用中の表示が常に出ます）',
        enabled: settings.warmMic,
        onToggle: (enabled) => setVoiceSetting({ warmMic: enabled }),
      },
      {
        label: aiProofreadAvailable()
          ? 'AIが陰で誤変換を見つけて学習する（入力は待たせません）'
          : 'AIが陰で誤変換を見つけて学習する（※「音声入力のAI校正」でAIを選ぶと動きます）',
        enabled: settings.aiProofread,
        onToggle: (enabled) => setVoiceSetting({ aiProofread: enabled }),
      },
      {
        label: aiProofreadAvailable()
          ? 'AIが入力の直前に文脈を見て医学用語を直す（確定時に最大3秒ほど待ちます）'
          : 'AIが入力の直前に文脈を見て医学用語を直す（※「音声入力のAI校正」でAIを選ぶと動きます）',
        enabled: settings.aiProofreadLive,
        onToggle: (enabled) => setVoiceSetting({ aiProofreadLive: enabled }),
      },
      {
        label: 'みんなで育てる辞書を使う（全ユーザーの学習から作った辞書を自動で取得）',
        enabled: settings.useGlobalDict,
        onToggle: (enabled) => setVoiceSetting({ useGlobalDict: enabled }),
      },
      {
        label:
          '辞書の改善に協力する（見つけた医学用語の言い間違いだけを匿名で提出。患者さんの文章は送りません）',
        enabled: settings.contributeDict,
        onToggle: (enabled) => setVoiceSetting({ contributeDict: enabled }),
      },
    ],
    typeHopCompat: {
      enabled: settings.typeHopCompat,
      onToggle: (enabled) => {
        settings = { ...settings, typeHopCompat: enabled };
        saveSettings(settings);
        typer.hop = enabled;
        updateTray();
      },
    },
    typeInBackground: {
      enabled: settings.typeInBackground,
      onToggle: (enabled) => {
        settings = { ...settings, typeInBackground: enabled };
        saveSettings(settings);
        typer.background = enabled;
        updateTray();
      },
    },
    autoUpdate: {
      enabled: settings.autoUpdate,
      onToggle: (enabled) => {
        settings = { ...settings, autoUpdate: enabled };
        saveSettings(settings);
        setAutoUpdate(enabled);
        updateTray();
      },
    },
  };
}

/** 各ツール（リスト・予定・PDF・ドック）を初期化。起動時に一度だけ呼ぶ */
function initModules(): void {
  app.setAppUserModelId('com.meditoku.chokotto.voicedictation');
  initLists({ rendererPath, preloadPath: path.join(__dirname, 'preload.js') });
  initGoogleCalendar({ rendererPath, preloadPath: path.join(__dirname, 'preload.js') });
  initManual({ rendererPath, preloadPath: path.join(__dirname, 'preload.js') });
  initBoard({ rendererPath, preloadPath: path.join(__dirname, 'preload.js') });
  initTaskReminder({ rendererPath, preloadPath: path.join(__dirname, 'preload.js') });
  initDeck({
    rendererPath,
    preloadPath: path.join(__dirname, 'preload.js'),
    runApp: (id) => runHomeAction(id),
  });
  initDeckWeb();
  startLocalAiWatch();
  initSeats({ rendererPath, preloadPath: path.join(__dirname, 'preload.js') });
  initLanShare({
    rendererPath,
    preloadPath: path.join(__dirname, 'preload.js'),
    getCurrentFolder: () => settings.sharedFolder,
    setFolder: (folder) => {
      settings = { ...settings, sharedFolder: folder };
      saveSettings(settings);
      setSharedFolder(folder);
      refreshListWatchers();
      refreshBoardSource();
      refreshManualSource();
      updateTray();
    },
    onFolderChanged: () => {
      refreshDeck();
      refreshListWatchers();
      refreshBoardSource();
      refreshManualSource();
    },
  });
  initStorage({ rendererPath, preloadPath: path.join(__dirname, 'preload.js') });
  initPdfRenamer({ rendererPath, preloadPath: path.join(__dirname, 'preload.js') });
  initPdfMerge({ rendererPath, preloadPath: path.join(__dirname, 'preload.js') });
  initPdfTools({ rendererPath, preloadPath: path.join(__dirname, 'preload.js') });
  initForm({
    rendererPath,
    preloadPath: path.join(__dirname, 'preload.js'),
    onChanged: () => updateTray(),
  });
  initDock({
    onVisibilityChanged: () => updateTray(),
    rendererPath,
    preloadPath: path.join(__dirname, 'preload.js'),
    actions: {
      voice: () => toggleListening(),
      snippets: () => void toggleLauncher(),
      schedule: () => openSchedule(),
      tasks: () => openList('tasks'),
      board: () => openBoard(),
      manual: () => openManual(),
      folder: () => openSharedFolder(),
      deck: () => openDeck(),
      google: () => openGoogleSettings(),
      stock: () => openList('stock'),
      pdf: () => openPdfRenamer(),
      pdfmerge: () => openPdfMerge(),
      pdftools: () => openPdfTools(),
      soap: () => toggleConversation(),
      report: () => toggleConversation('report'),
      echo: () => toggleEcho(),
      home: () => openHome(),
    },
  });
  initSchedule({
    onSharedFolderChanged: () => {
      refreshListWatchers();
      refreshBoardSource();
      refreshManualSource();
      refreshDeck();
    },
    rendererPath,
    preloadPath: path.join(__dirname, 'preload.js'),
    getSharedFolder: () => settings.sharedFolder,
    saveSharedFolder: (folder) => {
      settings = { ...settings, sharedFolder: folder };
      saveSettings(settings);
      setSharedFolder(folder); // 共有の辞書・スニペットも同じフォルダを使う
      updateTray();
    },
  });
}

/** force=true: 設定に関係なく表示（マイク診断など、画面に出さないと伝わないもの） */
function showOverlay(force = false): void {
  if (!overlayWindow) return;
  const { width, height } = overlayWindow.getBounds();
  const display = screen.getPrimaryDisplay();
  const x = Math.round(display.workArea.x + (display.workArea.width - width) / 2);
  const y = Math.round(display.workArea.y + display.workArea.height - height - 48);
  overlayWindow.setPosition(x, y);
  overlayWindow.showInactive();
  overlayWindow.webContents.send(IPC.OVERLAY_SHOW);
  sendOverlayUpdate('');
}

function hideOverlay(): void {
  overlayWindow?.hide();
  overlayWindow?.webContents.send(IPC.OVERLAY_HIDE);
}

/** 認識中の画面に添える案内（例: 話し終えるとまとめて入力される） */
let overlayNote = '';
let lastOverlayText = '';

// ---- 貼り付け方式のアプリ（LINE など）: 話すのを止めるたびに、その文ずつ入力する ----
let pasteOnlySession = false;
let pastedSoFar = '';
let pasteTimer: ReturnType<typeof setTimeout> | null = null;
/** 貼り付け中の途中入力（確定の貼り付けと同時に走ってクリップボードを奪い合い、二重に入るのを防ぐ） */
let incrementInFlight: Promise<void> | null = null;
/** 直前に音声入力したアプリ（トレイから貼り付け方式を切り替えるため） */
let lastTargetProc = '';
let lastTargetAuto = false;
const INCREMENT_PAUSE_MS = 1400;

function schedulePasteIncrement(text: string): void {
  if (pasteTimer) clearTimeout(pasteTimer);
  pasteTimer = setTimeout(() => {
    pasteTimer = null;
    void pasteIncrement(text);
  }, INCREMENT_PAUSE_MS);
}

async function pasteIncrement(text: string): Promise<void> {
  if (!pasteOnlySession || !listening) return;
  if (!text.startsWith(pastedSoFar)) return; // 認識が書き換わった: 最後にまとめて入力する
  const delta = text.slice(pastedSoFar.length).replace(/^[。、，．]+/, '');
  if (delta.trim().length < 3) return;
  const target = await targetWindow;
  if (!target) return;
  // 入力先から離れている間は貼らない（別の画面を見ているところへ割り込まない）。戻ったら次の区切りで入る
  if ((await typer.captureForeground()) !== target) return;
  // 待っている間に Enter で終了していたら、確定の貼り付けと重なって二重に入るので何もしない
  if (!pasteOnlySession || !listening) return;
  pastedSoFar = text;
  const run = (async () => {
    try {
      await pasteToActiveWindow(delta, target, { raw: true });
    } catch (e) {
      logPaste(`incremental paste failed: ${String(e)}`);
    }
  })();
  incrementInFlight = run;
  await run;
  if (incrementInFlight === run) incrementInFlight = null;
}
function sendOverlayUpdate(text: string): void {
  lastOverlayText = text;
  overlayWindow?.webContents.send(IPC.OVERLAY_UPDATE, {
    text,
    listening,
    note: overlayNote || (status === 'listening' && statusMessage ? statusMessage : ''),
    compact: !settings.showListeningText,
    phase: composePhase ? 'composing' : noticePhase && !listening ? 'notice' : status,
    // トークラーク・レポートーク使用中は、通常の音声入力と区別できるようアプリ名を出す
    app:
      conversationSession || composePhase
        ? conversationKind === 'report'
          ? 'レポートーク（内視鏡）'
          : conversationKind === 'echo'
            ? 'レポートーク（エコー）'
            : 'トークラーク'
        : '',
  });
}

/** 日本語（かな・漢字・全角記号）の前後の空白を除去（貼り付け直前の最終防衛線） */
function removeJapaneseSpaces(text: string): string {
  const ja = '[\\u3000-\\u303F\\u3040-\\u30FF\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uFF00-\\uFFEF]';
  return text
    .replace(new RegExp(`(?<=${ja})[\\s\\u3000]+`, 'g'), '')
    .replace(new RegExp(`[\\s\\u3000]+(?=${ja})`, 'g'), '');
}

/** 入力直前のAI校正を待つ上限（ミリ秒）。超えたら校正せずそのまま入力する */
const LIVE_PROOFREAD_MS = 3000;

async function commitText(text: string): Promise<void> {
  if (incrementInFlight) await incrementInFlight.catch(() => {});
  const incPasted = pasteOnlySession ? pastedSoFar : '';
  pasteOnlySession = false;
  pastedSoFar = '';
  if (pasteTimer) clearTimeout(pasteTimer);
  pasteTimer = null;
  let trimmed = removeJapaneseSpaces(text)
    .trim()
    .replace(/^[。、，．]+/, '');
  if (sessionBehavior.noFinalPeriod) trimmed = stripFinalPeriod(trimmed);
  const voiceCmd = !confirmSession && !conversationSession ? parseVoiceCommand(trimmed) : null;
  if (voiceCmd) {
    // 「ポチラン、予約表」: 文章としては入力せず、合うボタンを押す
    if (liveSession) {
      await typer.flush('');
      typer.end();
    }
    listening = false;
    liveSession = false;
    status = 'idle';
    statusMessage = null;
    updateTray();
    hideOverlay();
    void runVoiceCommand(voiceCmd);
    return;
  }
  if (confirmSession) {
    // 確認モード: カーソル位置へは入力せず、確認画面で直してから入力する
    confirmSession = false;
    let confirmText = trimmed;
    const aiStyle = activeVoiceStyle();
    if (trimmed && aiStyle) {
      // AIで整えてから確認画面へ（使えない・失敗のときは元の文章のまま。結果は画面の「直近のAI処理」に出る）
      overlayNote = 'AIで整えています…';
      sendOverlayUpdate(lastOverlayText);
      const ctx = recentInputTexts().slice(0, 2).reverse().join('\n');
      const r = await applyVoiceStyle(trimmed, aiStyle, voiceAiHints(), ctx);
      overlayNote = '';
      confirmText = r.text;
    }
    listening = false;
    liveSession = false;
    status = 'idle';
    statusMessage = null;
    updateTray();
    hideOverlay();
    if (confirmText) openConfirm(confirmText);
    return;
  }
  if (conversationSession) {
    // 診察会話: カーソル位置へは入力せず、SOAP下書きの確認画面を開く（会話は履歴にも残さない）
    conversationSession = false;
    listening = false;
    status = 'idle';
    statusMessage = null;
    updateTray();
    hideOverlay();
    if (conversationKind === 'echo') {
      // エコー: 画面へ確定した全文を渡す（空でも「終わった」ことを伝える）
      echoWindow?.webContents.send(IPC.ECHO_TEXT, { text: text.trim(), final: true });
      sendEchoMic('idle');
      return;
    }
    if (trimmed) {
      if (conversationKind === 'report') openReportReview(trimmed);
      else if (settings.soapDirect && soapTarget) void soapDirectInsert(trimmed, soapTarget);
      else openSoapReview(trimmed);
    }
    return;
  }
  const aiHints = [
    ...loadDictionary().map((d) => d.to),
    ...loadTermFolder().terms,
    ...Object.keys(MEDICAL_EXTRA_READINGS),
    ...Object.keys(CLINIC_TERMS),
  ];
  // 入力の直前に、PC内のAIが直前の入力などの文脈を見て医学用語を直す（時間切れ・不採用ならそのまま入力）。
  // 途中まで貼り付け済みの方式では、文頭が変わると二重に入るので使わない
  let correctedLive = false;
  // ちょこっとワークス自身の画面（院内AIチャットの入力欄など）への入力は、校正で待たせない
  const ownTarget =
    lastTargetProc !== '' &&
    lastTargetProc.toLowerCase() ===
      path.basename(process.execPath, path.extname(process.execPath)).toLowerCase();
  if (settings.aiProofreadLive && trimmed && ownTarget) {
    recordAiRun({
      kind: 'plain',
      status: 'skipped',
      reason: 'ちょこっとワークス内への入力のため',
      ms: 0,
    });
  }
  if (settings.aiProofreadLive && trimmed && !incPasted && !ownTarget) {
    const ctx = recentInputTexts().slice(0, 2).reverse().join('\n');
    const fixed = await proofreadMedical(trimmed, aiHints, LIVE_PROOFREAD_MS, ctx);
    if (fixed) {
      void learnFromProofread(trimmed, fixed);
      trimmed = fixed;
      correctedLive = true;
    }
  }
  if (settings.aiProofreadLive && trimmed && incPasted) {
    recordAiRun({
      kind: 'plain',
      status: 'skipped',
      reason: 'このアプリは文ごとに入力するため',
      ms: 0,
    });
  }
  // 陰の学習: 入力は直さず待たせず、あとで PC 内のAIが見直して、誤変換を今後の音声入力に活かす
  if (settings.aiProofread && trimmed && !correctedLive) {
    queueLearning(trimmed, aiHints, () => listening || status !== 'idle');
  }
  rememberInput(trimmed);
  const wasLive = liveSession;
  listening = false;
  liveSession = false;
  status = trimmed ? 'pasting' : 'idle';
  statusMessage = null;
  updateTray();
  // すぐには消さず「入力しています…」を見せる（入力が終わったら消す）
  if (trimmed) sendOverlayUpdate(lastOverlayText);
  else hideOverlay();

  if (wasLive) {
    // ライブ入力済み: 最終テキスト（句点など）を反映して終了。入力済みの文字は残す。
    const rest = await typer.flush(trimmed);
    const typedSomething = typer.hasTyped;
    const paused = typer.isPaused;
    typer.end();
    // 他の画面を見ている間に話した続きは、入力先に戻れなかった分だけ貼り付けで入力する
    if (rest) {
      try {
        await pasteToActiveWindow(rest, await targetWindow);
      } catch (e) {
        logPaste(`commit rest failed: ${String(e)}`);
      }
    }
    // ライブ入力が何も入力できなかった（入力先が変わった等）場合だけ、従来の貼り付けで救済する
    if (trimmed && !typedSomething && !paused) {
      try {
        await pasteToActiveWindow(trimmed, await targetWindow);
      } catch (e) {
        logPaste(`commit failed: ${String(e)}`);
      }
    }
  } else if (trimmed) {
    // 途中まで文ごとに入力済みなら、残りだけを入力する
    let toPaste = trimmed;
    if (incPasted) {
      // 入力済みの部分が最終テキストと少し違っていても（句読点の追加など）、入力済みの文字数ぶんは再入力しない。
      // 食い違った位置から貼り直すと、入力済みの文章が二重に入ってしまう。
      // 文字数の位置ではなく、文の内容で区切る（途中で句読点・数字への置き換えがあっても、前の文の一部が重ならない・欠けない）
      toPaste = newPartAfter(incPasted, trimmed);
    }
    try {
      if (toPaste) await pasteToActiveWindow(toPaste, await targetWindow);
    } catch (e) {
      logPaste(`commit failed: ${String(e)}`);
    }
  }

  status = 'idle';
  updateTray();
  if (trimmed) hideOverlay();
}

/** 音声認識ウィンドウ(Edge)を開く。setup=true のときはインストール案内を前面に */
/** 前回が正常終了でなかった／更新直後は、残っている古い認識ウィンドウを片付けてから開く（この起動で1回だけ判定） */
let engineCleanupChecked = false;
function engineSessionFile(): string {
  return path.join(app.getPath('userData'), 'engine-session.json');
}
function needEngineCleanup(): boolean {
  if (engineCleanupChecked) return false;
  engineCleanupChecked = true;
  let need = true;
  try {
    const prev = JSON.parse(fs.readFileSync(engineSessionFile(), 'utf8')) as {
      version?: string;
      clean?: boolean;
    };
    need = prev.version !== app.getVersion() || prev.clean !== true;
  } catch {
    need = true;
  }
  try {
    fs.writeFileSync(
      engineSessionFile(),
      JSON.stringify({ version: app.getVersion(), clean: false })
    );
  } catch {
    /* 書けなくても動作に影響しない */
  }
  return need;
}

function openEngine(setup: boolean): boolean {
  if (!bridge) return false;
  return openSpeechPage(
    bridge.pageUrl(setup),
    ENGINE_WINDOW_SIZE,
    path.join(app.getPath('userData'), 'engine-browser-profile'),
    needEngineCleanup(),
    !setup // 初回セットアップ以外では、最初から画面の外で起動する
  );
}

let engineWaiting = false;
let engineLaunchedAt = 0;

/**
 * 音声認識の準備（Edge の裏ウィンドウ）がまだのときは、セットアップ画面を出さずに
 * 「準備中…」を表示して、整い次第そのまま音声入力を始める。
 * 初回セットアップが済んでいない場合と、一定時間待っても準備できない場合だけセットアップ画面を出す。
 */
function startListeningWhenReady(): void {
  if (engineWaiting) return;
  engineWaiting = true;
  // 認識ウィンドウが起動していなければ、起動する（起動直後・Edge を閉じてしまったとき）
  if (!engineConnected && Date.now() - engineLaunchedAt > 20_000) {
    engineLaunchedAt = Date.now();
    openEngine(false);
  }
  showOverlay();
  sendOverlayUpdate('音声認識を準備中…');
  const startedAt = Date.now();
  const timer = setInterval(() => {
    if (engineConnected && onDeviceReady) {
      clearInterval(timer);
      engineWaiting = false;
      startListening();
    } else if (Date.now() - startedAt > 30_000) {
      clearInterval(timer);
      engineWaiting = false;
      hideOverlay();
      openSetup(); // 30秒待っても準備できない（言語パック未導入など）ときだけ案内を出す
    }
  }, 300);
}

function startListening(): void {
  if (listening) return;
  if (!engineConnected || !onDeviceReady) {
    if (isSetupComplete()) startListeningWhenReady();
    else openSetup();
    return;
  }
  // 文字を入れたいウィンドウ（今フォーカスがある所）を覚えておく
  // 常駐プロセスで即取得（毎回 PowerShell を起動すると数百ミリ秒かかる）。使えなければ従来方式
  targetWindow = typer.available ? typer.captureForeground() : captureForegroundWindow();
  // ライブ入力（話しながらカーソル位置へ入力）を準備。使えなければ従来どおり最後にまとめて貼り付け
  liveSession = false;
  overlayNote = '';
  pasteOnlySession = false;
  pastedSoFar = '';
  if (pasteTimer) clearTimeout(pasteTimer);
  pasteTimer = null;
  confirmSession = false;
  sessionBehavior = { noFinalPeriod: false, confirm: false, chatNewline: false, label: '' };
  void targetWindow.then(async (hwnd) => {
    if (conversationSession) {
      // 診察会話の記録中は入力しない（終了後に確認画面から入力する）。エコーの入力先は画面を開く前に取得済み
      if (conversationKind !== 'echo') soapTarget = hwnd;
      return;
    }
    // 入力先アプリに合わせた動作（取得できなければ通常どおり）
    // 2つの問い合わせは同時に出す（開始までの待ちを短くする）
    const winClassPromise = typer.windowClass(hwnd);
    const procName = await typer.processName(hwnd);
    const behavior = resolveAppBehavior(procName, settings.appRules);
    if (!listening) return;
    sessionBehavior = behavior;
    if (settings.confirmBeforeInput || behavior.confirm || rewriteStyleActive()) {
      confirmSession = true; // ライブ入力はせず、終了後に確認画面から入力する
      confirmTarget = hwnd;
      return;
    }
    // 以前「文字が入らない」と確認できたアプリは、ライブ入力せず最後にまとめて貼り付ける
    // Qt 製アプリ（LINE・LINE WORKS など）は、1文字ずつのキー入力が文字化け・無反応になるため、最初から貼り付け方式にする
    const winClass = await winClassPromise;
    const qtApp =
      /^Qt\d*QWindowIcon/i.test(winClass) || /^(?:line|wmone|lineworks)$/i.test(procName);
    lastTargetProc = procName;
    lastTargetAuto = qtApp;
    updateTray();
    if (
      qtApp ||
      (procName && settings.pasteOnlyApps.some((n) => n.toLowerCase() === procName.toLowerCase()))
    ) {
      logPaste(`paste-only app: ${procName} ${winClass}`);
      pasteOnlySession = true;
      overlayNote = '話すのを止めると、その文が入力されます';
      sendOverlayUpdate('');
      return;
    }
    typer.newlineShift = behavior.chatNewline;
    const ok = await typer.begin(hwnd, procName);
    if (listening) liveSession = ok;
    logPaste(`live typing begin target=${hwnd} ok=${ok}`);
  });
  listening = true;
  status = 'preparing';
  statusMessage = '準備中…';
  updateTray();
  showOverlay();
  bridge?.emit(IPC.SPEECH_START);
}

function stopListening(): void {
  if (conversationSession && conversationKind === 'echo') sendEchoMic('idle');
  bridge?.emit(IPC.SPEECH_STOP);
  listening = false;
  conversationSession = false;
  confirmSession = false;
  liveSession = false;
  typer.end();
  status = 'idle';
  statusMessage = null;
  updateTray();
  hideOverlay();
}

function flushListening(): void {
  bridge?.emit(IPC.SPEECH_FLUSH);
}

function toggleListening(): void {
  if (listening) {
    flushListening();
  } else {
    startListening();
  }
}

function openSetup(): void {
  if (setupWindow) {
    setupWindow.show();
    setupWindow.focus();
    return;
  }
  setupWindow = createSetupWindow();
}

function registerHotkey(): void {
  globalShortcut.unregisterAll();
  if (!globalShortcut.register(LAUNCHER_HOTKEY, () => void toggleLauncher())) {
    reportHotkeyFailure(LAUNCHER_HOTKEY);
  }
  if (!globalShortcut.register(SCHEDULE_HOTKEY, () => openSchedule())) {
    reportHotkeyFailure(SCHEDULE_HOTKEY);
  }
  if (!globalShortcut.register(TASKS_HOTKEY, () => openList('tasks'))) {
    reportHotkeyFailure(TASKS_HOTKEY);
  }
  if (!globalShortcut.register(BOARD_HOTKEY, () => openBoard())) {
    reportHotkeyFailure(BOARD_HOTKEY);
  }
  if (!globalShortcut.register(MANUAL_HOTKEY, () => openManual())) {
    reportHotkeyFailure(MANUAL_HOTKEY);
  }
  if (!globalShortcut.register(DOCK_HOTKEY, () => toggleDockAndRefresh())) {
    reportHotkeyFailure(DOCK_HOTKEY);
  }
  if (!globalShortcut.register(PDF_HOTKEY, () => openPdfRenamer())) {
    reportHotkeyFailure(PDF_HOTKEY);
  }
  if (!globalShortcut.register(STOCK_HOTKEY, () => openList('stock'))) {
    reportHotkeyFailure(STOCK_HOTKEY);
  }
  if (!globalShortcut.register(SOAP_HOTKEY, () => toggleConversation())) {
    reportHotkeyFailure(SOAP_HOTKEY);
  }
  if (!globalShortcut.register(REPORT_HOTKEY, () => toggleConversation('report'))) {
    reportHotkeyFailure(REPORT_HOTKEY);
  }
  if (!globalShortcut.register(ECHO_HOTKEY, () => toggleEcho())) {
    reportHotkeyFailure(ECHO_HOTKEY);
  }
  if (!globalShortcut.register(CORRECTION_HOTKEY, () => openCorrection())) {
    reportHotkeyFailure(CORRECTION_HOTKEY);
  }
  const ok = globalShortcut.register(HOTKEY, () => toggleListening());
  if (!ok) {
    reportHotkeyFailure(HOTKEY);
  }
}

function registerBridgeHandlers(b: SpeechBridge): void {
  b.on(IPC.SPEECH_STATUS, (payload: { status: SpeechStatus; message?: string }) => {
    // 準備中→聞き取り開始になった瞬間に合図を鳴らす（診察会話の記録中は鳴らさない）
    if (
      settings.readyBeep &&
      status === 'preparing' &&
      payload.status === 'listening' &&
      !conversationSession
    )
      shell.beep();
    // 聞き取り中（準備中を含む）に、入力する文字が無いまま終わった（準備中の中止・無音終了など）:
    // 確定テキストが来ないので、末尾で画面と状態を片付ける（さもないと「準備中」表示が残り続ける）
    const endedWithoutText = payload.status === 'idle' && listening;
    status = payload.status;
    statusMessage = payload.message ?? null;
    if (payload.status === 'listening') {
      listening = true;
      sendOverlayUpdate(lastOverlayText); // 「準備中」→「音声入力中」の表示へ切り替える
    }
    if (payload.status === 'idle' || payload.status === 'error') {
      listening = false;
    }
    if (conversationSession && conversationKind === 'echo') {
      const s = payload.status as string;
      sendEchoMic(
        s === 'listening'
          ? 'listening'
          : s === 'error'
            ? 'error'
            : s === 'idle'
              ? 'idle'
              : 'preparing',
        payload.message
      );
    }
    if (endedWithoutText) {
      if (pasteTimer) clearTimeout(pasteTimer);
      pasteTimer = null;
      pasteOnlySession = false;
      pastedSoFar = '';
      conversationSession = false;
      confirmSession = false;
      liveSession = false;
      typer.end();
      hideOverlay();
    }
    updateTray();
  });

  b.on(IPC.SPEECH_PREVIEW, (payload: { text: string; seq?: number }) => {
    // 並行送信で順序が入れ替わった古い途中結果は捨てる（書き直しの巻き戻りを防ぐ）
    if (typeof payload.seq === 'number') {
      if (payload.seq <= lastPreviewSeq) return;
      lastPreviewSeq = payload.seq;
    }
    const text = removeJapaneseSpaces(payload.text ?? '');
    if (echoMicActive()) {
      // エコー: 話している最中の全文を画面へ（項目の切れ目になる空白を残すため、空白除去前の文章を送る）
      echoWindow?.webContents.send(IPC.ECHO_TEXT, {
        text: (payload.text ?? '').trim(),
        final: false,
      });
    }
    const recording =
      conversationKind === 'report'
        ? '内視鏡の発話を記録中'
        : conversationKind === 'echo'
          ? 'エコーの発話を記録中'
          : '診察会話を記録中';
    sendOverlayUpdate(conversationSession && text ? `【${recording}】${text}` : text);
    // 「ポチラン、〇〇」は文章ではなくボタンの呼び出し。入力せず、話し終えたあとに実行する
    if (/^(?:ぽちらん|ポチラン)/i.test(text.normalize('NFKC'))) return;
    if (listening && liveSession) typer.setDesired(text);
    if (listening && pasteOnlySession) schedulePasteIncrement(text);
  });

  b.on(IPC.SPEECH_MIC_PROGRESS, (payload: { message?: string }) => {
    if (micCheckRunning) sendOverlayUpdate(payload.message ?? '');
  });
  b.on(IPC.SPEECH_MIC_RESULT, onMicResult);

  b.on(IPC.SPEECH_COMMIT, (payload: { text: string }) => {
    void commitText(payload.text ?? '');
  });

  b.on(IPC.SPEECH_LEARN, (payload: { from?: unknown; to?: unknown }) => {
    // 声で直した語を、辞書へ自動で覚える（正が確かな医学用語のときだけ。名前や言い換えは覚えない）
    if (typeof payload?.from !== 'string' || typeof payload?.to !== 'string') return;
    if (!isSafeLearnPair(payload.from, payload.to)) return;
    try {
      appendDictionaryEntries([`${payload.from.trim()}→${payload.to.trim()}`]);
      void contributePairs([{ from: payload.from, to: payload.to }]);
    } catch (e) {
      logPaste(`voice learn failed: ${String(e)}`);
    }
  });
  b.on(IPC.SPEECH_ERROR, (payload: { code: string; message: string }) => {
    if (conversationSession && conversationKind === 'echo') sendEchoMic('error', payload.message);
    listening = false;
    conversationSession = false;
    confirmSession = false;
    liveSession = false;
    typer.end();
    status = 'error';
    statusMessage = payload.message;
    updateTray();
    hideOverlay();
  });

  b.on(IPC.SPEECH_READY_RESULT, (payload: { ok: boolean; status: string; mic?: string }) => {
    onDeviceReady = payload.ok;
    lastReadyStatus = payload.status ?? '';
    lastMic = payload.mic ?? '';
    if (payload.ok) {
      const firstTime = !isSetupComplete();
      if (firstTime) markSetupComplete();
      // 初回だけ準備完了を見せる。2回目以降はすぐ裏へ隠す（音声認識の窓を目に触れさせない）
      setTimeout(
        () => {
          if (onDeviceReady) minimizeSpeechWindow();
        },
        firstTime ? 2500 : 300
      );
    }
    notifySetup();
  });

  b.onConnection((connected) => {
    engineConnected = connected;
    if (!connected) {
      onDeviceReady = false;
      listening = false;
      hideOverlay();
      updateTray();
    }
    notifySetup();
  });
}

function registerIpc(): void {
  ipcMain.on(IPC.LAUNCHER_INSERT, (_e, p: { id: string; inputs: Record<string, string> }) => {
    void insertSnippet(
      String(p?.id ?? ''),
      p?.inputs && typeof p.inputs === 'object' ? p.inputs : {}
    );
  });
  ipcMain.on(IPC.LAUNCHER_CLOSE, () => launcherWindow?.hide());
  ipcMain.handle(IPC.EDITOR_LOAD, () => loadSnippets());
  ipcMain.handle(IPC.EDITOR_SAVE, (_e, list: unknown) => {
    const problem = validateSnippets(list);
    if (problem) return { ok: false, error: problem };
    saveSnippets(list as Snippet[]);
    if (watcher.running) watcher.setTriggers(snippetTriggers());
    return { ok: true };
  });
  ipcMain.handle(IPC.EDITOR_OPEN_FILE, () => openSnippetFile());
  ipcMain.handle(IPC.EDITOR_INLINE_GET, () =>
    process.platform === 'win32' ? settings.inlineTriggers : null
  );
  ipcMain.handle(IPC.EDITOR_INLINE_SET, (_e, enabled: unknown) => {
    settings = { ...settings, inlineTriggers: enabled === true };
    saveSettings(settings);
    syncTriggerWatcher();
    updateTray();
  });
  ipcMain.handle(IPC.CORRECTION_SAVE, async (_e, lines: unknown, toShared?: unknown) => {
    const list = Array.isArray(lines)
      ? lines.filter((l): l is string => typeof l === 'string')
      : [];
    try {
      const added = appendDictionaryEntries(list);
      // みんなの辞書への提出（任意）: 正が確かな医学用語の組だけ
      void contributePairs(
        list
          .map((l) => l.split('→'))
          .filter((p) => p.length === 2)
          .map((p) => ({ from: p[0], to: p[1] }))
      );
      // 院内の共有辞書にも登録（共有フォルダを設定していて、チェックが入っているとき）
      if (toShared === true && hasSharedFolder()) await appendSharedDictionary(list);
      return { ok: true, added };
    } catch (e) {
      logPaste(`dictionary append failed: ${String(e)}`);
      return { ok: false, added: 0 };
    }
  });
  ipcMain.on(IPC.CORRECTION_CLOSE, () => correctionWindow?.close());

  ipcMain.handle(IPC.SOAP_INSERT, async (_e, text: unknown) => {
    const value = typeof text === 'string' ? text : '';
    if (!value.trim()) return { ok: false };
    soapWindow?.close(); // 入力先に操作を戻す
    await new Promise((r) => setTimeout(r, 200));
    try {
      await pasteToActiveWindow(value, soapTarget, { raw: true });
      return { ok: true };
    } catch (e) {
      logPaste(`soap insert failed: ${String(e)}`);
      return { ok: false };
    }
  });
  ipcMain.on(IPC.SOAP_CLOSE, () => soapWindow?.close());

  ipcMain.handle(IPC.REPORT_INSERT, async (_e, text: unknown) => {
    const value = typeof text === 'string' ? text : '';
    if (!value.trim()) return { ok: false };
    reportWindow?.close(); // 入力先に操作を戻す
    await new Promise((r) => setTimeout(r, 200));
    try {
      await pasteToActiveWindow(value, soapTarget, { raw: true });
      return { ok: true };
    } catch (e) {
      logPaste(`report insert failed: ${String(e)}`);
      return { ok: false };
    }
  });
  ipcMain.on(IPC.REPORT_CLOSE, () => reportWindow?.close());

  ipcMain.handle(IPC.ECHO_INSERT, async (_e, text: unknown) => {
    const value = typeof text === 'string' ? text : '';
    if (!value.trim()) return { ok: false };
    echoWindow?.close(); // 入力先に操作を戻す（録音中なら止まる）
    await new Promise((r) => setTimeout(r, 200));
    try {
      await pasteToActiveWindow(value, echoTarget, { raw: true });
      return { ok: true };
    } catch (e) {
      logPaste(`echo insert failed: ${String(e)}`);
      return { ok: false };
    }
  });
  ipcMain.on(IPC.ECHO_CLOSE, () => echoWindow?.close());
  ipcMain.handle(IPC.ECHO_MIC_TOGGLE, () => {
    if (echoMicActive()) flushListening();
    else if (!listening) startEchoMic();
  });
  ipcMain.handle(IPC.ECHO_POLISH, async (_e, items: unknown) => {
    if (!Array.isArray(items)) return {};
    const list: PolishItem[] = [];
    for (const i of items) {
      if (
        i &&
        typeof i.id === 'string' &&
        typeof i.label === 'string' &&
        typeof i.spoken === 'string'
      ) {
        list.push({ id: i.id, label: i.label, spoken: i.spoken.slice(0, 600) });
      }
    }
    return polishAbdomen(list);
  });

  ipcMain.handle(IPC.CONFIRM_INSERT, async (_e, text: unknown) => {
    const value = typeof text === 'string' ? text : '';
    if (!value.trim()) return { ok: false };
    confirmWindow?.close(); // 入力先に操作を戻す
    await new Promise((r) => setTimeout(r, 200));
    try {
      await pasteToActiveWindow(value, confirmTarget, { raw: true });
      return { ok: true };
    } catch (e) {
      logPaste(`confirm insert failed: ${String(e)}`);
      return { ok: false };
    }
  });
  ipcMain.on(IPC.CONFIRM_CLOSE, () => confirmWindow?.close());
  ipcMain.handle(IPC.APP_GET_STATE, () => appState());

  // 契約状態の確認（販売開始までは動かない）。1日の間隔・失敗時の待ちは contractSync 側で守る
  if (CONTRACT_SYNC_ENABLED) {
    void contractSync().sync();
    setInterval(() => void contractSync().sync(), 30 * 60 * 1000);
  }
  ipcMain.handle(IPC.HOME_STATE, () => ({
    version: app.getVersion(),
    listening,
    dockVisible: isDockVisible(),
    termCount: (() => {
      const d = loadTermFolder();
      return d.terms.length + d.pairs.length;
    })(),
    update: getUpdateStatus().state,
    updateVersion: getUpdateStatus().version,
    contracted: contractedAppIds(),
    linkEnabled: CONTRACT_SYNC_ENABLED,
    linked: CONTRACT_SYNC_ENABLED ? contractSync().isLinked() : false,
    licenseNotice: (() => {
      if (CONTRACT_SYNC_ENABLED) {
        const v = contractSync().view();
        if (v)
          return v.notice.level === 'ok'
            ? null
            : { level: v.notice.level, text: noticeText(v.notice) };
      }
      if (!LICENSE_ENFORCED) return null;
      const n = currentLicenseNotice();
      return n.level === 'ok' ? null : { level: n.level, text: noticeText(n) };
    })(),
  }));
  // ---- ホーム画面の「設定」で、音声入力などの設定をその場で変える ----
  const homeSettings = () => ({
    taskRemind: getRemindPrefs(),
    specialty: settings.specialty,
    specialties: SPECIALTIES.map((s) => ({ id: s.id, label: s.label })),
    medicalTerms: settings.medicalTerms,
    autoStart: settings.autoStart,
    autoUpdate: settings.autoUpdate,
    typeInBackground: settings.typeInBackground,
    typeHopCompat: settings.typeHopCompat,
    inlineTriggers: settings.inlineTriggers,
    showListeningText: settings.showListeningText,
    confirmBeforeInput: settings.confirmBeforeInput,
    readyBeep: settings.readyBeep,
    warmMic: settings.warmMic,
    pausePunct: settings.pausePunct,
    useGlobalDict: settings.useGlobalDict,
    voiceAi: voiceAiChoice(),
    voiceAiStatus: voiceAiStatusText(),
    voiceAiLast: describeAiRun(lastAiRun()),
    voiceAiCard: voiceAiCard(),
    aiChatUrl: settings.aiChatUrl,
    soapDirect: settings.soapDirect,
    soapFormat: settings.soapFormat,
  });
  ipcMain.handle(IPC.HOME_SETTINGS_GET, () => homeSettings());
  ipcMain.handle(IPC.HOME_SETTINGS_SET, async (_e, key: unknown, value: unknown) => {
    if (key === 'voiceAi') {
      if (value === 'test') {
        // 架空の文章で、いまの設定のとおりにAIを実行して結果を見せる（患者さんの文章は使わない）
        const st = activeVoiceStyle() ?? 'plain';
        // 毎回違う架空の文章を使う（その都度AIが直していることが分かるように）
        const sample = pickVoiceAiSample(lastVoiceAiSample);
        lastVoiceAiSample = sample;
        if (st === 'plain') {
          // 通常の校正は、実際の音声入力と同じ処理で実行し、変わった箇所を見せる（変化が小さくても分かるように）
          const d = await proofreadDetailed(sample, voiceAiHints(), 12_000, '', 'test');
          recordAiRun({
            kind: 'test',
            status: d.status,
            reason: d.reason,
            ms: d.ms,
            changes: d.status === 'ok' ? d.changes.length : undefined,
            code: d.code,
            requestId: d.requestId,
          });
          return {
            ...homeSettings(),
            voiceAiTestIn: sample,
            voiceAiTestOut: d.status === 'ok' ? d.after : '',
            voiceAiTestChanges: d.changes.map((c) => describeChange(sample, d.after, c)),
            voiceAiTestNote: d.reason,
          };
        }
        const r = await applyVoiceStyle(sample, st, voiceAiHints(), '', 'test');
        return {
          ...homeSettings(),
          voiceAiTestIn: sample,
          voiceAiTestOut: r.applied ? r.text : '',
        };
      }
      if (
        value === 'off' ||
        value === 'live' ||
        value === 'learn' ||
        value === 'chart' ||
        value === 'soap'
      ) {
        if (value === 'off') {
          setVoiceSetting({ voiceAiMode: 'off', aiProofread: false, aiProofreadLive: false });
        } else if (value === 'chart' || value === 'soap') {
          // カルテ文体・SOAPは院内AIだけ（院外AIへは切り替えない）
          setVoiceSetting({
            voiceAiMode: 'local',
            aiVoiceStyle: value,
            aiProofread: false,
            aiProofreadLive: false,
          });
        } else {
          // AI設定の接続先が院内（このPC・院内LAN）なら院内AI、そうでなければ院外AI（外部送信の確認つき）
          await selectVoiceAiMode(isLocalUrl(loadAi().baseUrl) ? 'local' : 'cloud');
          if (settings.voiceAiMode !== 'off') {
            setVoiceSetting({
              aiVoiceStyle: 'plain',
              aiProofreadLive: value === 'live',
              aiProofread: true,
            });
          }
        }
      }
      return homeSettings();
    }
    if (key === 'taskRemind') {
      setRemindPrefs(value);
      return homeSettings();
    }
    if (key === 'soapFormat') {
      settings = { ...settings, soapFormat: sanitizeSoapFormat(value) };
      saveSettings(settings);
      return homeSettings();
    }
    if (key === 'aiChatUrl') {
      const url = normalizeChatUrl(value);
      if (url) {
        settings = { ...settings, aiChatUrl: url };
        saveSettings(settings);
      }
      return homeSettings();
    }
    if (key === 'specialty') {
      if (SPECIALTIES.some((s) => s.id === value)) {
        settings = { ...settings, specialty: value as AppSettings['specialty'] };
        saveSettings(settings);
        updateTray();
      }
      return homeSettings();
    }
    if (typeof value !== 'boolean') return homeSettings();
    const on = value;
    switch (key) {
      case 'autoStart':
        settings = { ...settings, autoStart: on };
        saveSettings(settings);
        applyAutoStart(on);
        updateTray();
        break;
      case 'autoUpdate':
        settings = { ...settings, autoUpdate: on };
        saveSettings(settings);
        setAutoUpdate(on);
        updateTray();
        break;
      case 'typeInBackground':
        settings = { ...settings, typeInBackground: on };
        saveSettings(settings);
        typer.background = on;
        updateTray();
        break;
      case 'typeHopCompat':
        settings = { ...settings, typeHopCompat: on };
        saveSettings(settings);
        typer.hop = on;
        updateTray();
        break;
      case 'inlineTriggers':
        settings = { ...settings, inlineTriggers: on };
        saveSettings(settings);
        syncTriggerWatcher();
        updateTray();
        break;
      case 'readyBeep':
      case 'warmMic':
      case 'pausePunct':
      case 'useGlobalDict':
        setVoiceSetting({ [key]: on } as Partial<AppSettings>);
        break;
      case 'medicalTerms':
      case 'showListeningText':
      case 'soapDirect':
      case 'confirmBeforeInput':
        settings = { ...settings, [key]: on };
        saveSettings(settings);
        updateTray();
        break;
    }
    return homeSettings();
  });
  ipcMain.handle(IPC.HOME_DICT_GET, () => readDictionaryText());
  ipcMain.handle(IPC.HOME_DICT_SET, (_e, text: unknown) => {
    if (typeof text !== 'string' || text.length > 500_000) return false;
    writeDictionaryText(text);
    return true;
  });
  // ---- 契約のひも付け（メールに届く確認コード）。販売開始までは画面も出ない ----
  const deviceIdentity = (): string => {
    const f = path.join(app.getPath('userData'), 'chokotto-device-id');
    try {
      const v = fs.readFileSync(f, 'utf-8').trim();
      if (/^[A-Za-z0-9_-]{8,64}$/.test(v)) return v;
    } catch {
      /* 初回 */
    }
    const id = randomUUID().replace(/-/g, '');
    try {
      fs.writeFileSync(f, id, 'utf-8');
    } catch {
      /* 書けなくても今回は動かす */
    }
    return id;
  };
  const linkOk = (v: unknown, max: number): v is string =>
    typeof v === 'string' && v.length > 0 && v.length <= max;
  ipcMain.handle(IPC.LINK_REQUEST, async (_e, email: unknown) => {
    if (!CONTRACT_SYNC_ENABLED || !linkOk(email, 254)) return { ok: false, error: 'invalid' };
    return contractSync().requestOtp(email);
  });
  ipcMain.handle(IPC.LINK_VERIFY, async (_e, email: unknown, code: unknown) => {
    if (!CONTRACT_SYNC_ENABLED || !linkOk(email, 254) || !linkOk(code, 12))
      return { ok: false, error: 'invalid' };
    const r = await contractSync().verify(
      email,
      code,
      deviceIdentity(),
      os.hostname().slice(0, 60)
    );
    if (r.ok) void contractSync().sync();
    return r;
  });
  ipcMain.handle(IPC.BUY_CATALOG, async () => {
    if (!CONTRACT_SYNC_ENABLED) return { ok: false, forSale: false, prices: {} };
    return contractSync().catalog();
  });
  ipcMain.handle(IPC.BUY_PURCHASE, async (_e, email: unknown, pin: unknown, appIds: unknown) => {
    if (!CONTRACT_SYNC_ENABLED || !linkOk(email, 254) || !linkOk(pin, 6))
      return { ok: false, error: 'invalid' };
    if (
      !Array.isArray(appIds) ||
      appIds.length === 0 ||
      appIds.length > 10 ||
      !appIds.every((x) => linkOk(x, 31))
    )
      return { ok: false, error: 'invalid' };
    const r = await contractSync().purchase(email, pin, appIds as string[]);
    if (r.ok && contractSync().isLinked()) void contractSync().sync();
    return r;
  });
  ipcMain.handle(IPC.LINK_UNLINK, () => {
    if (!CONTRACT_SYNC_ENABLED) return false;
    contractSync().unlink();
    return true;
  });
  ipcMain.handle(IPC.HOME_OPEN_URL, (_e, url: unknown) => {
    if (typeof url !== 'string' || !/^https:\/\/meditoku\.com\//.test(url)) return false;
    void shell.openExternal(url);
    return true;
  });
  initHomeEmbed({
    getHome: () => homeWindow,
    rendererPath,
    preloadPath: path.join(__dirname, 'preload.js'),
    open: runHomeAction,
  });
  ipcMain.on(IPC.VOICE_START, () => {
    if (!listening) startListening();
  });
  ipcMain.handle(IPC.HOME_RUN, (_e, id: string) =>
    String(id) === 'update' ? runUpdateAction() : runHomeAction(String(id))
  );

  ipcMain.on(IPC.APP_RESIZE_SETUP, (_e, height: number) => {
    if (!setupWindow || !Number.isFinite(height)) return;
    const h = Math.max(200, Math.min(700, Math.round(height)));
    setupWindow.setContentSize(520, h);
  });

  // セットアップ画面 → 音声認識ウィンドウ(Edge)のインストール画面へ
  ipcMain.handle(IPC.APP_OPEN_ENGINE, () => {
    if (bridge?.connected) {
      bridge.emit(IPC.SPEECH_CHECK_READY);
    }
    return openEngine(true);
  });
}

app.whenReady().then(async () => {
  overlayWindow = createOverlayWindow();
  launcherWindow = createLauncherWindow();

  settings = loadSettings();
  applyLearningSettings();
  startGlobalDictRefresh();
  // PC を起動したら自動で立ち上がる（トレイのメニューでいつでも OFF にできる）
  applyAutoStart(settings.autoStart);
  typer.background = settings.typeInBackground;
  typer.hop = settings.typeHopCompat;
  setSharedFolder(settings.sharedFolder);
  startSharedRefresh();
  // 署名つきの院内共有辞書（設定されているときだけ。共有先が止まっていても、検証済みのキャッシュで動く）
  initDictAdmin({
    get: () => ({
      dictShareFolder: settings.dictShareFolder,
      dictSharePublicKey: settings.dictSharePublicKey,
      sharedFolder: settings.sharedFolder,
    }),
    set: (patch) => {
      settings = { ...settings, ...patch };
      saveSettings(settings);
    },
  });
  applyDictShare();
  tray = createAppTray(null, trayOptions());
  tray.setImage(createTrayIcon());

  registerIpc();
  initModules();
  // 各ポップアップを隠したまま先に読み込んでおく（アイコンを押した瞬間に開くため。起動を遅くしないよう少し待つ）
  setTimeout(() => {
    warmUpLists();
    warmUpBoard();
    warmUpManual();
    warmUpSchedule();
    warmUpPdfRenamer();
  }, 4000);
  initUpdater(() => updateTray(), settings.autoUpdate);
  registerHotkey();
  typer.warmUp();
  syncTriggerWatcher();
  // スリープ復帰・ロック解除のあとは、呼び名の監視を作り直す（フックが外れていても動くように）
  const restartWatcher = (): void => {
    if (settings.inlineTriggers) setTimeout(() => watcher.restart(snippetTriggers()), 1500);
  };
  powerMonitor.on('resume', restartWatcher);
  powerMonitor.on('unlock-screen', restartWatcher);
  // スニペット.txt をメモ帳などで直接編集した場合も、呼び名の一覧を更新する
  fs.watchFile(snippetFilePath(), { interval: 3000 }, () => {
    if (watcher.running) watcher.setTriggers(snippetTriggers());
  });

  ensureTermFolder(); // 専門用語フォルダを用意（使い方の説明ファイル入り）
  bridge = new SpeechBridge(rendererDir());
  // 認識ウィンドウは音声入力の開始ごとにここから最新の設定・辞書を取得する
  bridge.setConfigProvider(() => {
    void refreshShared(); // 院内共有の辞書・スニペットの最新版を裏で読む（待たない。次回の入力から反映）
    return {
      dictionary: loadDictionary(),
      specialty: settings.specialty,
      medicalTerms: settings.medicalTerms,
      snippetNames: loadAllSnippets().map((s) => s.name),
      warmMic: settings.warmMic,
      // 専門用語フォルダの用語（認識エンジンに優先して聞き取らせる）
      terms: loadTermFolder().terms,
      pausePunct: settings.pausePunct,
    };
  });
  // 「定型 ○○」の音声コマンド用: 変数を展開した定型文を返す。
  // 音声では入力欄に答えられないので、{input:…} {choice:…} は【ラベル】の目印にして、あとで直せるようにする
  bridge.setSnippetProvider((name) => {
    const snippet = loadAllSnippets().find((s) => s.name === name);
    if (!snippet) return null;
    const inputs: Record<string, string> = {};
    const library = loadAllSnippets();
    for (const p of extractPrompts(snippet.text, library)) inputs[p.label] = `【${p.label}】`;
    return expandSnippet(snippet.text, {
      now: new Date(),
      clipboard: clipboard.readText(),
      inputs,
      library,
    }).text;
  });
  registerBridgeHandlers(bridge);
  try {
    await bridge.start();
  } catch (e) {
    console.error(e);
    openSetup();
    return;
  }

  // 手動で起動したときはホーム画面を開く（PC起動時の自動開始 --hidden のときは常駐のみ）
  if (!process.argv.includes('--hidden')) openHome();

  // 音声認識エンジン（Edge/Chrome のアプリウィンドウ）を起動
  engineLaunchedAt = Date.now();
  openEngine(!isSetupComplete());
  if (!isSetupComplete()) {
    openSetup();
  }
});

app.on('will-quit', () => {
  stopLanShare();
  stopDeckWeb();
  stopDeckWatch();
  watcher.stop();
  stopSharedRefresh();
  disposeSchedule();
  disposeUpdater();
  disposePdfRenamer();
  typer.dispose();
  closeEngineBrowsers(path.join(app.getPath('userData'), 'engine-browser-profile'));
  try {
    fs.writeFileSync(
      engineSessionFile(),
      JSON.stringify({ version: app.getVersion(), clean: true })
    );
  } catch {
    /* ignore */
  }
  globalShortcut.unregisterAll();
  bridge?.stop();
});

app.on('window-all-closed', () => {
  // トレイ常駐のため終了しない
});

app.on('second-instance', () => {
  // ショートカットからもう一度起動されたら、ホームとドックを前面に出す
  openHome();
  showDock();
  updateTray();
});
