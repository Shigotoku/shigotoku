import { app, clipboard } from 'electron';
import { execFile } from 'child_process';
import fs from 'fs';
import path from 'path';
import { promisify } from 'util';

const execFileAsync = promisify(execFile);

const WIN32_TYPES = `
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class ChokottoWin {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool attach);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vk);
}
"@
`;

export function logPaste(message: string): void {
  try {
    const file = path.join(app.getPath('userData'), 'paste.log');
    fs.appendFileSync(file, `${new Date().toISOString()} ${message}\n`, 'utf-8');
  } catch {
    /* ログ失敗は無視 */
  }
}

function runPowerShell(script: string): Promise<string> {
  const encoded = Buffer.from(script, 'utf16le').toString('base64');
  return execFileAsync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-EncodedCommand', encoded],
    // 黒いコンソール窓がフォーカスを奪わないようにする
    { windowsHide: true, timeout: 8000 }
  ).then((r) => r.stdout.trim());
}

/**
 * 音声入力を開始した時点で、文字を入れたいウィンドウ（フォーカス中のウィンドウ）を覚えておく。
 * 戻り値は HWND（取得できなければ 0）。
 */
export async function captureForegroundWindow(): Promise<number> {
  if (process.platform !== 'win32') return 0;
  try {
    // 音声認識ウィンドウ自身（Chrome）や本アプリのウィンドウは貼り付け先にしない
    const out = await runPowerShell(`${WIN32_TYPES}
$h = [ChokottoWin]::GetForegroundWindow()
$p = Get-Process | Where-Object { $_.MainWindowHandle -eq $h } | Select-Object -First 1
if ($p -and $p.MainWindowTitle -like '*ちょこっと*') { 0 } else { $h.ToInt64() }`);
    const hwnd = Number(out);
    return Number.isFinite(hwnd) ? hwnd : 0;
  } catch (e) {
    logPaste(`captureForegroundWindow failed: ${String(e)}`);
    return 0;
  }
}

/**
 * 認識テキストを、音声入力開始時にフォーカスしていたウィンドウへ貼り付ける。
 * - 元のウィンドウを前面に戻してから Ctrl+V（Chrome 側などにフォーカスが移っていても入力できる）
 * - 押しっぱなしの Shift/Alt を離してから送る（Ctrl+Shift+V にならないように）
 */
export interface PasteOptions {
  /** true なら前後の空白・改行を削らずそのまま貼る（定型文用） */
  raw?: boolean;
  /** 貼り付け後にカーソルを左へ戻す文字数（定型文の {cursor}） */
  caretBack?: number;
}

/**
 * 常駐プロセスによる高速な貼り付け（毎回 PowerShell を起動しないので数百ミリ秒速い）。
 * 結果は 'ok' / 'nofocus'。使えないときは null を返し、従来の方式にフォールバックする。
 */
type FastPaster = (targetHwnd: number, caretBack: number) => Promise<string | null>;
let fastPaster: FastPaster | null = null;
export function setFastPaster(fn: FastPaster | null): void {
  fastPaster = fn;
}

/** 貼り付けできなかったとき（入力先に戻れない等）に呼ばれる。文章はクリップボードに残してある */
let pasteFailedHandler: ((text: string) => void) | null = null;
export function setPasteFailedHandler(fn: ((text: string) => void) | null): void {
  pasteFailedHandler = fn;
}
export async function pasteToActiveWindow(
  text: string,
  targetHwnd = 0,
  options: PasteOptions = {}
): Promise<void> {
  const trimmed = options.raw ? text : text.trim();
  if (!trimmed) return;
  const caretBack = Math.max(0, Math.min(500, Math.floor(options.caretBack ?? 0)));

  const previous = clipboard.readText();
  clipboard.writeText(trimmed);

  if (fastPaster && process.platform === 'win32') {
    const t0 = Date.now();
    const r = await fastPaster(targetHwnd, caretBack);
    if (r !== null) {
      logPaste(
        `paste(fast) target=${targetHwnd} chars=${trimmed.length} result=${r} ms=${Date.now() - t0}`
      );
      if (r === 'ok') {
        // 貼り付け先が読み取り終わってから、元のクリップボードを戻す（待たずに呼び出し元へ戻る）
        setTimeout(() => clipboard.writeText(previous), 400);
      } else {
        pasteFailedHandler?.(trimmed); // 文章はクリップボードに残す
      }
      return;
    }
  }
  await delay(100);

  try {
    if (process.platform === 'win32') {
      const script = `${WIN32_TYPES}
$h = [IntPtr]${targetHwnd}
if ($h -ne [IntPtr]::Zero -and [ChokottoWin]::IsWindow($h)) {
  if ([ChokottoWin]::IsIconic($h)) { [ChokottoWin]::ShowWindow($h, 9) | Out-Null }
  if ([ChokottoWin]::GetForegroundWindow() -ne $h) {
    # 現在の前面ウィンドウのスレッドに入力を接続すると、バックグラウンドからでも前面化できる
    $pid0 = [uint32]0
    $fg = [ChokottoWin]::GetForegroundWindow()
    $fgThread = [ChokottoWin]::GetWindowThreadProcessId($fg, [ref]$pid0)
    $me = [ChokottoWin]::GetCurrentThreadId()
    [ChokottoWin]::AttachThreadInput($me, $fgThread, $true) | Out-Null
    [ChokottoWin]::BringWindowToTop($h) | Out-Null
    [ChokottoWin]::SetForegroundWindow($h) | Out-Null
    [ChokottoWin]::AttachThreadInput($me, $fgThread, $false) | Out-Null
    Start-Sleep -Milliseconds 250
  }
  # 元のウィンドウに戻せなかったら、別の窓へ誤って貼らないよう中止する
  if ([ChokottoWin]::GetForegroundWindow() -ne $h) { "nofocus"; exit }
}
# 修飾キーを離す: Shift(0x10) Alt(0x12) / 0x0002 = KEYUP
# 押されているときだけ離す（押していない Alt の KEYUP は Outlook/Office のリボンキーヒントを開いてしまう）
if (([ChokottoWin]::GetAsyncKeyState(0x10) -band 0x8000) -ne 0) { [ChokottoWin]::keybd_event(0x10, 0, 2, [UIntPtr]::Zero) }
if (([ChokottoWin]::GetAsyncKeyState(0x12) -band 0x8000) -ne 0) { [ChokottoWin]::keybd_event(0x12, 0, 2, [UIntPtr]::Zero) }
[ChokottoWin]::keybd_event(0x11, 0, 0, [UIntPtr]::Zero)  # Ctrl down
[ChokottoWin]::keybd_event(0x56, 0, 0, [UIntPtr]::Zero)  # V down
[ChokottoWin]::keybd_event(0x56, 0, 2, [UIntPtr]::Zero)  # V up
[ChokottoWin]::keybd_event(0x11, 0, 2, [UIntPtr]::Zero)  # Ctrl up
${
  caretBack > 0
    ? `Start-Sleep -Milliseconds 180
for ($i = 0; $i -lt ${caretBack}; $i++) {
  [ChokottoWin]::keybd_event(0x25, 0, 0, [UIntPtr]::Zero)  # Left down
  [ChokottoWin]::keybd_event(0x25, 0, 2, [UIntPtr]::Zero)  # Left up
  Start-Sleep -Milliseconds 4
}`
    : ''
}
"ok"
`;
      const out = await runPowerShell(script);
      logPaste(`paste target=${targetHwnd} chars=${trimmed.length} result=${out}`);
      if (out.includes('nofocus')) {
        pasteFailedHandler?.(trimmed);
        // 貼り付け先に戻せなかった: テキストはクリップボードに残す（手動で Ctrl+V できる）
        return;
      }
    } else if (process.platform === 'darwin') {
      await execFileAsync('osascript', [
        '-e',
        'tell application "System Events" to keystroke "v" using command down',
      ]);
      if (caretBack > 0) {
        await delay(180);
        await execFileAsync('osascript', [
          '-e',
          `tell application "System Events"\nrepeat ${caretBack} times\nkey code 123\nend repeat\nend tell`,
        ]);
      }
    } else {
      await execFileAsync('xdotool', ['key', 'ctrl+v']);
    }
  } catch (e) {
    logPaste(`paste FAILED target=${targetHwnd}: ${String(e)}`);
    throw e;
  }

  // 貼り付け先アプリが読み取り終えるまで待ってから、元のクリップボードを戻す
  await delay(500);
  clipboard.writeText(previous);
}

/** ショートカットキーを、今フォーカスしているウィンドウへ送る（押す順に渡す。離すときは逆順） */
export async function sendKeyChord(vks: number[]): Promise<void> {
  if (process.platform !== 'win32' || vks.length === 0) return;
  const down = vks.map((v) => `[ChokottoWin]::keybd_event(${v}, 0, 0, [UIntPtr]::Zero)`).join('\n');
  const up = [...vks]
    .reverse()
    .map((v) => `[ChokottoWin]::keybd_event(${v}, 0, 2, [UIntPtr]::Zero)`)
    .join('\n');
  await runPowerShell(`${WIN32_TYPES}\n${down}\nStart-Sleep -Milliseconds 40\n${up}\n"ok"`);
}

/** ウィンドウのタイトル、またはアプリ名に含まれる文字で開いているアプリがあるか */
export async function windowOpen(name: string): Promise<boolean> {
  if (process.platform !== 'win32') return false;
  const b64 = Buffer.from(name.trim(), 'utf8').toString('base64');
  const out =
    await runPowerShell(`$n = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${b64}'))
$p = Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and ($_.MainWindowTitle -like "*$n*" -or $_.ProcessName -like "*$n*") -and $_.MainWindowTitle -notlike '*ちょこっと*' } | Select-Object -First 1
if ($p) { 'yes' } else { 'no' }`);
  return out.includes('yes');
}

/** ウィンドウのタイトル、またはアプリ名に含まれる文字で探して、前に出す。見つからなければ false */
export async function focusWindowByName(name: string): Promise<boolean> {
  if (process.platform !== 'win32') return false;
  const b64 = Buffer.from(name.trim(), 'utf8').toString('base64');
  const out = await runPowerShell(`${WIN32_TYPES}
$n = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${b64}'))
$p = Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and ($_.MainWindowTitle -like "*$n*" -or $_.ProcessName -like "*$n*") -and $_.MainWindowTitle -notlike '*ちょこっと*' } | Select-Object -First 1
if (-not $p) { "notfound"; exit }
$h = $p.MainWindowHandle
if ([ChokottoWin]::IsIconic($h)) { [ChokottoWin]::ShowWindow($h, 9) | Out-Null }
$pid0 = [uint32]0
$fg = [ChokottoWin]::GetForegroundWindow()
$fgThread = [ChokottoWin]::GetWindowThreadProcessId($fg, [ref]$pid0)
$me = [ChokottoWin]::GetCurrentThreadId()
[ChokottoWin]::AttachThreadInput($me, $fgThread, $true) | Out-Null
[ChokottoWin]::BringWindowToTop($h) | Out-Null
[ChokottoWin]::SetForegroundWindow($h) | Out-Null
[ChokottoWin]::AttachThreadInput($me, $fgThread, $false) | Out-Null
"ok"`);
  return out.includes('ok');
}
function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
