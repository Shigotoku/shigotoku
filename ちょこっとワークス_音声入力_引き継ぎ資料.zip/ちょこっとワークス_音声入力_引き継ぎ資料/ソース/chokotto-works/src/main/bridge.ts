import http from 'http';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { spawn, execFile } from 'child_process';

/**
 * Edge(Chrome) で動く音声認識ページとの橋渡し。
 * Electron 内蔵ブラウザは日本語オンデバイス音声パックを導入できないため、
 * 認識エンジン本体は Edge の「アプリウィンドウ」で動かす（127.0.0.1 のみ待受）。
 */

const BASE_PORT = 47821;
const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
};

export const PAGE_TITLE = 'ちょこっとワークス - 音声認識エンジン';

type Handler = (payload: any) => void;

export class SpeechBridge {
  readonly token = crypto.randomBytes(16).toString('hex');
  port = 0;
  private server: http.Server | null = null;
  private clients = new Set<http.ServerResponse>();
  private handlers = new Map<string, Handler>();
  private onConnectionChange: (connected: boolean) => void = () => {};

  private configProvider: () => unknown = () => ({});
  private snippetProvider: (name: string) => string | null = () => null;

  constructor(private rendererDir: string) {}

  /** 音声の「定型 ○○」で挿入する定型文（変数展開済み）の提供元。無ければ null */
  setSnippetProvider(fn: (name: string) => string | null): void {
    this.snippetProvider = fn;
  }

  /** 認識ウィンドウへ渡す設定（ユーザー辞書・診療科など）の提供元 */
  setConfigProvider(fn: () => unknown): void {
    this.configProvider = fn;
  }

  get connected(): boolean {
    return this.clients.size > 0;
  }

  on(channel: string, handler: Handler): void {
    this.handlers.set(channel, handler);
  }

  onConnection(cb: (connected: boolean) => void): void {
    this.onConnectionChange = cb;
  }

  emit(channel: string, payload?: unknown): void {
    const data = `data: ${JSON.stringify({ channel, payload })}\n\n`;
    for (const res of this.clients) res.write(data);
  }

  pageUrl(setup: boolean): string {
    return `http://127.0.0.1:${this.port}/index.html?t=${this.token}${setup ? '&setup=1' : ''}`;
  }

  async start(): Promise<void> {
    for (let i = 0; i < 10; i++) {
      const port = BASE_PORT + i;
      try {
        await this.listen(port);
        this.port = port;
        return;
      } catch {
        /* 次のポートへ */
      }
    }
    throw new Error('ブリッジ用のポートを確保できませんでした');
  }

  private listen(port: number): Promise<void> {
    return new Promise((resolve, reject) => {
      const server = http.createServer((req, res) => this.handle(req, res));
      server.once('error', reject);
      server.listen(port, '127.0.0.1', () => {
        this.server = server;
        resolve();
      });
    });
  }

  private handle(req: http.IncomingMessage, res: http.ServerResponse): void {
    const url = new URL(req.url ?? '/', 'http://127.0.0.1');

    if (url.pathname.startsWith('/api/')) {
      if (url.searchParams.get('t') !== this.token) {
        res.writeHead(403).end();
        return;
      }
      if (url.pathname === '/api/events' && req.method === 'GET') {
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          Connection: 'keep-alive',
        });
        res.write(': connected\n\n');
        // 新しいページが接続したら古いページは閉じる
        this.emit('replaced');
        for (const old of this.clients) old.end();
        this.clients.clear();
        this.clients.add(res);
        this.onConnectionChange(true);
        req.on('close', () => {
          this.clients.delete(res);
          if (this.clients.size === 0) this.onConnectionChange(false);
        });
        return;
      }
      if (url.pathname === '/api/config' && req.method === 'GET') {
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-store',
        });
        res.end(JSON.stringify(this.configProvider()));
        return;
      }
      if (url.pathname === '/api/snippet' && req.method === 'GET') {
        const text = this.snippetProvider(url.searchParams.get('name') ?? '');
        if (text === null) {
          res.writeHead(404).end();
          return;
        }
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-store',
        });
        res.end(JSON.stringify({ text }));
        return;
      }
      if (url.pathname === '/api/send' && req.method === 'POST') {
        let body = '';
        req.on('data', (c) => {
          body += c;
          if (body.length > 1_000_000) req.destroy();
        });
        req.on('end', () => {
          try {
            const { channel, payload } = JSON.parse(body);
            this.handlers.get(channel)?.(payload);
            res.writeHead(204).end();
          } catch {
            res.writeHead(400).end();
          }
        });
        return;
      }
      res.writeHead(404).end();
      return;
    }

    // 静的ファイル（ビルド済みレンダラー）
    const rel =
      url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname).replace(/^\/+/, '');
    const file = path.normalize(path.join(this.rendererDir, rel));
    if (
      !file.startsWith(this.rendererDir) ||
      !fs.existsSync(file) ||
      fs.statSync(file).isDirectory()
    ) {
      res.writeHead(404).end();
      return;
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] ?? 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  }

  stop(): void {
    this.server?.close();
  }
}

export function findEdgeOrChrome(): string | null {
  const pf = process.env['ProgramFiles'] ?? 'C:\\Program Files';
  const pf86 = process.env['ProgramFiles(x86)'] ?? 'C:\\Program Files (x86)';
  const local = process.env['LOCALAPPDATA'] ?? '';
  // 日本語オンデバイス音声認識は Chrome が対応（Edge は未対応の版がある）ため Chrome 優先
  const candidates = [
    path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(pf86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(local, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(pf86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(pf, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
  ];
  return candidates.find((p) => fs.existsSync(p)) ?? null;
}

/** 音声認識ページを Edge/Chrome のアプリウィンドウで開く */
export function openSpeechPage(
  url: string,
  size: { width: number; height: number },
  profileDir: string,
  cleanFirst = false,
  offscreen = false
): boolean {
  const exe = findEdgeOrChrome();
  if (!exe) return false;
  // 前回起動(アップデート前など)の認識ウィンドウが残っていると、古いポートを見に行って
  // 「このサイトにアクセスできません」の画面になるため、先に片付けてから開く
  // （毎回やると起動が数秒遅れるため、前回が正常終了でなかったときと更新直後だけ）
  if (cleanFirst)
    closeEngineBrowsers(profileDir, () => launchSpeechPage(exe, url, size, profileDir, offscreen));
  else launchSpeechPage(exe, url, size, profileDir, offscreen);
  return true;
}

/** この専用プロファイルで動いているブラウザ(前回の認識ウィンドウ)をすべて閉じる */
export function closeEngineBrowsers(profileDir: string, done?: () => void): void {
  const safe = profileDir.replace(/'/g, "''");
  const script =
    `$p='${safe}'; Get-CimInstance Win32_Process -Filter "Name='chrome.exe' or Name='msedge.exe'" | ` +
    `Where-Object { $_.CommandLine -and $_.CommandLine.Contains($p) } | ` +
    `ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`;
  let finished = false;
  const finish = () => {
    if (finished) return;
    finished = true;
    done?.();
  };
  try {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', script],
      { windowsHide: true, timeout: 8000 },
      () => setTimeout(finish, 300)
    );
  } catch {
    finish();
  }
}

function launchSpeechPage(
  exe: string,
  url: string,
  size: { width: number; height: number },
  profileDir: string,
  offscreen = false
): void {
  // 専用プロファイル（拡張機能なし）で起動: 通常のEdgeの拡張機能に邪魔されず、
  // マイク許可・日本語音声パックもこのプロファイルに保存される
  spawn(
    exe,
    [
      `--user-data-dir=${profileDir}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-extensions',
      `--app=${url}`,
      `--window-size=${size.width},${size.height}`,
      // 通常の起動では、最初から画面の外に出す（一瞬だけ画面に出るのを防ぐ）
      ...(offscreen ? ['--window-position=-32000,-32000'] : []),
    ],
    { detached: true, stdio: 'ignore' }
  ).unref();
}

/**
 * 音声認識ウィンドウを、タスクバーにも Alt+Tab にも出ない「見えない場所」へ移す
 * （マイク許可済みで準備完了後に呼ぶ）。最小化だけだとタスクバーに別のボタンが残るため。
 * 画面外に置くだけで閉じてはいないので、音声認識は動き続ける。
 */
export function minimizeSpeechWindow(): void {
  const script = `
Add-Type @"
using System; using System.Runtime.InteropServices;
public class W {
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr h, int i, int v);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int cx, int cy, uint f);
}
"@
Get-Process | Where-Object { $_.MainWindowTitle -like '*${PAGE_TITLE}*' -and $_.MainWindowHandle -ne 0 } | ForEach-Object {
  $h = $_.MainWindowHandle
  [W]::ShowWindow($h, 0) | Out-Null
  $ex = [W]::GetWindowLong($h, -20)
  # WS_EX_TOOLWINDOW(0x80) on, WS_EX_APPWINDOW(0x40000) off => no taskbar button
  [W]::SetWindowLong($h, -20, (($ex -bor 0x80) -band (-bnot 0x40000))) | Out-Null
  [W]::SetWindowPos($h, [IntPtr]::Zero, -32000, -32000, 0, 0, 0x15) | Out-Null
  [W]::ShowWindow($h, 4) | Out-Null
}
`;
  execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], () => {});
}
