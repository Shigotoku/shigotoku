import { spawn, type ChildProcessWithoutNullStreams } from 'child_process';
import { writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { logPaste } from './paste';
import { newPartAfter } from '../shared/leadMarks';

/**
 * ライブ入力: 認識中のテキストを、カーソル位置へその場でキー入力として送る。
 *
 * - 常駐 PowerShell に SendInput(Unicode) を依頼する（クリップボードを使わない）
 * - 認識の途中結果が変わったら、共通する先頭部分までバックスペースで戻して打ち直す
 * - 入力先ウィンドウが開始時と変わったら入力を止める（別のアプリへ誤入力・誤削除しない）
 */

const PS_SCRIPT = String.raw`
Add-Type -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class ChkTyper {
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Explicit)] public struct INPUTUNION { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
  [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public INPUTUNION u; }
  [DllImport("user32.dll", SetLastError=true)] static extern uint SendInput(uint n, INPUT[] i, int size);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h, System.Text.StringBuilder s, int n);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  public static uint Pid(IntPtr h) { uint pid; GetWindowThreadProcessId(h, out pid); return pid; }
  public static string Title(IntPtr h) { System.Text.StringBuilder sb = new System.Text.StringBuilder(256); GetWindowText(h, sb, 256); return sb.ToString(); }
  // ---- マウスクリックの検知（入力中に別の場所をクリックしたら、そこからは続きを打つだけにして誤削除を防ぐ）----
  [StructLayout(LayoutKind.Sequential)] public struct MSG { public IntPtr h; public uint m; public IntPtr w; public IntPtr l; public uint t; public int x; public int y; }
  delegate IntPtr MProc(int code, IntPtr w, IntPtr l);
  [DllImport("user32.dll", SetLastError=true)] static extern IntPtr SetWindowsHookEx(int id, MProc p, IntPtr mod, uint tid);
  [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int code, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern int GetMessage(out MSG m, IntPtr h, uint a, uint b);
  [DllImport("kernel32.dll")] static extern IntPtr GetModuleHandle(string n);
  static MProc mproc = MCallback;
  static volatile bool clicked = false;
  static IntPtr MCallback(int code, IntPtr w, IntPtr l) {
    if (code >= 0) { int m = (int)w; if (m == 0x201 || m == 0x204 || m == 0x207) clicked = true; }
    return CallNextHookEx(IntPtr.Zero, code, w, l);
  }
  // ---- 矢印キー・Home/End・PageUp/Down（ユーザーが自分でカーソルを動かした）の検知。入力もクリックと同じ扱いにする ----
  public static IntPtr watch = IntPtr.Zero;
  static MProc kproc = KCallback;
  static IntPtr KCallback(int code, IntPtr w, IntPtr l) {
    if (code >= 0) {
      int m = (int)w;
      if (m == 0x100 || m == 0x104) {
        int vk = Marshal.ReadInt32(l, 0); int fl = Marshal.ReadInt32(l, 8);
        bool injected = (fl & 0x10) != 0;
        if (!injected && vk >= 0x21 && vk <= 0x28 && watch != IntPtr.Zero && GetForegroundWindow() == watch) clicked = true;
      }
    }
    return CallNextHookEx(IntPtr.Zero, code, w, l);
  }  public static void StartMouse() {
    System.Threading.Thread t = new System.Threading.Thread(() => {
      SetWindowsHookEx(14, mproc, GetModuleHandle(null), 0);
      SetWindowsHookEx(13, kproc, GetModuleHandle(null), 0);
      MSG m; while (GetMessage(out m, IntPtr.Zero, 0, 0) > 0) { }
    });
    t.IsBackground = true; t.SetApartmentState(System.Threading.ApartmentState.STA); t.Start();
  }
  public static bool TakeClick() { bool c = clicked; clicked = false; return c; }

  // ---- 別のウィンドウを見ている間も、入力先へ一瞬だけ戻って入力し、すぐ元のウィンドウへ戻す ----
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool attach);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [StructLayout(LayoutKind.Sequential)] struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
  [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LASTINPUTINFO p);
  public static bool Focus(IntPtr h) {
    if (h == IntPtr.Zero || !IsWindow(h)) return false;
    if (IsIconic(h)) ShowWindow(h, 9);
    if (GetForegroundWindow() == h) return true;
    uint pid; IntPtr fg = GetForegroundWindow();
    uint fgThread = GetWindowThreadProcessId(fg, out pid);
    uint me = GetCurrentThreadId();
    AttachThreadInput(me, fgThread, true);
    BringWindowToTop(h);
    SetForegroundWindow(h);
    AttachThreadInput(me, fgThread, false);
    for (int i = 0; i < 10; i++) { if (GetForegroundWindow() == h) return true; System.Threading.Thread.Sleep(15); }
    return GetForegroundWindow() == h;
  }
  /** 最後にキーボード・マウス操作があってからの経過ミリ秒 */
  public static uint IdleMs() {
    LASTINPUTINFO i = new LASTINPUTINFO(); i.cbSize = (uint)Marshal.SizeOf(typeof(LASTINPUTINFO));
    if (!GetLastInputInfo(ref i)) return 99999;
    return (uint)Environment.TickCount - i.dwTime;
  }
  public static bool ButtonDown() { return (GetAsyncKeyState(0x01) & 0x8000) != 0 || (GetAsyncKeyState(0x02) & 0x8000) != 0; }
  /** Ctrl+V を送る（押しっぱなしの Shift/Alt は先に離す）。Alt を無駄に離すと Office のキーヒントが開くので、押されているときだけ */
  public static void PasteKeys() {
    foreach (byte vk in new byte[] { 0x10, 0x12 })
      if ((GetAsyncKeyState(vk) & 0x8000) != 0) keybd_event(vk, 0, 2, UIntPtr.Zero);
    // Ctrl が相手に認識されてから V を送る（間隔なしだと V だけが文字として入ることがある）
    keybd_event(0x11, 0, 0, UIntPtr.Zero);
    System.Threading.Thread.Sleep(5);
    keybd_event(0x56, 0, 0, UIntPtr.Zero);
    System.Threading.Thread.Sleep(3);
    keybd_event(0x56, 0, 2, UIntPtr.Zero);
    System.Threading.Thread.Sleep(3);
    keybd_event(0x11, 0, 2, UIntPtr.Zero);
  }
  public static void LeftKeys(int n) {
    for (int k = 0; k < n; k++) { keybd_event(0x25, 0, 0, UIntPtr.Zero); keybd_event(0x25, 0, 2, UIntPtr.Zero); System.Threading.Thread.Sleep(2); }
  }
  static INPUT Key(ushort vk, ushort scan, uint flags) {
    INPUT i = new INPUT(); i.type = 1; i.u.ki.wVk = vk; i.u.ki.wScan = scan; i.u.ki.dwFlags = flags; return i;
  }
  static void Flush(List<INPUT> list) {
    if (list.Count > 0) SendInput((uint)list.Count, list.ToArray(), Marshal.SizeOf(typeof(INPUT)));
  }
  /** 改行を Shift+Enter で入れる（Enter が送信になるチャット用） */
  public static volatile bool NlShift = false;
  public static void Send(string text) {
    List<INPUT> list = new List<INPUT>();
    foreach (char c in text) {
      if (c == '\n') {
        if (NlShift) list.Add(Key(0x10, 0, 0));
        list.Add(Key(0x0D, 0, 0)); list.Add(Key(0x0D, 0, 2));
        if (NlShift) list.Add(Key(0x10, 0, 2));
      }
      else if (c == '\r') { }
      else { list.Add(Key(0, (ushort)c, 4)); list.Add(Key(0, (ushort)c, 6)); }
      if (list.Count >= 400) { Flush(list); list.Clear(); }
    }
    Flush(list);
  }
  public static void Back(int n) {
    List<INPUT> list = new List<INPUT>();
    for (int k = 0; k < n; k++) {
      list.Add(Key(0x08, 0, 0)); list.Add(Key(0x08, 0, 2));
      if (list.Count >= 400) { Flush(list); list.Clear(); }
    }
    Flush(list);
  }
  // ---- ウィンドウを前面にせず、入力先のコントロールへ文字メッセージを直接送る（他の画面を見ながら入力できる）----
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int l, t, r, b; }
  [StructLayout(LayoutKind.Sequential)] public struct GUITHREADINFO { public int cbSize; public int flags; public IntPtr hwndActive; public IntPtr hwndFocus; public IntPtr hwndCapture; public IntPtr hwndMenuOwner; public IntPtr hwndMoveSize; public IntPtr hwndCaret; public RECT rcCaret; }
  [DllImport("user32.dll")] static extern bool GetGUIThreadInfo(uint tid, ref GUITHREADINFO i);
  [DllImport("user32.dll", EntryPoint="PostMessageW")] static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  static IntPtr ctl = IntPtr.Zero;
  /** 入力先ウィンドウ内で、いまキー入力を受けているコントロールを覚える */
  public static void SaveCtl(IntPtr target) {
    ctl = target; watch = target;
    uint pid; uint tid = GetWindowThreadProcessId(target, out pid);
    GUITHREADINFO g = new GUITHREADINFO(); g.cbSize = Marshal.SizeOf(typeof(GUITHREADINFO));
    if (GetGUIThreadInfo(tid, ref g) && g.hwndFocus != IntPtr.Zero) ctl = g.hwndFocus;
  }
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h, System.Text.StringBuilder s, int n);
  public static string CtlClass() { System.Text.StringBuilder sb = new System.Text.StringBuilder(128); if (ctl != IntPtr.Zero) GetClassName(ctl, sb, 128); return sb.ToString(); }
  [DllImport("user32.dll", EntryPoint="SendMessageTimeoutW", CharSet=CharSet.Unicode, SetLastError=true)] static extern IntPtr SendMessageTimeoutText(IntPtr h, uint m, IntPtr w, System.Text.StringBuilder l, uint f, uint t, out IntPtr r);
  /** 標準の入力欄(Edit/RichEdit等)なら中身を直接読む。読めなければ null */
  public static string CtlText() {
    if (ctl == IntPtr.Zero || !IsWindow(ctl)) return null;
    IntPtr len;
    if (SendMessageTimeout(ctl, 0x000E, IntPtr.Zero, IntPtr.Zero, 2, 300, out len) == IntPtr.Zero) return null;
    int n = (int)len;
    if (n <= 0 || n > 200000) return null;
    System.Text.StringBuilder sb = new System.Text.StringBuilder(n + 2);
    IntPtr got;
    if (SendMessageTimeoutText(ctl, 0x000D, (IntPtr)(n + 1), sb, 2, 300, out got) == IntPtr.Zero) return null;
    return sb.ToString();
  }
  public static string ClassOf(IntPtr h) { System.Text.StringBuilder sb = new System.Text.StringBuilder(128); GetClassName(h, sb, 128); return sb.ToString(); }
  public static bool CtlAlive() { return ctl != IntPtr.Zero && IsWindow(ctl); }
  public static void PostChars(string text) {
    foreach (char c in text) {
      if (c == '\r') continue;
      PostMessage(ctl, 0x0102, (IntPtr)(c == '\n' ? 13 : (int)c), IntPtr.Zero);
    }
  }
  public static void PostBack(int n) {
    for (int k = 0; k < n; k++) PostMessage(ctl, 0x0102, (IntPtr)8, IntPtr.Zero);
  }
  // ---- 管理者権限で動いているアプリには、通常権限のアプリから入力を送れない（Windows の仕様 UIPI）----
  [DllImport("advapi32.dll", SetLastError=true)] static extern bool OpenProcessToken(IntPtr p, uint a, out IntPtr t);
  [DllImport("advapi32.dll", SetLastError=true)] static extern bool GetTokenInformation(IntPtr t, int c, out int info, int len, out int ret);
  [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr OpenProcess(uint a, bool i, uint pid);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
  static bool TokenElevated(IntPtr proc) {
    IntPtr t; if (!OpenProcessToken(proc, 8, out t)) return true;
    int e = 0, r; bool ok = GetTokenInformation(t, 20, out e, 4, out r); CloseHandle(t);
    return ok && e != 0;
  }
  public static bool TargetNeedsAdmin(IntPtr hwnd) {
    uint pid = Pid(hwnd); if (pid == 0) return false;
    if (TokenElevated(System.Diagnostics.Process.GetCurrentProcess().Handle)) return false;
    IntPtr h = OpenProcess(0x1000, false, pid); if (h == IntPtr.Zero) return true;
    bool r = TokenElevated(h); CloseHandle(h); return r;
  }
  // ---- IME 制御 ----
  // 日本語 IME がオンのまま Unicode 入力・バックスペースを送ると、アプリ側で「変換中の文字」として扱われ、
  // 確定済みの文字が消えない／途中から入力が始まる、といった崩れが起きる。
  // 入力の間だけ入力先ウィンドウの IME をオフ（直接入力）にし、終了時に元へ戻す。
  [DllImport("imm32.dll")] static extern IntPtr ImmGetDefaultIMEWnd(IntPtr hWnd);
  [DllImport("user32.dll", SetLastError=true)] static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  static IntPtr imeWnd = IntPtr.Zero;
  static bool imeWasOpen = false;
  static IntPtr ImeControl(IntPtr wnd, int cmd, int value) {
    IntPtr res;
    SendMessageTimeout(wnd, 0x0283, (IntPtr)cmd, (IntPtr)value, 2, 500, out res);
    return res;
  }
  public static string CloseIme(IntPtr target) {
    imeWnd = ImmGetDefaultIMEWnd(target);
    if (imeWnd == IntPtr.Zero) return "noime";
    imeWasOpen = ImeControl(imeWnd, 5, 0) != IntPtr.Zero;
    if (imeWasOpen) { ImeControl(imeWnd, 6, 0); return "closed"; }
    return "alreadyoff";
  }
  public static void RestoreIme() {
    if (imeWnd != IntPtr.Zero && imeWasOpen) ImeControl(imeWnd, 6, 1);
    imeWasOpen = false;
    imeWnd = IntPtr.Zero;
  }
  [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);
  // 実際に押されているキーだけ離す。押していない Alt の KEYUP を送ると、Outlook/Office がリボンのキーヒント（Alt操作）を開いてしまう
  public static void ReleaseModifiers() {
    foreach (byte vk in new byte[] { 0x10, 0x11, 0x12 })
      if ((GetAsyncKeyState(vk) & 0x8000) != 0) keybd_event(vk, 0, 2, UIntPtr.Zero);
  }
}
"@
$target = [IntPtr]::Zero
$script:bg = $true
$script:post = $false
$script:postOk = $false
$script:lastHop = -1
$script:sw = [Diagnostics.Stopwatch]::StartNew()
[ChkTyper]::StartMouse()
# ---- カーソル位置の記憶と復元（UI Automation）----
# 入力した直後のカーソル位置を覚えておき、あとで別の場所をクリックされても、元の位置へ戻してから続きを入力する。
# テキスト位置を取れないアプリでは何もしない（none を返す）。
$script:uiaLoaded = $false
$script:savedRange = $null
function Save-Caret {
  try {
    if (-not $script:uiaLoaded) {
      Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
      $script:uiaLoaded = $true
    }
    $el = [System.Windows.Automation.AutomationElement]::FocusedElement
    if ($el -eq $null) { return 'none' }
    $pat = $null
    if ($el.TryGetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern, [ref]$pat)) {
      $sel = $pat.GetSelection()
      if ($sel.Length -gt 0) { $script:savedRange = $sel[0]; return 'ok' }
    }
  } catch { }
  $script:savedRange = $null
  return 'none'
}
# 入力した文字が本当に入力先へ入ったか確かめる（yes/no/unknown）。確かめられないアプリは unknown
function Probe-Text($probe) {
  try {
    if (-not $script:uiaLoaded) { Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes; $script:uiaLoaded = $true }
    if ([ChkTyper]::GetForegroundWindow() -ne $target) { return 'unknown' }
    $el = [System.Windows.Automation.AutomationElement]::FocusedElement
    if ($el -eq $null) { return 'unknown' }
    try { if ($el.Current.IsPassword) { return 'unknown' } } catch { }
    $txt = $null
    $pat = $null
    if ($el.TryGetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern, [ref]$pat)) {
      $sel = $pat.GetSelection()
      if ($sel.Length -gt 0) {
        $rg = $sel[0].Clone()
        [void]$rg.MoveEndpointByUnit([System.Windows.Automation.Text.TextPatternRangeEndpoint]::Start, [System.Windows.Automation.Text.TextUnit]::Character, -60)
        $txt = $rg.GetText(200)
      }
    }
    if ($txt -eq $null) {
      $vp = $null
      if ($el.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$vp)) {
        $v = $vp.Current.Value
        if ($v -ne $null -and $v.Length -lt 100000) { $txt = $v }
      }
    }
    if ($txt -eq $null -and $script:postOk) { $txt = [ChkTyper]::CtlText() }
    if ($txt -eq $null) { return 'unknown' }
    $txt = $txt -replace "[\r\n]", ''
    if ($txt.Contains($probe)) { return 'yes' } else { return 'no' }
  } catch { return 'unknown' }
}
function Restore-Caret {
  try {
    if ($script:savedRange -ne $null) { $script:savedRange.Select(); return 'ok' }
  } catch { }
  return 'none'
}
[Console]::Out.WriteLine('ready'); [Console]::Out.Flush()
while (($line = [Console]::In.ReadLine()) -ne $null) {
  $r = 'ok'
  try {
    $cmd = $line.Substring(0, 1)
    $arg = $line.Substring(1)
    if ($cmd -ceq 'F') {
      [ChkTyper]::RestoreIme()
      $target = [IntPtr][int64]$arg
      [ChkTyper]::ReleaseModifiers()
      [void][ChkTyper]::TakeClick()
      $script:savedRange = $null
      if ($target -ne [IntPtr]::Zero) { [ChkTyper]::SaveCtl($target); $cls = [ChkTyper]::CtlClass(); $script:postOk = ($cls -match '^(Edit|RichEdit.*|RICHEDIT.*|Scintilla|_WwG|WindowsForms10\.(EDIT|RichEdit).*)$'); $r = 'ok:' + [ChkTyper]::CloseIme($target) + ':' + $cls + ':' + $script:postOk }
    } elseif ($cmd -ceq 'C') {
      # 入力先が前面のときだけ記録（別のウィンドウのカーソルを覚えないように）
      if ($target -ne [IntPtr]::Zero -and [ChkTyper]::GetForegroundWindow() -eq $target) { $r = Save-Caret } else { $r = 'skip' }
    } elseif ($cmd -ceq 'S') {
      $r = Restore-Caret
    } elseif ($cmd -ceq 'R') {
      [ChkTyper]::RestoreIme()
    } elseif ($cmd -ceq 'G') {
      $h = [ChkTyper]::GetForegroundWindow()
      # 自分自身（ちょこっとワークスの窓・音声認識の窓）のときだけ 0。ウィンドウ名に「ちょこっと」を含む別のアプリ
      # （例: タイトルにその文字が入ったエディタ）を誤って除外すると、そこへ入力できなくなる
      $own = $false
      try {
        $pn = [Diagnostics.Process]::GetProcessById([int][ChkTyper]::Pid($h)).ProcessName
        if ($pn -eq 'ChokottoWorks') { $own = $true }
      } catch { }
      if ([ChkTyper]::Title($h) -like '*音声認識エンジン*') { $own = $true }
      if ($own) { $r = '0' } else { $r = $h.ToInt64().ToString() }
    } elseif ($cmd -ceq 'P') {
      $r = ''
      $pidv = [ChkTyper]::Pid([IntPtr][int64]$arg)
      if ($pidv -ne 0) { $r = [Diagnostics.Process]::GetProcessById([int]$pidv).ProcessName }
      if (-not $r) { $r = '-' }
    } elseif ($cmd -ceq 'Q') {
      break
    } elseif ($cmd -ceq 'T' -or $cmd -ceq 'B') {
      if ($target -eq [IntPtr]::Zero) { $r = 'notarget' }
      elseif ([ChkTyper]::GetForegroundWindow() -ne $target) { $r = 'nofocus' }
      elseif ([ChkTyper]::TakeClick()) { $r = 'moved' }
      elseif ($cmd -ceq 'B') { [ChkTyper]::Back([int]$arg) }
      else { [ChkTyper]::Send([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($arg))) }
    } elseif ($cmd -ceq 'W') {
      $r = [ChkTyper]::ClassOf([IntPtr][int64]$arg)
      if (-not $r) { $r = '-' }
    } elseif ($cmd -ceq 'E') {
      $r = 'no'
      if ([ChkTyper]::TargetNeedsAdmin([IntPtr][int64]$arg)) { $r = 'admin' }
    } elseif ($cmd -ceq 'K') {
      $pr = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($arg))
      $r = Probe-Text $pr
    } elseif ($cmd -ceq 'M') {
      $script:bg = ($arg -ne '0')
      $script:post = ($arg -eq '2') -and -not [ChkTyper]::NlShift
    } elseif ($cmd -ceq 'N') {
      [ChkTyper]::NlShift = ($arg -eq '1')
    } elseif ($cmd -ceq 'X') {
      # 「戻る文字数|入力する文字(Base64)」をまとめて入力。入力先が前面でなくても、操作が一段落したら一瞬だけ戻って入力する
      if ($target -eq [IntPtr]::Zero) { $r = 'notarget' }
      else {
        $parts = $arg.Split('|')
        $back = [int]$parts[0]
        $txt = ''
        if ($parts.Length -gt 1 -and $parts[1]) { $txt = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($parts[1])) }
        $other = [IntPtr]::Zero
        if ([ChkTyper]::GetForegroundWindow() -ne $target -and $script:post -and $script:postOk) {
          # 前面にせず直接送る（他の画面を操作していても、その場で続ける）
          if (-not [ChkTyper]::CtlAlive()) { $r = 'nofocus' }
          else {
            if ($back -gt 0) { [ChkTyper]::PostBack($back) }
            if ($txt) { [ChkTyper]::PostChars($txt) }
          }
        } elseif ([ChkTyper]::GetForegroundWindow() -ne $target) {
          if (-not $script:bg) { $r = 'nofocus' }
          elseif ($script:lastHop -ge 0 -and ($script:sw.ElapsedMilliseconds - $script:lastHop) -lt 800) { $r = 'busy' }
          elseif ([ChkTyper]::IdleMs() -lt 400 -or [ChkTyper]::ButtonDown()) { $r = 'busy' }
          else {
            $other = [ChkTyper]::GetForegroundWindow()
            if ([ChkTyper]::Focus($target)) { [void](Restore-Caret); [void][ChkTyper]::TakeClick() }
            else { $r = 'busy'; $other = [IntPtr]::Zero }
          }
        } elseif ([ChkTyper]::TakeClick()) {
          # ユーザーがカーソルを動かした（クリック・矢印キー）: 元の場所へ戻さず、動かした先から続きを入力する
          $r = 'moved'
        }
        if ($r -eq 'ok' -and -not ($script:post -and $script:postOk -and [ChkTyper]::GetForegroundWindow() -ne $target)) {
          if ($back -gt 0) { [ChkTyper]::Back($back) }
          if ($txt) { [ChkTyper]::Send($txt) }
          if ($other -ne [IntPtr]::Zero) {
            Start-Sleep -Milliseconds 70
            [void](Save-Caret)
            [void][ChkTyper]::Focus($other)
            $script:lastHop = $script:sw.ElapsedMilliseconds
          }
        }
      }
    } elseif ($cmd -ceq 'V') {
      # 貼り付け（スニペットなど）: 「入力先|戻すカーソル文字数」。クリップボードへは呼び出し側が書き込み済み
      $parts = $arg.Split('|')
      $h = [IntPtr][int64]$parts[0]
      $cb = 0
      if ($parts.Length -gt 1 -and $parts[1]) { $cb = [int]$parts[1] }
      if ($h -ne [IntPtr]::Zero -and -not [ChkTyper]::Focus($h)) { $r = 'nofocus' }
      else {
        [ChkTyper]::PasteKeys()
        if ($cb -gt 0) { Start-Sleep -Milliseconds 120; [ChkTyper]::LeftKeys($cb) }
      }
    }
  } catch { $r = 'err' }
  [Console]::Out.WriteLine($r); [Console]::Out.Flush()
}
`;

const KNOWN_GOOD_CLASS =
  /^(Chrome_|Edit$|RichEdit|RICHEDIT|Scintilla|_WwG|OpusApp|rctrl_|Notepad|WindowsForms10|SunAwt|Mozilla|MozillaWindowClass|Windows\.UI|Xaml|TextBox|Internet Explorer_Server|Afx:)/;

type Waiter = { resolve: (v: string) => void; timer: ReturnType<typeof setTimeout> };

export class LiveTyper {
  private proc: ChildProcessWithoutNullStreams | null = null;
  private waiters: Waiter[] = [];
  private buf = '';
  private ready = false;
  private readyWaiters: Array<() => void> = [];

  private typed = '';
  private desired = '';
  private pumping = false;
  private paused = false;
  private active = false;
  private hasTarget = false;
  /**
   * 別の場所へ移った/クリックした時点で「入力済み」だった認識の全文。これより前は、前の場所に入力済みなので、
   * 新しい場所には、これより後の部分だけを入力する（位置ではなく文の内容で区切る。認識の書き直しでずれないように）
   */
  private base = '';
  /** いま入力済みの文字（typed）を作ったときの、認識の全文 */
  private typedSrc = '';
  private typedEver = false;
  private captureTimer: ReturnType<typeof setTimeout> | null = null;
  /** 入力先がフォアグラウンドでなくなって待ち始めた時刻（0=待っていない） */
  private waitingSince = 0;

  /** ライブ入力が使えるか（常駐プロセスが生きている） */
  get available(): boolean {
    return process.platform === 'win32' && this.proc !== null && this.ready;
  }

  /** このセッションで 1 文字でも入力したか（別の場所へ移ったあとも、それまでに入力した分を含む） */
  get hasTyped(): boolean {
    return this.typedEver;
  }

  /** 入力を止めたか（入力先が変わった等） */
  get isPaused(): boolean {
    return this.paused;
  }

  /** 常駐プロセスを起動（アプリ起動時に呼んでおくと初回の待ちが減る） */
  warmUp(): void {
    if (process.platform !== 'win32' || this.proc) return;
    // スクリプトが長く -EncodedCommand だと Windows のコマンド長上限(32767)を超えるため、BOM付きファイルで渡す
    const scriptPath = join(tmpdir(), `chokotto-typer-${process.pid}.ps1`);
    writeFileSync(scriptPath, '\ufeff' + PS_SCRIPT, 'utf8');
    const proc = spawn(
      'powershell.exe',
      [
        '-NoProfile',
        '-NonInteractive',
        '-WindowStyle',
        'Hidden',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        scriptPath,
      ],
      { windowsHide: true }
    );
    this.proc = proc;
    this.ready = false;
    proc.stdout.setEncoding('utf8');
    proc.stdout.on('data', (chunk: string) => this.onData(chunk));
    proc.stderr.on('data', (d) => logPaste(`typer stderr: ${String(d).slice(0, 300)}`));
    proc.on('exit', () => {
      this.proc = null;
      this.ready = false;
      this.active = false;
      for (const w of this.waiters) {
        clearTimeout(w.timer);
        w.resolve('dead');
      }
      this.waiters = [];
    });
    proc.stdin.on('error', () => {});
  }

  private onData(chunk: string): void {
    this.buf += chunk;
    let idx: number;
    while ((idx = this.buf.indexOf('\n')) >= 0) {
      const line = this.buf.slice(0, idx).trim();
      this.buf = this.buf.slice(idx + 1);
      if (!line) continue;
      if (line === 'ready' && !this.ready) {
        this.ready = true;
        for (const cb of this.readyWaiters) cb();
        this.readyWaiters = [];
        continue;
      }
      const w = this.waiters.shift();
      if (w) {
        clearTimeout(w.timer);
        w.resolve(line);
      }
    }
  }

  private waitReady(ms: number): Promise<boolean> {
    if (this.ready) return Promise.resolve(true);
    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve(this.ready), ms);
      this.readyWaiters.push(() => {
        clearTimeout(timer);
        resolve(true);
      });
    });
  }

  private request(line: string): Promise<string> {
    return new Promise((resolve) => {
      if (!this.proc || !this.ready) {
        resolve('dead');
        return;
      }
      const timer = setTimeout(() => {
        const i = this.waiters.findIndex((w) => w.timer === timer);
        if (i >= 0) this.waiters.splice(i, 1);
        resolve('timeout');
      }, 4000);
      this.waiters.push({ resolve, timer });
      try {
        this.proc.stdin.write(`${line}\n`);
      } catch {
        resolve('dead');
      }
    });
  }

  /** いまフォーカスのあるウィンドウ(HWND)を取得。本アプリ自身の窓や取得失敗は 0 */
  async captureForeground(): Promise<number> {
    this.warmUp();
    if (!(await this.waitReady(6000))) return 0;
    const r = await this.request('G');
    const n = Number(r);
    return Number.isFinite(n) ? n : 0;
  }

  /** ウィンドウ(HWND)を持つアプリのプロセス名（拡張子なし）。取得できなければ空文字 */
  async processName(hwnd: number): Promise<string> {
    if (!hwnd || !(await this.waitReady(3000))) return '';
    const r = await this.request(`P${hwnd}`);
    return r === '-' || r === 'dead' || r === 'timeout' || r === 'err' ? '' : r;
  }

  /** ウィンドウのクラス名（Qt 製アプリなどの判定用）。取得できなければ空文字 */
  async windowClass(hwnd: number): Promise<string> {
    if (!hwnd || !(await this.waitReady(3000))) return '';
    const r = await this.request(`W${hwnd}`);
    return r === '-' || r === 'dead' || r === 'timeout' || r === 'err' ? '' : r;
  }

  /** セッション開始: 入力先ウィンドウ(HWND)を設定する。使えなければ false */
  /** 他のウィンドウを操作中も、入力先へ一瞬だけ戻って入力を続ける */
  background = true;
  /** true: 画面を切り替えて入力（互換）。false: 前面にせず直接送る */
  hop = false;

  /** 入力先のアプリ名（確認で入らないと分かったとき、あとから貼り付け方式にするため） */
  private procName = '';
  private verified = false;
  /** 入力先コントロールのクラス名（実績のあるものは入力確認を省いて速くする） */
  private ctlClass = '';
  /** 入力先が管理者権限のアプリで、入力を受け付けられないとき */
  onElevated: ((proc: string) => void) | null = null;
  /** ライブ入力しても文字が入らないアプリだと確認できたとき（貼り付け方式へ切り替える） */
  onUnsupported: ((proc: string) => void) | null = null;

  /** 入力先がチャットのとき true（改行を Shift+Enter で入れる）。begin の前に設定する */
  newlineShift = false;

  async begin(targetHwnd: number, procName = ''): Promise<boolean> {
    this.warmUp();
    this.procName = procName;
    this.verified = false;
    this.ctlClass = '';
    this.typed = '';
    this.desired = '';
    this.paused = false;
    this.base = '';
    this.typedSrc = '';
    this.typedEver = false;
    this.waitingSince = 0;
    this.hasTarget = targetHwnd !== 0;
    if (!(await this.waitReady(6000))) return false;
    if (targetHwnd !== 0 && (await this.request(`E${targetHwnd}`)) === 'admin') {
      logPaste(`target is elevated (admin): ${procName}`);
      this.active = false;
      this.onElevated?.(procName);
      return false;
    }
    void this.request(`N${this.newlineShift ? 1 : 0}`);
    void this.request(`M${!this.background ? 0 : this.hop ? 1 : 2}`);
    const r = await this.request(`F${targetHwnd}`);
    this.active = r.startsWith('ok') && this.hasTarget;
    this.ctlClass = r.split(':')[2] ?? '';
    // 実績のあるクラス（標準の入力欄・Chrome/Electron・Office など）は確認しない。確認はUI Automationを呼び、
    // 初回の読み込みと Chrome 系のアクセシビリティ有効化で入力が遅くなるため、未知のアプリだけに限る
    if (KNOWN_GOOD_CLASS.test(this.ctlClass)) this.verified = true;
    logPaste(`live typing begin: ${r}`);
    return this.active;
  }

  /** 入力したい全文（認識中のテキスト）を更新。差分だけをキー入力する */
  setDesired(text: string): void {
    if (!this.active) return;
    if (this.captureTimer) clearTimeout(this.captureTimer);
    this.desired = text;
    void this.pump();
  }

  /** 認識の全文のうち、いまの場所へ入力する部分。動かした先（または先頭）から始まる文の頭には、句読点を付けない */
  private effOf(desired: string): string {
    return newPartAfter(this.base, desired);
  }
  private effDesired(): string {
    return this.effOf(this.desired);
  }

  private async pump(): Promise<void> {
    if (this.pumping) return;
    this.pumping = true;
    try {
      while (this.active && !this.paused && this.effDesired() !== this.typed) {
        const src = this.desired;
        const target = this.effOf(src);
        const a = Array.from(this.typed);
        const b = Array.from(target);
        let common = 0;
        while (common < a.length && common < b.length && a[common] === b[common]) common++;
        const back = a.length - common;
        const add = b.slice(common).join('');

        // 戻る文字数と入力する文字を、1回の依頼でまとめて送る（別ウィンドウから一瞬だけ戻る回数を最小にするため）
        const r = await this.request(`X${back}|${Buffer.from(add, 'utf8').toString('base64')}`);
        if (r === 'busy') {
          // 別のウィンドウを操作中: 操作が一段落するまで待つ（音声認識は続いていて、文字は溜まる）
          // （入力済みの文字は触らない必要はない: 戻ったときにカーソル位置も復元する）
          if (!this.waitingSince) this.waitingSince = Date.now();
          await new Promise((res) => setTimeout(res, 250));
          continue;
        }
        if (r === 'nofocus' || r === 'moved') {
          this.onInterrupted(r);
          if (r === 'nofocus') await new Promise((res) => setTimeout(res, 250));
          continue;
        }
        if (r !== 'ok') return this.fail(r);
        this.waitingSince = 0;
        this.typed = target;
        this.typedSrc = src;
        if (target) this.typedEver = true;
        if (
          !this.verified &&
          Array.from(target).length >= 2 &&
          target.replace(/[\r\n]/g, '').length >= 2
        ) {
          this.verified = true;
          if ((await this.verifyTyped(target)) === 'no') {
            logPaste(`typed text not found in target (${this.procName}) -> switch to paste`);
            this.typed = '';
            this.desired = '';
            this.active = false;
            void this.request('R');
            this.onUnsupported?.(this.procName);
            return;
          }
        }
      }
      this.scheduleCaretSave();
    } finally {
      this.pumping = false;
    }
  }

  /**
   * 入力先から離れた（他のウィンドウを開いた）・別の場所をクリックした場合。
   * 音声入力は止めずに、入力先に戻るまで待って続きを入力する。
   */
  private onInterrupted(reason: string): void {
    // ここまでの入力は前の場所に残す（そこの文字は消さない）。新しい場所へは、これより後の部分だけを入力する
    this.base = this.typedSrc;
    this.typed = '';
    if (reason === 'nofocus' && !this.waitingSince) {
      this.waitingSince = Date.now();
      logPaste('live typing waiting for target focus');
    }
  }

  /** 入力が落ち着いたら、いまのカーソル位置を覚えておく（クリックで動かされたとき戻すため） */
  private scheduleCaretSave(): void {
    if (this.captureTimer) clearTimeout(this.captureTimer);
    this.captureTimer = setTimeout(() => {
      this.captureTimer = null;
      if (this.active && !this.pumping) void this.request('C');
    }, 350);
  }

  /** 入力した文字が入力先に入ったか確認。3回続けて「無い」ときだけ no（誤判定で二重入力しないため） */
  private async verifyTyped(typed: string): Promise<'yes' | 'no' | 'unknown'> {
    const probe = Array.from(typed.replace(/[\r\n]/g, ''))
      .slice(-6)
      .join('');
    if (!probe) return 'unknown';
    const b64 = Buffer.from(probe, 'utf8').toString('base64');
    for (let i = 0; i < 3; i++) {
      await new Promise((res) => setTimeout(res, i === 0 ? 250 : 500));
      const r = await this.request(`K${b64}`);
      if (r === 'yes') return 'yes';
      if (r !== 'no') return 'unknown';
    }
    return 'no';
  }

  private fail(reason: string): void {
    logPaste(`live typing stopped: ${reason}`);
    this.paused = true;
  }

  /** 常駐プロセスで Ctrl+V を送る（スニペットなど）。入力先へ戻してから貼り付ける。使えなければ null */
  async pasteKeys(targetHwnd: number, caretBack: number): Promise<string | null> {
    if (!this.available) return null;
    const r = await this.request('V' + targetHwnd + '|' + caretBack);
    return r === 'dead' || r === 'timeout' || r === 'err' ? null : r;
  }

  /**
   * 最終テキストを反映しきるまで待つ。入力先に戻れず入力できなかった続き（残り）を返す
   * （呼び出し側が入力先へ貼り付けて救済する）。
   */
  async flush(finalText: string): Promise<string> {
    this.setDesired(finalText);
    const until = Date.now() + 5000;
    while (this.active && !this.paused && (this.pumping || this.effDesired() !== this.typed)) {
      if (Date.now() > until) break;
      // 他のウィンドウを見ている間に終了した場合は、長く待たずに残りを貼り付けへ回す
      if (this.waitingSince && Date.now() - this.waitingSince > 1200) break;
      await new Promise((r) => setTimeout(r, 30));
    }
    // 入力の依頼が実行中のまま打ち切ると、入力済みの文字数がまだ反映されておらず、
    // 続きを貼り付けで二重に入れてしまう。実行中の依頼が終わるのを待ってから残りを数える
    const settle = Date.now() + 4000;
    while (this.pumping && Date.now() < settle) await new Promise((r) => setTimeout(r, 30));
    if (this.pumping) return ''; // 状態が確定できないときは、二重入力を避けて貼り付けしない
    if (!this.active || this.paused || this.effDesired() === this.typed) return '';
    return Array.from(this.effDesired()).slice(Array.from(this.typed).length).join('');
  }
  /** セッション終了（入力済みの文字はそのまま残す） */
  end(): void {
    if (this.captureTimer) clearTimeout(this.captureTimer);
    this.captureTimer = null;
    if (this.active) void this.request('R'); // IME を元の状態に戻す
    this.active = false;
    this.typed = '';
    this.desired = '';
    this.paused = false;
  }

  dispose(): void {
    try {
      this.proc?.stdin.write('R\nQ\n');
    } catch {
      /* ignore */
    }
    this.proc?.kill();
    this.proc = null;
  }
}
