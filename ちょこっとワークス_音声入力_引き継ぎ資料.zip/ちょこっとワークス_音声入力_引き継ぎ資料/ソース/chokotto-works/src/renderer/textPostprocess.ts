/**
 * 音声認識結果の整形（ちょこっと音声入力）
 *
 * 1. 日本語の文字間の空白を除去（端末内認識は単語ごとに空白を入れて返す）
 * 2. 言いよどみ（えっと・あのー 等）の除去
 * 3. 読み上げ句読点（「句点」「読点」「改行」）の変換
 * 4. 医療用語の読み仮名 → 正しい表記への補正（誤変換されにくい4文字以上の読みのみ）
 * 5. 句読点の自動挿入（文末表現から判定。確信が持てないときは何も付けない）
 */

import { inferCommas } from '../shared/punctInfer';
import { MEDICAL_EXTRA_READINGS } from '../shared/medicalDict';
import { correctDrugNames, isKnownDrug, setExtraNames } from '../shared/drugMatch';
import { correctDiseaseNames } from '../shared/diseaseMatch';
import { convertKanaRuns, setUserReadings } from '../shared/kanaSegment';
import { CLINIC_TERMS, COMMON_DRUG_HINTS } from '../shared/clinicTerms';
import { findSpecialty } from '../shared/specialties';
import { ECHO_PHRASE_HINTS } from '../shared/echoCardiac';
import { formatMedicalNumbers } from '../shared/medicalFormat';
import { applySpokenBrackets } from '../shared/formatCommands';
import { parseEditCommand } from '../shared/voiceCommands';
import { applyRephrase } from '../shared/rephrase';

// ---- 設定（アプリ本体から音声入力開始時に受け取る） ----
export interface PostprocessConfig {
  dictionary: Array<{ from: string; to: string }>;
  specialty: string;
  medicalTerms: boolean;
  /** 音声で呼び出せる定型文の名前（「定型 ○○」の照合用） */
  snippetNames: string[];
  /** マイクを待機状態にして話し始めを速くする */
  warmMic?: boolean;
  /** 専門用語フォルダの用語（認識エンジンに優先して聞き取らせ、薬剤名の補正先にも使う） */
  terms?: string[];
}
let config: PostprocessConfig = {
  dictionary: [],
  specialty: 'general',
  medicalTerms: true,
  snippetNames: [],
};
let specialtyReplacements: Array<[string, string]> = [];

export function isWarmMic(): boolean {
  return config.warmMic === true;
}

export function setPostprocessConfig(next: Partial<PostprocessConfig>): void {
  config = { ...config, ...next };
  const pack = findSpecialty(config.specialty);
  specialtyReplacements = Object.entries(pack.readings)
    .flatMap(([canonical, readings]) => readings.map((r) => [r, canonical] as [string, string]))
    .sort((a, b) => b[0].length - a[0].length);
}

// ---- 1. 日本語の文字間の空白 ----
const JA = '[\\u3000-\\u303F\\u3040-\\u30FF\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uFF00-\\uFFEF]';
const JA_SPACE_AFTER = new RegExp(`(?<=${JA})[\\s\\u3000]+`, 'g');
const JA_SPACE_BEFORE = new RegExp(`[\\s\\u3000]+(?=${JA})`, 'g');

/** 日本語（かな・漢字・全角記号）の前後の空白をすべて除去。英数字どうしの空白は残す */
export function removeJapaneseSpaces(text: string): string {
  return text.replace(JA_SPACE_AFTER, '').replace(JA_SPACE_BEFORE, '');
}

// ---- 2. 言いよどみ ----
const FILLERS =
  /(?:えーっと|えっと|えーと|えぇと|あのー+|あのぅ|あのう|そのー+|うーん+|んーと|えー+|あー+)/g;

export function removeFillers(text: string): string {
  return text
    .replace(FILLERS, '')
    .replace(/、{2,}/g, '、')
    .replace(/^[、。]+/, '');
}

// ---- 3. 読み上げ句読点 ----
export function applySpokenPunctuation(text: string): string {
  return applySpokenBrackets(text)
    .replace(/句点/g, '。')
    .replace(/読点/g, '、')
    .replace(/(?:改行|新しい行|あたらしいぎょう)/g, '\n');
}

// ---- 4. 医療用語の読み仮名補正（読み → 表記） ----
// 注意: 部分一致で置換するため、短い読み（3文字以下）は日常語を壊す恐れがあり入れない。
const MEDICAL_READINGS: Record<string, string[]> = {
  主訴: ['しゅそ'],
  現病歴: ['げんびょうれき', 'げんびょうし'],
  既往歴: ['きおうれき'],
  家族歴: ['かぞくれき'],
  内服歴: ['ないふくれき'],
  生活歴: ['せいかつれき'],
  社会歴: ['しゃかいれき'],
  経過観察: ['けいかかんさつ'],
  鑑別診断: ['かんべつしんだん'],
  倦怠感: ['けんたいかん'],
  高血圧: ['こうけつあつ'],
  糖尿病: ['とうにょうびょう'],
  脂質異常症: ['ししついじょうしょう'],
  高尿酸血症: ['こうにょうさんけっしょう'],
  慢性腎臓病: ['まんせいじんぞうびょう'],
  逆流性食道炎: ['ぎゃくりゅうせいしょくどうえん'],
  胃潰瘍: ['いかいよう'],
  十二指腸潰瘍: ['じゅうにしちょうかいよう'],
  大腸ポリープ: ['だいちょうぽりーぷ'],
  過敏性腸症候群: ['かびんせいちょうしょうこうぐん'],
  ピロリ菌: ['ぴろりきん', 'ヘリコバクターピロリ'],
  心房細動: ['しんぼうさいどう'],
  狭心症: ['きょうしんしょう'],
  心筋梗塞: ['しんきんこうそく'],
  脳梗塞: ['のうこうそく'],
  喘息: ['ぜんそく'],
  肺炎: ['はいえん'],
  気管支炎: ['きかんしえん'],
  インフルエンザ: ['いんふるえんざ'],
  血液検査: ['けつえきけんさ'],
  尿検査: ['にょうけんさ'],
  心電図: ['しんでんず'],
  胸部レントゲン: ['きょうぶれんとげん'],
  腹部エコー: ['ふくぶえこー'],
  胃カメラ: ['いかめら'],
  内視鏡: ['ないしきょう'],
  処方箋: ['しょほうせん'],
  診断書: ['しんだんしょ'],
  紹介状: ['しょうかいじょう'],
  セカンドオピニオン: ['せかんどおぴにおん'],
  インフォームドコンセント: ['いんふぉーむどこんせんと'],
};

const MEDICAL_REPLACEMENTS: Array<[string, string]> = [
  ...Object.entries(MEDICAL_READINGS),
  ...Object.entries(MEDICAL_EXTRA_READINGS),
  ...Object.entries(CLINIC_TERMS),
]
  .flatMap(([canonical, readings]) => readings.map((r) => [r, canonical] as [string, string]))
  // 日常語を壊さないよう、ひらがなだけの読みは4文字以上に限る（短い語は認識結果が漢字で返るので不要）
  .filter(([r]) => !/^[ぁ-ゖー]+$/.test(r) || r.length >= 4)
  .sort((a, b) => b[0].length - a[0].length);

/** 薬剤名の補正で触らない語（辞書・診療科の正しい表記、ユーザー辞書の「正」） */
function protectedWords(): Set<string> {
  const s = new Set<string>();
  for (const [, c] of MEDICAL_REPLACEMENTS) s.add(c);
  for (const [, c] of specialtyReplacements) s.add(c);
  for (const d of config.dictionary) s.add(d.to);
  for (const w of config.terms ?? []) s.add(w);
  return s;
}

/** 音声認識エンジンに優先して聞き取らせる語（ユーザー辞書の「正」→診療科の語→頻用薬→共通の医学用語の順） */
export function getMedicalPhraseHints(max = 700): string[] {
  if (!config.medicalTerms)
    return [...(config.terms ?? []), ...config.dictionary.map((d) => d.to)].slice(0, max);
  const out: string[] = [];
  const seen = new Set<string>();
  const add = (s: string) => {
    const w = s.trim();
    if (w.length < 2 || w.length > 30 || seen.has(w)) return;
    seen.add(w);
    out.push(w);
  };
  for (const w of config.terms ?? []) add(w); // 専門用語フォルダの語は最優先
  for (const d of config.dictionary) add(d.to);
  for (const w of ECHO_PHRASE_HINTS) add(w); // エコーの項目名（LVDd・TRPG など）を聞き取りやすくする
  for (const [canonical] of specialtyReplacements) add(canonical);
  for (const w of COMMON_DRUG_HINTS) add(w);
  for (const [, canonical] of MEDICAL_REPLACEMENTS) add(canonical);
  return out.slice(0, max);
}
/**
 * 認識の候補（n-best）の採点: 補正後の文に含まれる医学用語（辞書・診療科・ユーザー辞書）と薬剤名の数。
 * 同じ文でも、医学用語として正しく聞き取れた候補ほど高くなる。
 */
export function medicalScore(text: string): number {
  if (!config.medicalTerms) return 0;
  const t = applyMedicalReadings(applyUserDictionary(text));
  let s = 0;
  for (const w of protectedWords()) if (w.length >= 3 && t.includes(w)) s++;
  for (const m of t.matchAll(/[ァ-ヴー]{4,}/g)) if (isKnownDrug(m[0])) s++;
  return s;
}

export function applyMedicalReadings(text: string): string {
  if (!config.medicalTerms) return text;
  let result = text;
  for (const [reading, canonical] of [...MEDICAL_REPLACEMENTS, ...specialtyReplacements]) {
    if (result.includes(reading)) result = result.split(reading).join(canonical);
  }
  // かなの音のまま返った語（ヒダリカハイヤシンジュンエイ）を、医学語彙の組み合わせで漢字へ
  setUserReadings(config.dictionary);
  setExtraNames(config.terms ?? []);
  result = convertKanaRuns(result);
  return correctDrugNames(correctDiseaseNames(result), protectedWords());
}

/**
 * 言い直し（「火曜日、いや水曜日」→「水曜日」）を反映する。
 * 医療用語の補正がオン（医療モード）のときは、数値・左右は「違う」「訂正」など明示的な訂正語のときだけ。
 */
export function rephraseText(text: string): string {
  return applyRephrase(text, config.medicalTerms);
}

/** 定型文の名前一覧（音声コマンドの照合用） */
export function getSnippetNames(): string[] {
  return config.snippetNames;
}

/** ユーザー辞書（誤り→正）。医療用語補正より優先して適用 */
export function applyUserDictionary(text: string): string {
  let result = text;
  for (const { from, to } of config.dictionary) {
    if (result.includes(from)) result = result.split(from).join(to);
  }
  return result;
}

// ---- 5. 句読点の自動挿入 ----
const END_MARK = /[。！？!?、\n]$/;
const QUESTION_END = /(?:ですか|ますか|ませんか|でしょうか|ですかね|でしたか|ましたか)$/;
const SENTENCE_END =
  /(?:です|ます|でした|ました|ません|ませんでした|ください|でしょう|ましょう|ですね|ますね|ですよ|ますよ|ありません|ない|した|している|していた|である|だ)$/;

function endMarkFor(text: string): '？' | '。' | '' {
  if (QUESTION_END.test(text)) return '？';
  if (SENTENCE_END.test(text)) return '。';
  return '';
}

// 続けて話すと Chrome は息継ぎまで 1 つの長い結果にまとめるため、文の途中にも句読点を入れる。
// 文末表現のあとに別の文が続く場合（次の文字が接続の助詞でない場合）だけ区切る。
//   「〜あります リポジトリは…」→「〜あります。リポジトリは…」
//   「〜ますが」「〜ですから」「〜でしたので」などは文が続くので区切らない
const CONTINUES = 'がのかけしとてねよでにはもをらばどなわぜ';
const QUESTION_INNER = new RegExp(
  `(ですか|ますか|ましたか|ませんか|でしたか|でしょうか)(?![${CONTINUES}。、！？\\n])(?=.)`,
  'g'
);
const SENTENCE_INNER = new RegExp(
  `(ですね|ますね|ですよ|ますよ|ませんでした|でした|ました|ません|ましょう|ください|です|ます)(?![${CONTINUES}。、！？\\n])(?=.)`,
  'g'
);

export function insertInnerPunctuation(text: string): string {
  return text.replace(QUESTION_INNER, '$1？').replace(SENTENCE_INNER, '$1。');
}

/** 血圧・体温・単位の整形（医療用語の補正がオンのときだけ） */
function applyMedicalNumbers(text: string): string {
  return config.medicalTerms ? formatMedicalNumbers(text) : text;
}

/** 1発話分の認識結果を整形（空文字になることがある） */
export function cleanSegment(raw: string): string {
  return insertInnerPunctuation(
    removeFillers(
      applyMedicalNumbers(
        applyMedicalReadings(applyUserDictionary(applySpokenPunctuation(removeJapaneseSpaces(raw))))
      )
    ).trim()
  );
}

/** 既存テキストに発話を追記（文末なら「。」「？」、そうでなければ「、」で接続） */
export function joinSegment(base: string, seg: string): string {
  if (!seg) return base;
  if (!base) return seg;
  if (END_MARK.test(base) || /^[。、！？\n]/.test(seg)) return `${base}${seg}`;
  const mark = endMarkFor(base);
  return `${base}${mark || '、'}${seg}`;
}

/** 貼り付け直前の仕上げ（文末表現がはっきりしている場合だけ句点を付ける） */
export function finalizeText(text: string): string {
  const t = text.trim();
  if (!t || END_MARK.test(t)) return t;
  return `${t}${endMarkFor(t)}`;
}

// ---- 音声コマンド: 「いまの取り消し」で直前の1文を消す ----
// （「全部消して」「一文字削除」「入力終了」「定型 ○○」は shared/voiceCommands.ts）
export function isUndoCommand(text: string): boolean {
  return parseEditCommand(text)?.kind === 'undo';
}

/** 末尾の1文を取り除く（直前の「。」「？」「！」「改行」まで戻す） */
export function removeLastSentence(text: string): string {
  const trimmed = text.replace(/[。！？!?、\s]+$/, '');
  const idx = Math.max(
    trimmed.lastIndexOf('。'),
    trimmed.lastIndexOf('？'),
    trimmed.lastIndexOf('！'),
    trimmed.lastIndexOf('\n')
  );
  return idx >= 0 ? trimmed.slice(0, idx + 1) : '';
}
