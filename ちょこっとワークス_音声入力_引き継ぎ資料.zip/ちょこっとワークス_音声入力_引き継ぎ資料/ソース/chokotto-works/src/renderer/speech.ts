import './engine.css';
import {
  ensureMicrophonePermission,
  ensureOnDeviceSpeechReady,
  getOnDeviceSpeechStatus,
  speechErrorMessage,
  startLiveSpeech,
  type LiveSpeechOptions,
} from '@meditoku/speech-common';
import { IPC } from '../shared/ipc';
import {
  cleanSegment,
  finalizeText,
  getMedicalPhraseHints,
  medicalScore,
  getSnippetNames,
  isWarmMic,
  joinSegment,
  rephraseText,
  removeLastSentence,
  setPostprocessConfig,
} from './textPostprocess';
import {
  isTemplateEnd,
  isTemplateNext,
  nextTemplateHeader,
  matchSnippetCommand,
  matchTemplateSection,
  matchTemplateStart,
  parseEditCommand,
  parseInsertCommand,
  formatInsert,
  removeLastChars,
  type EditCommand,
  type TemplateMode,
} from '../shared/voiceCommands';
import {
  applyFix,
  listMarker,
  parseFormatCommand,
  stripEmptyMarker,
  type FormatCommand,
  type ListStyle,
} from '../shared/formatCommands';
import { toDb } from '../shared/micCheck';

/**
 * 音声認識エンジン（Edge/Chrome のアプリウィンドウで動作）。
 * Electron 本体とは localhost のブリッジ（SSE + POST）で通信する。
 */

/** 話し終わりと判断する無音の長さ（長文で考えながら話しても切れないよう長め） */
// 自動終了はしない（Enter / Ctrl+Shift+Space で終了）。ただしマイクの消し忘れで
// Enter キーを奪ったままにならないよう、10分間まったく音声が無ければ安全のため終了する。
const SILENCE_MS = 10 * 60 * 1000;
/** セットアップで言語パック・マイク許可の確認が済んだか（済んでいれば開始時の再確認を省略） */
let preflightDone = false;
let silenceTimer: ReturnType<typeof setTimeout> | null = null;

const params = new URLSearchParams(location.search);
const token = params.get('t') ?? '';
// 診断用: ?v=xxx があればタイトルに付ける（起動方法の比較用）
const variantLabel = params.get('v');
if (variantLabel) document.title = `[${variantLabel}] ${document.title}`;

const statusEl = document.getElementById('status')!;
const detailEl = document.getElementById('detail')!;
const actionBtn = document.getElementById('action') as HTMLButtonElement;

let stopHandle: (() => void) | null = null;
let buffer = '';
let interim = '';
/** buffer の末尾が定型文の挿入結果のとき true（続けて話した文に句読点を足さない） */
let tailRaw = false;
/** 見出し入力モード（SOAP・内視鏡所見）。null なら通常の入力 */
let templateMode: TemplateMode | null = null;
/** 見出しモードで今入力している見出し（S) など） */
let currentHeader = '';

/** 画面に出す案内（見出しモード・箇条書き中の「次の一言」） */
function hint(): string | undefined {
  if (templateMode) {
    const next = nextTemplateHeader(templateMode, currentHeader);
    return next
      ? `${currentHeader} を入力中 ／ 「次」で ${next} へ`
      : `${currentHeader} を入力中 ／ 「入力終わり」で確定`;
  }
  if (listStyle) return '箇条書き中 ／ 「次」で次の項目、「箇条書き終わり」で終了';
  return undefined;
}
let listening = false;
let flushing = false;
/** この音声入力で「話せます」に切り替え済みか */
let readyShown = false;
let sessionSeq = 0;

// ---- マイクの待機（設定オン時だけ。話し始めの取りこぼしを減らす）----
let warmStream: MediaStream | null = null;
let warmTrack: MediaStreamTrack | null = null;
async function syncWarmMic(): Promise<void> {
  if (isWarmMic()) {
    if (warmTrack && warmTrack.readyState === 'live') return;
    try {
      warmStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      warmTrack = warmStream.getAudioTracks()[0] ?? null;
    } catch {
      warmStream = null;
      warmTrack = null;
    }
  } else if (warmStream) {
    warmStream.getTracks().forEach((t) => t.stop());
    warmStream = null;
    warmTrack = null;
  }
}

// ---- ブリッジ ----
const listeners = new Map<string, Array<(payload?: any) => void>>();
/** 話の間が空いたときに「、」「。」を自動で付けるか（設定。既定は付けない） */
let pausePunct = false;

function send(channel: string, payload?: unknown) {
  void fetch(`/api/send?t=${token}`, {
    method: 'POST',
    body: JSON.stringify({ channel, payload }),
  }).catch(() => {});
}

function onChannel(channel: string, cb: (payload?: any) => void) {
  listeners.set(channel, [...(listeners.get(channel) ?? []), cb]);
}

const events = new EventSource(`/api/events?t=${token}`);
events.onmessage = (e) => {
  const { channel, payload } = JSON.parse(e.data) as { channel: string; payload?: unknown };
  if (channel === 'replaced') {
    window.close();
    return;
  }
  listeners.get(channel)?.forEach((cb) => cb(payload));
};
events.onerror = () => {
  // アプリ本体が終了した場合はこのウィンドウも閉じる
  setTimeout(() => {
    if (events.readyState !== EventSource.OPEN) window.close();
  }, 8000);
};

let previewSeq = 0;
const api = {
  sendStatus: (status: string, message?: string) => send(IPC.SPEECH_STATUS, { status, message }),
  // 順序番号: 並行して送られた途中結果が入れ替わって届いても、古いものを無視できるようにする
  sendPreview: (text: string) => send(IPC.SPEECH_PREVIEW, { text, seq: ++previewSeq }),
  sendCommit: (text: string) => send(IPC.SPEECH_COMMIT, { text }),
  sendError: (code: string, message: string) => send(IPC.SPEECH_ERROR, { code, message }),
  /** 音声の言い直し（「○○を△△に訂正」）で直した語。正が確かな医学用語なら、本体が辞書に自動で覚える */
  sendLearn: (from: string, to: string) => send(IPC.SPEECH_LEARN, { from, to }),
  sendReadyResult: (ok: boolean, status: string, mic?: string) =>
    send(IPC.SPEECH_READY_RESULT, { ok, status, mic }),
};

function setStatus(status: string, message?: string) {
  api.sendStatus(status, message);
}

// ---- 画面表示 ----
function setMessage(title: string, detail: string) {
  statusEl.textContent = title;
  detailEl.textContent = detail;
}

function setAction(label: string | null, handler?: () => void) {
  if (!label) {
    actionBtn.hidden = true;
    actionBtn.onclick = null;
    return;
  }
  actionBtn.hidden = false;
  actionBtn.disabled = false;
  actionBtn.textContent = label;
  actionBtn.onclick = handler ?? null;
}

// 前の確定からこれ以上の間が空いたら、文末表現がはっきりしなくても句点で区切る（ミリ秒）
const PAUSE_SENTENCE_MS = 1800;
// 話し終えてこれだけ間が空いたら、続きの文を待たずに、その場で読点（、）を付ける（ミリ秒）。
// 次の発話の頭に付けると、間に別の場所へカーソルを動かしたとき、動かした先の行頭に付いてしまうため。
const PAUSE_COMMA_MS = 1000;
let lastFinalAt = 0;
let pauseBeforeSeg = 0;
let pauseCommaTimer: ReturnType<typeof setTimeout> | null = null;
let pausePeriodTimer: ReturnType<typeof setTimeout> | null = null;
/** buffer の末尾の「、」が、間が空いたことで自動で付けたものか（入力を終えるときは取り除く） */
let autoComma = false;

function clearPauseTimers(): void {
  if (pauseCommaTimer) clearTimeout(pauseCommaTimer);
  if (pausePeriodTimer) clearTimeout(pausePeriodTimer);
  pauseCommaTimer = null;
  pausePeriodTimer = null;
}

/** 確定のあと、間が空いたら前の文の末尾に区切りを付ける（読点 → さらに空いたら句点に） */
function schedulePauseMarks(): void {
  clearPauseTimers();
  if (!pausePunct || tailRaw || !buffer.trim()) return;
  pauseCommaTimer = setTimeout(() => {
    pauseCommaTimer = null;
    if (!listening || interim || tailRaw || !buffer.trim() || /[。！？!?、\n]$/.test(buffer))
      return;
    buffer = `${buffer}、`;
    autoComma = true;
    broadcastOverlay();
  }, PAUSE_COMMA_MS);
  pausePeriodTimer = setTimeout(() => {
    pausePeriodTimer = null;
    if (!listening || interim || !autoComma || !buffer.endsWith('、')) return;
    if (Array.from(buffer).length < 6) return;
    buffer = `${buffer.slice(0, -1)}。`;
    autoComma = false;
    broadcastOverlay();
  }, PAUSE_SENTENCE_MS);
}

// ---- 診断表示（原因調査用: 直近のイベントを画面に出す） ----
const debugLog: string[] = [];
const debugEnabled = new URLSearchParams(location.search).has('debug');
function showDebug(ev: string) {
  if (!debugEnabled) return;
  debugLog.push(ev);
  if (debugLog.length > 8) debugLog.shift();
  detailEl.textContent = `診断: ${debugLog.join(' → ')}`;
}

// ---- 音声認識 ----
/** 既存テキストに発話を追記（定型文・見出しの直後は、そのまま続ける）。言い直しも反映する */
function appendSeg(base: string, seg: string): string {
  return rephraseText(tailRaw ? `${base}${seg}` : joinSegment(base, seg));
}

/** 見出し（S) や 部位： など）を改行のあとに入れる。見出しの直後の発話には句読点を足さない */
function insertHeader(header: string): void {
  interim = '';
  const head = buffer.trim() ? finalizeText(buffer) : '';
  buffer = head ? `${head}\n${header}` : header;
  currentHeader = header;
  tailRaw = true;
  touchSilenceTimer();
  broadcastOverlay();
}

/** 見出しモードの開始・見出し・終了の音声コマンドか（該当すれば処理して true） */
function isTemplateCommand(text: string): boolean {
  return Boolean(
    matchTemplateStart(text) ||
    (templateMode &&
      (isTemplateEnd(text) || isTemplateNext(text) || matchTemplateSection(text, templateMode)))
  );
}

function runTemplateCommand(text: string): void {
  const start = matchTemplateStart(text);
  if (start) {
    templateMode = start;
    insertHeader(start.firstHeader);
    return;
  }
  if (!templateMode) return;
  if (isTemplateEnd(text)) {
    templateMode = null;
    interim = '';
    touchSilenceTimer();
    broadcastOverlay();
    return;
  }
  if (isTemplateNext(text)) {
    const nx = nextTemplateHeader(templateMode, currentHeader);
    if (nx) insertHeader(nx);
    else setStatus('listening', hint());
    return;
  }
  const header = matchTemplateSection(text, templateMode);
  if (header) insertHeader(header);
}

function broadcastOverlay() {
  const preview = appendSeg(buffer, interim);
  api.sendPreview(preview);
}

/** 箇条書き・番号リストの入力中の種類と、次に付ける番号 */
let listStyle: ListStyle | null = null;
let listNo = 0;

function currentMarker(): string {
  return listStyle ? listMarker(listStyle, listNo) : '';
}

/** 行頭記号を付けて新しい項目を始める（直前の項目を確定してから改行） */
function startItem(): void {
  if (!listStyle) return;
  const head = buffer.trim() ? finalizeText(buffer) : '';
  const base = head.replace(/\n+$/, '');
  listNo += 1;
  buffer = `${base}${base ? '\n' : ''}${listMarker(listStyle, listNo)}`;
  tailRaw = true;
}

/** 書式コマンド（箇条書き・番号・段落・言い直し）を実行する */
function runFormatCommand(cmd: FormatCommand): void {
  interim = '';
  if (cmd.kind === 'list-start') {
    listStyle = cmd.style;
    listNo = 0;
    startItem();
  } else if (cmd.kind === 'list-next') {
    // 中身が空の項目のまま「次」と言ったときは、行頭記号を増やさない
    if (!buffer.endsWith(currentMarker())) startItem();
  } else if (cmd.kind === 'list-end') {
    if (listStyle) {
      buffer = stripEmptyMarker(buffer, currentMarker());
      listStyle = null;
      if (buffer.trim() && !buffer.endsWith('\n')) buffer = `${finalizeText(buffer)}\n`;
      tailRaw = true;
    }
  } else if (cmd.kind === 'paragraph') {
    if (listStyle) buffer = stripEmptyMarker(buffer, currentMarker());
    listStyle = null;
    const head = buffer.trim() ? finalizeText(buffer).replace(/\n+$/, '') : '';
    buffer = head ? `${head}\n\n` : '';
    tailRaw = true;
  } else {
    const r = applyFix(buffer, cmd.from, cmd.to);
    if (r.ok) {
      buffer = r.text;
      tailRaw = false;
      api.sendLearn(cmd.from, cmd.to);
    } else {
      setStatus('listening', `「${cmd.from}」が見つかりませんでした`);
    }
  }
  touchSilenceTimer();
  broadcastOverlay();
}
/** 音声で編集コマンドを実行する（バッファを書き換えると、ライブ入力が差分でバックスペースする） */
function runEditCommand(cmd: EditCommand): void {
  interim = '';
  if (cmd.kind === 'finish') {
    void finishAndFlush();
    return;
  }
  if (cmd.kind === 'undo') buffer = removeLastSentence(buffer);
  else if (cmd.kind === 'clear') buffer = '';
  else buffer = removeLastChars(buffer, cmd.n);
  tailRaw = false;
  touchSilenceTimer();
  broadcastOverlay();
}

/** 「定型 ○○」: 本体で変数を展開した定型文を取得して、入力中の文章に挿入する */
async function insertSnippetByVoice(name: string): Promise<void> {
  try {
    const res = await fetch(`/api/snippet?t=${token}&name=${encodeURIComponent(name)}`);
    if (!res.ok) throw new Error(String(res.status));
    const { text } = (await res.json()) as { text: string };
    if (!listening || !text) return;
    buffer = `${buffer}${text}`;
    tailRaw = true;
    interim = '';
    touchSilenceTimer();
    broadcastOverlay();
  } catch {
    setStatus('listening', `定型文「${name}」を取得できませんでした`);
  }
}

/** 最新のユーザー辞書・診療科設定を取得（音声入力の開始ごと。失敗しても前回の設定のまま続行） */
async function refreshConfig(): Promise<void> {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 1500);
    const res = await fetch(`/api/config?t=${token}`, { signal: ctrl.signal });
    clearTimeout(timer);
    if (res.ok) {
      const cfg = await res.json();
      pausePunct = cfg?.pausePunct === true;
      setPostprocessConfig(cfg);
    }
  } catch {
    /* 設定取得失敗は無視 */
  }
}

async function beginListening(): Promise<void> {
  if (listening) return;
  listening = true;
  buffer = '';
  interim = '';
  tailRaw = false;
  templateMode = null;
  currentHeader = '';
  listStyle = null;
  listNo = 0;
  lastFinalAt = 0;
  pauseBeforeSeg = 0;
  clearPauseTimers();
  autoComma = false;
  readyShown = false;
  // 準備中に中止（stopEngine）されたかを判定する番号。stopEngine が進めるので、ずれたら中止済み
  const sessionNo = ++sessionSeq;
  setStatus('preparing', '端末内音声認識を準備中…');
  // 医学用語の聞き取り指定にユーザー辞書が要るので、設定を先に取得する（ローカル通信で数ミリ秒。最大1.5秒）
  await refreshConfig();
  await syncWarmMic();
  if (sessionNo !== sessionSeq) return; // 準備中に中止された

  const liveOpts: LiveSpeechOptions = {
    // オンデバイスのみ（clinical）: 日本語パック未導入ならクラウドへ送らずエラーにする
    privacyMode: 'clinical',
    // セットアップ（checkReady）で言語パック・マイク許可を確認済みなら、開始時の再確認を省いて即開始
    skipPreflight: preflightDone,
    // Chrome 155 では quality 指定でオンデバイスが unavailable になるため指定しない
    quality: 'default',
    vocabulary: 'soap',
    // 医学用語をエンジンに優先して聞き取らせる（未対応のChromeでは自動で外れる）
    localPhrases: getMedicalPhraseHints(),
    // 認識の候補(n-best)のうち、医学用語を多く含むものを選ぶ
    scoreAlternative: medicalScore,
    // 無音判定は共通部品に任せない（確定結果の後しか数えず、話している最中に切れるため）。
    // 途中結果・確定結果のどちらが来てもタイマーをリセットする自前方式にする。
    onPreparing: (msg) => {
      if (sessionNo === sessionSeq) setStatus('preparing', msg);
    },
    onDebug: (ev) => {
      showDebug(ev);
      // マイクが実際に音を拾い始めた瞬間に「話せます」にする（準備中に話し始めて取りこぼすのを防ぐ）
      if (ev === 'audiostart') markReady();
    },
    audioTrack: warmTrack ?? undefined,
    onInterim: (raw) => {
      // 終了（Enter）の後に遅れて届いた結果は無視する（同じ文が二重に入るのを防ぐ）
      if (!listening) return;
      clearPauseTimers(); // 話し始めたので、間が空いたときの区切りは付けない
      const text = cleanSegment(raw);
      // 新しい発話の最初の結果: 前の確定からの間（ポーズ）の長さを覚えておく
      if (!interim && lastFinalAt) pauseBeforeSeg = Date.now() - lastFinalAt;
      // 「いまの取り消し」「定型 ○○」などの命令は画面に打たない（確定時に処理する）
      interim =
        parseEditCommand(text) ||
        parseFormatCommand(text, listStyle !== null) ||
        matchSnippetCommand(text, getSnippetNames()) ||
        isTemplateCommand(text)
          ? ''
          : text;
      touchSilenceTimer();
      setStatus('listening', hint());
      broadcastOverlay();
    },
    onFinal: (raw) => {
      if (!listening) return;
      const text = cleanSegment(raw);
      if (!text.trim()) return;
      clearPauseTimers();
      autoComma = false; // 付けてあった「、」は、そのまま文の区切りとして残る
      const command = parseEditCommand(text);
      if (command) {
        runEditCommand(command);
        return;
      }
      const fmtCmd = parseFormatCommand(text, listStyle !== null);
      if (fmtCmd) {
        runFormatCommand(fmtCmd);
        return;
      }
      if (isTemplateCommand(text)) {
        runTemplateCommand(text);
        return;
      }
      const insertCmd = parseInsertCommand(text);
      if (insertCmd) {
        // 「今日の日付」「いまの時刻」: 令和の日付・時刻をその場で入れる
        interim = '';
        buffer = `${buffer}${formatInsert(insertCmd)}`;
        tailRaw = true;
        touchSilenceTimer();
        broadcastOverlay();
        return;
      }
      const snippetName = matchSnippetCommand(text, getSnippetNames());
      if (snippetName) {
        interim = '';
        void insertSnippetByVoice(snippetName);
        return;
      }
      // 文末表現がはっきりしなくても、長い間（ポーズ）があったら前の文はそこで終わりとみなして句点を付ける
      if (
        pausePunct &&
        pauseBeforeSeg >= PAUSE_SENTENCE_MS &&
        !tailRaw &&
        !/[。！？!?、\n]$/.test(buffer) &&
        Array.from(buffer).length >= 6
      ) {
        buffer = `${buffer}。`;
      }
      pauseBeforeSeg = 0;
      lastFinalAt = Date.now();
      // 確定したらすぐ文末の句点を付ける（次の発話や無音タイマーを待たない）
      // 箇条書き中は、話の途中の「改行」も次の項目にする
      const seg = listStyle
        ? text.replace(/\n/g, () => `\n${listMarker(listStyle!, ++listNo)}`)
        : text;
      buffer = finalizeText(appendSeg(buffer, seg));
      tailRaw = false;
      interim = '';
      touchSilenceTimer();
      setStatus('listening', hint());
      broadcastOverlay();
      schedulePauseMarks();
    },
    onError: (code) => {
      clearSilenceTimer();
      listening = false;
      stopHandle = null;
      const message = speechErrorMessage(code);
      api.sendError(code, message);
      setStatus('error', message);
    },
    onEnd: () => {
      if (!listening) return;
      setStatus('listening', '音声入力が一時停止しました。もう一度お試しください');
    },
  };
  const handle = await startLiveSpeech(liveOpts);

  if (sessionNo !== sessionSeq) {
    // 準備中に中止された: 遅れて始まった認識を止める（マイクを掴んだままにしない）
    handle?.stop();
    return;
  }
  if (!handle) {
    listening = false;
    setStatus('error', '音声認識を開始できませんでした');
    return;
  }

  stopHandle = handle.stop;
  touchSilenceTimer(); // 何も話さないまま放置された場合の安全タイマー
  // 'audiostart' が来ない環境でも、少し待てば「話せます」にする
  setTimeout(() => {
    if (sessionNo === sessionSeq) markReady();
  }, 2500);
}

/** 「話せます」への切り替え（1回の音声入力につき1回だけ） */
function markReady(): void {
  if (readyShown || !listening) return;
  readyShown = true;
  setStatus('listening', hint());
}

function clearSilenceTimer() {
  if (silenceTimer) {
    clearTimeout(silenceTimer);
    silenceTimer = null;
  }
}

/** 音声（途中結果・確定結果）を受け取るたびにリセット。SILENCE_MS 無音が続いたら自動で貼り付け */
function touchSilenceTimer() {
  clearSilenceTimer();
  silenceTimer = setTimeout(() => {
    void finishAndFlush();
  }, SILENCE_MS);
}

function stopEngine(): string {
  clearSilenceTimer();
  clearPauseTimers();
  // 間が空いたことで自動で付けた末尾の「、」は、入力を終えるときは取り除く
  if (autoComma && buffer.endsWith('、')) buffer = buffer.slice(0, -1);
  autoComma = false;
  listening = false;
  sessionSeq++; // 準備中だった開始処理を無効にする
  stopHandle?.();
  stopHandle = null;
  // 中身が空の行頭記号（・ や 3. だけ）は残さない
  if (listStyle && !interim.trim()) buffer = stripEmptyMarker(buffer, currentMarker());
  // 確定前の最後の途中結果も取りこぼさない
  const joined = appendSeg(buffer, interim);
  // 定型文で終わっているときは、句点などを足さない
  const result = tailRaw && !interim ? joined : finalizeText(joined);
  interim = '';
  buffer = '';
  tailRaw = false;
  listStyle = null;
  listNo = 0;
  return result;
}

async function finishAndFlush(): Promise<void> {
  if (flushing) return;
  if (!listening && !buffer.trim() && !interim.trim()) return;
  flushing = true;
  try {
    const text = stopEngine();
    if (text) {
      setStatus('pasting');
      api.sendCommit(text);
    } else {
      setStatus('idle');
    }
  } finally {
    flushing = false;
  }
}

// ---- セットアップ（マイク許可） ----
async function checkReady(): Promise<void> {
  setAction(null);
  setMessage('マイクの許可を確認中…', '表示された許可ダイアログで「許可」を押してください。');
  const mic = await ensureMicrophonePermission(60000);
  if (mic === 'granted') {
    // オンデバイス専用のため、日本語音声パックの導入まで確認する（未導入ならダウンロード）
    setMessage('日本語音声パックを確認中…', '初回はダウンロードに時間がかかることがあります。');
    const before = await getOnDeviceSpeechStatus('ja-JP', 'default');
    let pack = await ensureOnDeviceSpeechReady({
      quality: 'default',
      onProgress: (msg) => setMessage('日本語音声パックを準備中…', msg),
    });
    // 念のため dictation 指定でも試す
    if (!pack.ok && pack.status !== 'unsupported') {
      pack = await ensureOnDeviceSpeechReady({
        quality: 'dictation',
        onProgress: (msg) => setMessage('日本語音声パックを準備中…', msg),
      });
    }
    const ua = navigator.userAgent.match(/(Edg|Chrome)\/([\d.]+)/);
    let variants = '';
    if (!pack.ok) {
      // 切り分け用: 条件を変えたときの可否を並べて表示する
      const SR = (window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition;
      const tries: Array<[string, unknown]> = [
        ['ja-JP/local', { langs: ['ja-JP'], processLocally: true }],
        ['ja/local', { langs: ['ja'], processLocally: true }],
        ['en-US/local', { langs: ['en-US'], processLocally: true }],
        ['ja-JP/cloud', { langs: ['ja-JP'], processLocally: false }],
      ];
      const out: string[] = [];
      for (const [label, opt] of tries) {
        try {
          out.push(`${label}=${SR?.available ? await SR.available(opt) : 'no-api'}`);
        } catch (e) {
          out.push(`${label}=err`);
        }
      }
      variants = `\n${out.join(' / ')}`;
    }
    const diag = `状態: ${before} → ${pack.status} / ${ua ? `${ua[1]} ${ua[2]}` : navigator.userAgent}${variants}`;
    if (!pack.ok) {
      const detail =
        (pack.status === 'unsupported'
          ? 'お使いのブラウザ/OSはオンデバイス音声認識に対応していません。Edge または Chrome を最新版に更新してください。'
          : '日本語音声パックを導入できませんでした。ネットワーク接続を確認して再確認してください。') +
        `\n(${diag})`;
      setMessage('音声パックの確認が必要です', detail);
      setAction('再確認', () => void checkReady());
      api.sendReadyResult(false, pack.status, mic);
      return;
    }
    setMessage(
      '準備完了',
      'Ctrl+Shift+Space で音声入力を開始できます。このウィンドウは最小化して構いません。'
    );
    setAction(null);
    preflightDone = true;
    api.sendReadyResult(true, 'on-device', mic);
    return;
  }
  const msg =
    mic === 'no-device'
      ? 'マイクが見つかりません。接続を確認してください。'
      : 'マイクが許可されていません。アドレスバー左のアイコンからマイクを許可してください。';
  setMessage('マイクの確認が必要です', msg);
  setAction('再確認', () => void checkReady());
  api.sendReadyResult(false, 'general', mic);
}

onChannel(IPC.SPEECH_START, () => void beginListening());
// 設定でマイク待機がオンなら、起動時から準備しておく（失敗しても通常の開始にはなる）
void refreshConfig().then(syncWarmMic);
onChannel(IPC.SPEECH_STOP, () => {
  stopEngine();
  setStatus('idle');
});
onChannel(IPC.SPEECH_FLUSH, () => void finishAndFlush());
onChannel(IPC.SPEECH_CHECK_READY, () => void checkReady());
onChannel(IPC.SPEECH_MIC_CHECK, () => void runMicCheck());

// ---- マイク診断（静かな2秒 + 話す5秒の音量を測り、結果を本体へ送る） ----
const MIC_QUIET_MS = 2000;
const MIC_SPEAK_MS = 5000;

function percentile(values: number[], p: number): number {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * p))];
}

async function runMicCheck(): Promise<void> {
  if (listening) {
    send(IPC.SPEECH_MIC_RESULT, {
      error: '音声入力の途中です。終了してからもう一度お試しください。',
    });
    return;
  }
  let stream: MediaStream | null = null;
  let ctx: AudioContext | null = null;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const label = stream.getAudioTracks()[0]?.label ?? '';
    ctx = new AudioContext();
    const source = ctx.createMediaStreamSource(stream);
    // 最小化されたウィンドウでは setInterval が間引かれるため、音声処理側のコールバックで測る
    const processor = ctx.createScriptProcessor(2048, 1, 1);
    const mute = ctx.createGain();
    mute.gain.value = 0;
    source.connect(processor);
    processor.connect(mute);
    mute.connect(ctx.destination);

    let phase: 'quiet' | 'speak' | 'done' = 'quiet';
    const quietRms: number[] = [];
    const speechRms: number[] = [];
    let samples = 0;
    let clipped = 0;
    processor.onaudioprocess = (e) => {
      const data = e.inputBuffer.getChannelData(0);
      let sum = 0;
      let clip = 0;
      for (let i = 0; i < data.length; i++) {
        const v = data[i];
        sum += v * v;
        if (Math.abs(v) >= 0.99) clip++;
      }
      const rms = Math.sqrt(sum / data.length);
      if (phase === 'quiet') {
        quietRms.push(rms);
      } else if (phase === 'speak') {
        speechRms.push(rms);
        samples += data.length;
        clipped += clip;
      }
    };

    send(IPC.SPEECH_MIC_PROGRESS, { message: 'マイク診断: 2秒間、静かにしてください…' });
    await new Promise((r) => setTimeout(r, MIC_QUIET_MS));
    phase = 'speak';
    send(IPC.SPEECH_MIC_PROGRESS, {
      message: 'マイク診断: 今から5秒間、いつもの声で話してください（例: 本日はどうされましたか）',
    });
    await new Promise((r) => setTimeout(r, MIC_SPEAK_MS));
    phase = 'done';

    send(IPC.SPEECH_MIC_RESULT, {
      measurement: {
        label,
        noiseDb: toDb(percentile(quietRms, 0.5)),
        speechDb: toDb(percentile(speechRms, 0.9)),
        clipRatio: samples ? clipped / samples : 0,
      },
    });
  } catch (e) {
    send(IPC.SPEECH_MIC_RESULT, { error: `マイクを使えませんでした: ${String(e)}` });
  } finally {
    stream?.getTracks().forEach((t) => t.stop());
    if (ctx) void ctx.close();
  }
}

void checkReady();

// ---- 診断ツール（原因調査用）: 素の Web Speech API で端末内/クラウドを個別に試す ----
function runRawTest(local: boolean) {
  const out = document.getElementById('diag-out')!;
  const lines: string[] = [];
  const log = (s: string) => {
    lines.push(s);
    out.textContent = lines.slice(-14).join('\n');
  };
  const SR = (window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition;
  if (!SR) {
    log('SpeechRecognition なし');
    return;
  }
  const rec = new SR();
  rec.lang = 'ja-JP';
  rec.continuous = false;
  rec.interimResults = true;
  rec.processLocally = local;
  log(`--- ${local ? '端末内' : 'クラウド'} テスト開始: 何か話してください ---`);
  for (const n of [
    'start',
    'audiostart',
    'soundstart',
    'speechstart',
    'speechend',
    'audioend',
    'end',
    'nomatch',
  ]) {
    rec.addEventListener(n, () => log(n));
  }
  rec.addEventListener('error', (e: any) => log(`error: ${e.error} ${e.message ?? ''}`));
  rec.addEventListener('result', (e: any) => {
    const r = e.results[e.results.length - 1];
    log(`result(${r.isFinal ? '確定' : '途中'}): ${r[0].transcript}`);
  });
  try {
    rec.start();
  } catch (e) {
    log(`start 例外: ${String(e)}`);
  }
}
document.getElementById('diag-local')!.onclick = () => runRawTest(true);
document.getElementById('diag-cloud')!.onclick = () => runRawTest(false);

// マイク診断: 使われるデバイス名と、5秒間の音量(ピーク)を表示
document.getElementById('diag-mic')!.onclick = async () => {
  const out = document.getElementById('diag-out')!;
  out.textContent = 'マイク確認中… 5秒間、普通の声で話してください';
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const track = stream.getAudioTracks()[0];
    const settings = track.getSettings();
    const devices = (await navigator.mediaDevices.enumerateDevices())
      .filter((d) => d.kind === 'audioinput')
      .map((d) => `・${d.label || d.deviceId}`)
      .join('\n');
    const ctx = new AudioContext();
    const src = ctx.createMediaStreamSource(stream);
    const an = ctx.createAnalyser();
    an.fftSize = 1024;
    src.connect(an);
    const buf = new Float32Array(an.fftSize);
    let peak = 0;
    const t0 = Date.now();
    await new Promise<void>((resolve) => {
      const tick = () => {
        an.getFloatTimeDomainData(buf);
        let sum = 0;
        for (const v of buf) sum += v * v;
        peak = Math.max(peak, Math.sqrt(sum / buf.length));
        out.textContent = `使用中: ${track.label}\nsampleRate=${settings.sampleRate} muted=${track.muted} enabled=${track.enabled}\n音量ピーク(RMS)=${peak.toFixed(4)}（0.02未満は小さすぎ）\n--- 候補 ---\n${devices}`;
        if (Date.now() - t0 < 5000) requestAnimationFrame(tick);
        else resolve();
      };
      tick();
    });
    stream.getTracks().forEach((t) => t.stop());
    void ctx.close();
  } catch (e) {
    out.textContent = `マイク取得エラー: ${String(e)}`;
  }
};
