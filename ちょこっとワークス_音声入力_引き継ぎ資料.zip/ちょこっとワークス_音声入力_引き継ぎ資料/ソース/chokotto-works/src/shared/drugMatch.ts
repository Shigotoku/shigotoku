import { DRUG_BRAND_NAMES, DRUG_GENERIC_NAMES } from './drugNames';

/**
 * 薬剤名の補正: 音声認識が似た別のカタカナ（1〜2文字違い）にした薬剤名を、辞書の薬剤名へ直す。
 * 例: 「ロキソニ」→「ロキソニン」「アムロジビン」→「アムロジピン」
 * 誤って普通の語を薬剤名にしないよう、長い語（5文字以上）で、候補が1つに決まるときだけ直す。
 */
const BASE_NAMES: string[] = Array.from(new Set([...DRUG_GENERIC_NAMES, ...DRUG_BRAND_NAMES]));
let NAME_SET = new Set<string>();
let BY_LEN = new Map<number, string[]>();
let BY_SKELETON = new Map<string, string | null>();

/** 濁点・半濁点・小書き・長音を無視した形（バ/パ/ハ、ビ/ピ のような聞き違いを同じとみなす） */
export function skeleton(word: string): string {
  return word
    .normalize('NFD')
    .replace(/[\u3099\u309A]/g, '')
    .replace(/ー/g, '')
    .replace(/ヴ/g, 'ウ')
    .replace(/[ァィゥェォャュョッヮ]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 1));
}

function build(extra: string[]): void {
  const names = Array.from(new Set([...BASE_NAMES, ...extra]));
  NAME_SET = new Set(names);
  BY_LEN = new Map();
  BY_SKELETON = new Map();
  for (const n of names) {
    const len = Array.from(n).length;
    if (len < 5) continue;
    const list = BY_LEN.get(len);
    if (list) list.push(n);
    else BY_LEN.set(len, [n]);
    const k = skeleton(n);
    BY_SKELETON.set(k, BY_SKELETON.has(k) ? null : n);
  }
}
build([]);

let extraKey = '';
/** ユーザーの専門用語フォルダのカタカナ語（薬剤名など）も、聞き間違いの補正先に加える */
export function setExtraNames(list: string[]): void {
  const extra = Array.from(new Set(list.filter((w) => /^[ァ-ヴー]{5,}$/.test(w))));
  const key = extra.join('|');
  if (key === extraKey) return;
  extraKey = key;
  build(extra);
}

/** 編集距離（max を超えたら max+1 を返す） */
export function editDistance(a: string, b: string, max: number): number {
  const x = Array.from(a);
  const y = Array.from(b);
  if (Math.abs(x.length - y.length) > max) return max + 1;
  let prev = Array.from({ length: y.length + 1 }, (_, i) => i);
  for (let i = 1; i <= x.length; i++) {
    const cur = [i];
    let rowMin = i;
    for (let j = 1; j <= y.length; j++) {
      const v = Math.min(
        prev[j] + 1,
        cur[j - 1] + 1,
        prev[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1)
      );
      cur.push(v);
      if (v < rowMin) rowMin = v;
    }
    if (rowMin > max) return max + 1;
    prev = cur;
  }
  return prev[y.length];
}

/** 辞書にある薬剤名か */
export function isKnownDrug(word: string): boolean {
  return NAME_SET.has(word);
}

/** 1語（カタカナ）を、似た薬剤名へ。直せなければ元のまま */
export function nearestDrug(word: string): string {
  if (NAME_SET.has(word)) return word;
  const len = Array.from(word).length;
  if (len < 5) return word;
  // 濁点・半濁点・長音の違いだけで、薬剤名が1つに決まるとき（ビ/ピ、バ/パ など）
  const bySkel = BY_SKELETON.get(skeleton(word));
  if (bySkel) return bySkel;
  const max = len >= 9 ? 2 : 1;
  let best = '';
  // 点数 = 編集距離*2 + (長さが違えば1)。同じ長さの1文字違い（聞き間違い）を、文字の増減より優先する
  let bestScore = (max + 1) * 2;
  let tie = false;
  for (let l = len - max; l <= len + max; l++) {
    for (const cand of BY_LEN.get(l) ?? []) {
      const d = editDistance(word, cand, max);
      if (d > max) continue;
      const score = d * 2 + (l === len ? 0 : 1);
      if (score < bestScore) {
        best = cand;
        bestScore = score;
        tie = false;
      } else if (score === bestScore && cand !== best) {
        tie = true;
      }
    }
  }
  return best && !tie ? best : word;
}

/** 文中のカタカナ語を薬剤名へ補正（医療用語の補正がオンのときだけ呼ぶ） */
export function correctDrugNames(text: string, protectedWords?: Set<string>): string {
  return text.replace(/[ァ-ヴー]{5,}/g, (w) => (protectedWords?.has(w) ? w : nearestDrug(w)));
}
