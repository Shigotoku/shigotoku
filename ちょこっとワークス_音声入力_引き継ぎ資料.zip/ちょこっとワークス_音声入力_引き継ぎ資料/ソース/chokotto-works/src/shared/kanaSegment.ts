import { FUNCTION_WORDS, lexiconEntries } from './lexicon';
import { DISEASE_DATA, MODIFIER_DATA } from './diseaseNames';
import { MEDICAL_EXTRA_READINGS } from './medicalDict';
import { CLINIC_TERMS } from './clinicTerms';
import { SPECIALTIES } from './specialties';

/**
 * かな漢字変換（医学語彙版）。音声認識が知らない語を、カタカナ（またはひらがな）の音のまま返したとき、
 * 医学語彙の組み合わせで、文字列の全体を漢字の語へ直す。
 *   「ヒダリカハイヤシンジュンエイ」→「左下肺野浸潤影」
 * 全体を語彙で隙間なく説明できるときだけ直す（一部だけ分かるときは変えない）ので、普通の語を壊しにくい。
 */
const toHira = (s: string): string =>
  s.replace(/[ァ-ヶ]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0x60));
const KANA_ONLY = /^[ぁ-ゖー]+$/;
const MAX_READING = 30;

interface Entry {
  surface: string;
  content: boolean;
}

let lex: Map<string, Entry> | null = null;
const extra = new Map<string, Entry>();

function add(map: Map<string, Entry>, reading: string, surface: string, content: boolean): void {
  const r = toHira(reading.trim());
  if (!KANA_ONLY.test(r) || r.length > MAX_READING) return;
  const s = surface.trim();
  if (!s || (s === r && content)) return;
  if (!map.has(r)) map.set(r, { surface: s, content });
}

function build(): Map<string, Entry> {
  const m = new Map<string, Entry>();
  // 手で整えた部品語彙（部位・所見・程度）を最優先
  for (const [r, s] of lexiconEntries()) add(m, r, s, true);
  for (const [r, s] of FUNCTION_WORDS) add(m, r, s, false);
  // 辞書の「表記→読み」（ひらがな・カタカナの読みだけ）
  const fromTable = (tbl: Record<string, string[]>) => {
    for (const [surface, readings] of Object.entries(tbl))
      for (const r of readings) add(m, r, surface, true);
  };
  fromTable(MEDICAL_EXTRA_READINGS);
  fromTable(CLINIC_TERMS);
  for (const sp of SPECIALTIES) fromTable(sp.readings);
  // 標準病名マスター（読み\t病名）
  for (const line of DISEASE_DATA.split('\n')) {
    const i = line.indexOf('\t');
    if (i > 0) add(m, line.slice(0, i), line.slice(i + 1), true);
  }
  for (const line of MODIFIER_DATA.split('\n')) {
    const i = line.indexOf('\t');
    if (i > 0) add(m, line.slice(0, i), line.slice(i + 1), true);
  }
  return m;
}

function table(): Map<string, Entry> {
  if (!lex) lex = build();
  return lex;
}

/** ユーザー辞書の「ひらがなの読み→表記」を語彙に加える（使うたびに入れ替える） */
export function setUserReadings(pairs: Array<{ from: string; to: string }>): void {
  extra.clear();
  for (const p of pairs) add(extra, p.from, p.to, true);
}

function lookup(reading: string): Entry | undefined {
  return extra.get(reading) ?? table().get(reading);
}

/**
 * かなの1つながり（ひらがな換算）を、語彙の組み合わせで漢字の語にする。できなければ null。
 * 区切りの数が最も少ない組み合わせを選び、語彙の語（助詞だけでなく）を含むときだけ採用する。
 */
export function segmentKana(run: string): string | null {
  const h = toHira(run);
  const n = h.length;
  if (n < 4 || n > 80) return null;
  const INF = 1e9;
  const cost = new Array<number>(n + 1).fill(INF);
  const prev = new Array<number>(n + 1).fill(-1);
  const via = new Array<Entry | null>(n + 1).fill(null);
  cost[0] = 0;
  for (let i = 0; i < n; i++) {
    if (cost[i] >= INF) continue;
    for (let l = Math.min(MAX_READING, n - i); l >= 1; l--) {
      const e = lookup(h.slice(i, i + l));
      if (!e) continue;
      // 区切りの少なさを優先。1文字の語（助詞など）は少し不利にして、長い語彙語を選ばせる
      const c = cost[i] + 10 + (l === 1 ? 4 : 0) - Math.min(l, 8) * 0.1;
      if (c < cost[i + l]) {
        cost[i + l] = c;
        prev[i + l] = i;
        via[i + l] = e;
      }
    }
  }
  if (cost[n] >= INF) return null;
  const parts: Entry[] = [];
  for (let p = n; p > 0; p = prev[p]) parts.push(via[p] as Entry);
  parts.reverse();
  // 語彙の語（助詞・語尾以外）が2つ以上、または長い1語を含むときだけ。「の」「を」だけでは変えない
  const contents = parts.filter((e) => e.content);
  if (contents.length === 0) return null;
  const contentChars = contents.reduce((s, e) => s + Array.from(e.surface).length, 0);
  if (contents.length < 2 && contentChars < 3) return null;
  return parts.map((e) => e.surface).join('');
}

/** 文中のカタカナ・ひらがなの6文字以上のつながりを、語彙で全体を説明できるときだけ漢字の語へ直す */
export function convertKanaRuns(text: string): string {
  if (!/[ァ-ヴぁ-ゖー]{6}/.test(text)) return text;
  return text.replace(/[ァ-ヴー]{6,}|[ぁ-ゖー]{6,}/g, (run) => segmentKana(run) ?? run);
}
