/**
 * エコー（心エコー／腹部エコー）の音声入力用: 音声認識の文章を、項目名・数値の読み取りに向く形へそろえる。純粋関数。
 * - 全角→半角、英字は小文字、「e'」「s'」の言い方（イーダッシュ／イープライム）、漢数字（四十八→48）、
 *   「2点5／2ポイント5」→「2.5」。
 * - 項目名（別名）側にも同じ処理をかけるので、「一回拍出量」→「1回拍出量」のように揺れが出ない。
 */

const KANJI_DIGIT: Record<string, number> = {
  〇: 0,
  零: 0,
  一: 1,
  二: 2,
  三: 3,
  四: 4,
  五: 5,
  六: 6,
  七: 7,
  八: 8,
  九: 9,
};

/** 漢数字の並び（「四十八」「百二十」「一二三」）を算用数字にする */
function kanjiRun(run: string): string {
  if (!/[十百]/.test(run))
    return Array.from(run)
      .map((c) => KANJI_DIGIT[c] ?? '')
      .join('');
  let total = 0;
  let cur = 0;
  for (const c of run) {
    if (c === '十') {
      total += (cur || 1) * 10;
      cur = 0;
    } else if (c === '百') {
      total += (cur || 1) * 100;
      cur = 0;
    } else {
      cur = KANJI_DIGIT[c] ?? 0;
    }
  }
  return String(total + cur);
}

export function normalizeEchoSpeech(input: string): string {
  let s = input.normalize('NFKC').toLowerCase();
  s = s.replace(/[’´′`‘]/g, "'");
  s = s.replace(/[〇零一二三四五六七八九十百]+/g, kanjiRun);
  // 「e'」「s'」の言い方
  s = s.replace(/(?:イー|e)\s*(?:ダッシュ|プライム)/g, "e'");
  s = s.replace(/(?:エス|s)\s*(?:ダッシュ|プライム)/g, "s'");
  // 小数: 2点5 / 2ポイント5 / 2てん5
  s = s.replace(/(\d)\s*(?:ポイント|てん|点)\s*(\d)/g, '$1.$2');
  return s;
}

/** 正規表現の特殊文字を無効にする */
export function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
}

/**
 * 項目名（別名）を探す正規表現。文字の間の空白は許す。英字で始まる/終わる別名は、
 * 前後が英字のときは一致させない（「tr」が「trpg」の一部に当たらないように）。
 */
export function aliasRegExp(alias: string, flags = 'g'): RegExp {
  const a = normalizeEchoSpeech(alias).replace(/\s+/g, '');
  const body = Array.from(a).map(escapeRegExp).join('\\s*');
  const pre = /^[a-z]/.test(a) ? '(?<![a-z])' : '';
  const post = /[a-z]$/.test(a) ? '(?![a-z])' : '';
  return new RegExp(`${pre}${body}${post}`, flags);
}

export interface AliasToken<T> {
  start: number;
  end: number;
  target: T;
}

/**
 * 文章の中の別名を、重ならないように左から拾う（同じ位置では長い別名を優先）。
 * text は normalizeEchoSpeech 済みであること。
 */
export function scanAliases<T>(
  text: string,
  table: Array<{ aliases: string[]; target: T }>
): AliasToken<T>[] {
  const found: AliasToken<T>[] = [];
  for (const row of table) {
    for (const alias of row.aliases) {
      const re = aliasRegExp(alias);
      for (const m of text.matchAll(re)) {
        if (m[0].length === 0) continue;
        found.push({ start: m.index ?? 0, end: (m.index ?? 0) + m[0].length, target: row.target });
      }
    }
  }
  found.sort((a, b) => a.start - b.start || b.end - b.start - (a.end - a.start));
  const out: AliasToken<T>[] = [];
  let lastEnd = -1;
  for (const f of found) {
    if (f.start < lastEnd) continue; // 先に拾った（長い）別名と重なる
    out.push(f);
    lastEnd = f.end;
  }
  return out;
}

/** 文章の先頭近く（相づちや助詞を挟んでよい）にある最初の数値と、その直後の文字 */
export function leadingNumber(seg: string, maxGap = 10): { value: number; after: string } | null {
  const m = new RegExp(`^[^\\d]{0,${maxGap}}?(\\d+(?:\\.\\d+)?)`).exec(seg);
  if (!m) return null;
  const value = Number(m[1]);
  if (!Number.isFinite(value)) return null;
  return { value, after: seg.slice(m[0].length) };
}

/** 数値を小数 dec 桁までに丸め、末尾の 0 を落として文字にする */
export function formatNum(v: number, dec: number): string {
  return String(Number(v.toFixed(dec)));
}
