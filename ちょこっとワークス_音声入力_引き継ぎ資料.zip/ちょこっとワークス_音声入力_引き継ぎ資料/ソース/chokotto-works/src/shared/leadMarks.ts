/** index 番目（文字単位）から始まる部分の先頭にある 。、 を取り除く（動かした先の行頭に句読点が付くのを防ぐ） */
export function stripMarksAt(text: string, index: number): string {
  const arr = Array.from(text);
  let i = Math.max(0, index);
  if (i > arr.length) return text;
  while (i < arr.length && /[。、，．]/.test(arr[i])) i++;
  return i === Math.max(0, index)
    ? text
    : arr.slice(0, Math.max(0, index)).join('') + arr.slice(i).join('');
}

const MARK = /[。、，．]/;
function lev(a: string[], b: string[]): number {
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i];
    for (let j = 1; j <= b.length; j++)
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[b.length];
}

/**
 * 「ここまでは別の場所に入力済み（base）」としたとき、認識中の全文（desired）のうち、
 * 新しい場所へ入力する「そのあとの部分」を返す。
 *
 * 認識は、途中で書き直される（句読点が入る・数字や用語が置き換わる・言い直す）ので、
 * 文字数の位置だけで区切ると、前の文の終わりの文字や「、。」が新しい場所に入ったり、
 * 前の文の途中から入力が始まったりする。そこで、先頭が一致する範囲のあと、書き換わった末尾が
 * もっとも近くなる位置で区切る。区切りの先頭にある句読点は付けない。
 */
export function newPartAfter(base: string, desired: string): string {
  const b = Array.from(base);
  const d = Array.from(desired);
  let p = 0;
  while (p < b.length && p < d.length && b[p] === d[p]) p++;
  let e = p;
  if (p < b.length) {
    // base の末尾が書き換わった（または desired が base より短い）。書き換え後の末尾に当たる位置を探す
    const tail = b.slice(p);
    if (tail.length <= 24) {
      let best = Infinity;
      const max = Math.min(d.length, p + tail.length + 6);
      for (let k = p; k <= max; k++) {
        const c = lev(tail, d.slice(p, k));
        if (c <= best) {
          best = c;
          e = k; // 同点なら、より後ろ（新しい文を削らない側ではなく、前の文の残りを入れない側）
        }
      }
    } else {
      e = Math.min(d.length, b.length);
    }
  } else {
    e = b.length;
  }
  while (e < d.length && MARK.test(d[e])) e++;
  return d.slice(e).join('');
}
