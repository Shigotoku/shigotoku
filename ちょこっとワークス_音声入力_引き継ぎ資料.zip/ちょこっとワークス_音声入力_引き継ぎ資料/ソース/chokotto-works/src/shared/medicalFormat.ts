/**
 * 医療の数値・単位の整形（純粋関数。Electron / DOM に依存しない）。
 *
 *   「血圧は130の80」        → 「血圧は130/80」
 *   「36度5分」「三十六度五分」 → 「36.5℃」
 *   「体温36.5度」            → 「体温36.5℃」
 *   「50ミリグラム」          → 「50mg」   （マイクログラム→μg、ミリリットル→mL、パーセント→% など）
 *
 * 方針: 日常語を壊さないよう、必ず「数字 + 決まった語」「血圧という語の直後」など
 * 文脈が確かな場合だけ変換する。迷うものは変換しない。
 */

const KANJI_DIGIT: Record<string, number> = {
  〇: 0,
  零: 0,
  一: 1,
  二: 2,
  三: 3,
  四: 4,
  五: 5,
  六: 6,
  七: 7,
  八: 8,
  九: 9,
};
const KANJI_UNIT: Record<string, number> = { 十: 10, 百: 100, 千: 1000 };

/** 漢数字・算用数字を数値にする（千の位まで）。解釈できなければ null */
export function kanjiToNumber(input: string): number | null {
  const s = input.trim();
  if (!s) return null;
  if (/^[0-9]+$/.test(s)) return Number(s);
  const hasUnit = /[十百千]/.test(s);
  if (!hasUnit) {
    // 一三〇 のような位取りの読み
    let digits = '';
    for (const ch of s) {
      if (!(ch in KANJI_DIGIT)) return null;
      digits += String(KANJI_DIGIT[ch]);
    }
    return Number(digits);
  }
  let total = 0;
  let pending: number | null = null;
  for (const ch of s) {
    if (ch in KANJI_DIGIT) {
      pending = KANJI_DIGIT[ch];
    } else if (ch in KANJI_UNIT) {
      total += (pending ?? 1) * KANJI_UNIT[ch];
      pending = null;
    } else {
      return null;
    }
  }
  return total + (pending ?? 0);
}

/** 全角数字を半角にする */
function toHalfWidthDigits(text: string): string {
  return text.replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
}

// 数（算用 or 漢数字）。小数点は「.」または「点」
const KDIGITS = '[〇零一二三四五六七八九]';
const KNUM = '[〇零一二三四五六七八九十百千]+';
const NUM = `(?:\\d+|${KNUM})`;
const DEC = `${NUM}(?:\\.\\d+|点(?:\\d+|${KDIGITS}+))?`;

/** 「三十六」「5」「零点五」「0点5」「12.5」→ 数値文字列（"36" "5" "0.5" "0.5" "12.5"） */
function decimalText(raw: string): string | null {
  const t = raw.trim();
  if (/^\d+(?:\.\d+)?$/.test(t)) return t;
  const [intPart, fracPart] = t.split('点');
  if (fracPart === undefined) {
    const n = kanjiToNumber(t);
    return n === null ? null : String(n);
  }
  const n = kanjiToNumber(intPart);
  if (n === null) return null;
  let frac = '';
  for (const ch of fracPart) {
    if (/\d/.test(ch)) frac += ch;
    else if (ch in KANJI_DIGIT) frac += String(KANJI_DIGIT[ch]);
    else return null;
  }
  return frac ? `${n}.${frac}` : String(n);
}

// ---- 血圧 ----
const BP_PREFIX = '(?:血圧|BP|ＢＰ|最高血圧)(?:は|が|も|:|：)?';
const BP_WITH_WORD = new RegExp(`(${BP_PREFIX})(${NUM})(?:の|/|／)(${NUM})`, 'g');
// 「血圧」と言わなくても、直後が「ミリ」「mmHg」「文末」なら血圧とみなす（3桁の2桁/3桁）
const BP_BARE =
  /(?<![\d/.])(\d{3})の(\d{2,3})(?=ミリ|mmHg|ですね|です|でした|でして|ありました|、|。|$)/g;

function bpOk(sys: number, dia: number): boolean {
  return sys >= 60 && sys <= 300 && dia >= 30 && dia <= 200 && sys > dia;
}

function formatBloodPressure(text: string): string {
  let result = text.replace(BP_WITH_WORD, (whole, prefix: string, a: string, b: string) => {
    const sys = kanjiToNumber(a);
    const dia = kanjiToNumber(b);
    if (sys === null || dia === null || !bpOk(sys, dia)) return whole;
    return `${prefix}${sys}/${dia}`;
  });
  result = result.replace(BP_BARE, (whole, a: string, b: string) =>
    bpOk(Number(a), Number(b)) ? `${a}/${b}` : whole
  );
  return result;
}

// ---- 体温 ----
// 関節の角度（屈曲40度 など）を体温と取り違えない
const ANGLE_WORDS =
  /(?:屈曲|伸展|外転|内転|回旋|挙上|角度|開排|内旋|外旋|可動域|ROM|傾斜)[^。、]{0,6}$/;

function tempOk(v: number): boolean {
  return v >= 34 && v <= 42.9;
}

function formatTemperature(text: string): string {
  // 36度5分
  let result = text.replace(
    new RegExp(`(${NUM})度(${NUM})分`, 'g'),
    (whole, a: string, b: string, offset: number, src: string) => {
      const head = kanjiToNumber(a);
      const tenth = kanjiToNumber(b);
      if (head === null || tenth === null || tenth > 9) return whole;
      if (!tempOk(head) || ANGLE_WORDS.test(src.slice(0, offset))) return whole;
      return `${head}.${tenth}℃`;
    }
  );
  // 36.5度 / 38度 / 三十八度（体温らしい範囲だけ）
  result = result.replace(
    new RegExp(`(?<![\\d.])(${DEC})度(?![0-9分])`, 'g'),
    (whole, a: string, offset: number, src: string) => {
      const t = decimalText(a);
      if (t === null) return whole;
      const v = Number(t);
      if (!tempOk(v) || ANGLE_WORDS.test(src.slice(0, offset))) return whole;
      return `${t}℃`;
    }
  );
  return result;
}

// ---- 単位 ----
// 長い語を先に並べる（「ミリグラム」が「グラム」に先取りされないように）
const UNITS: Array<[string, string]> = [
  ['マイクログラム', 'μg'],
  ['ミリグラム', 'mg'],
  ['キログラム', 'kg'],
  ['グラム', 'g'],
  ['ミリリットル', 'mL'],
  ['デシリットル', 'dL'],
  ['リットル', 'L'],
  ['ミリメートル', 'mm'],
  ['センチメートル', 'cm'],
  ['センチ', 'cm'],
  ['パーセント', '%'],
];
// 「/」の直後（130/80ミリ の 80）は血圧の一部なので対象外
const UNIT_RE = new RegExp(`(?<![\\d./])(${DEC})(${UNITS.map(([k]) => k).join('|')})`, 'g');
const UNIT_MAP = new Map(UNITS);
// 「5ミリぐらいの病変」→ 5mm。ミリ秒・ミリ水銀柱・ミリグラム等は別の語なので除く
const MILLI_RE = new RegExp(`(?<![\\d./])(${DEC})ミリ(?![グリメ秒ヘエ水ボ])`, 'g');

function formatUnits(text: string): string {
  const replaced = text.replace(UNIT_RE, (whole, num: string, unit: string) => {
    const t = decimalText(num);
    const symbol = UNIT_MAP.get(unit);
    if (t === null || !symbol) return whole;
    return `${t}${symbol}`;
  });
  return replaced.replace(MILLI_RE, (whole, num: string) => {
    const t = decimalText(num);
    return t === null ? whole : `${t}mm`;
  });
}

// ---- 用法・日数（「一日三回」「七日分」「一回一錠」）----
// 「一日中」のような普通の文を壊さないよう、回数・日数・数量の語が続くときだけ数字にする
const DOSE_UNIT = '(?:錠|カプセル|包|滴|本|枚|個|プッシュ|パフ|mg|mL|g)';
const DOSAGE_RULES: Array<[RegExp, (m: RegExpExecArray) => string | null]> = [
  [
    new RegExp(`(${NUM})日(${NUM})回`, 'g'),
    (m) => {
      const a = kanjiToNumber(m[1]);
      const b = kanjiToNumber(m[2]);
      return a !== null && b !== null && a <= 3 && b <= 6 ? `${a}日${b}回` : null;
    },
  ],
  [
    new RegExp(`(${NUM})(日分|週間分|週分|か月分|ヶ月分|カ月分)`, 'g'),
    (m) => {
      const a = kanjiToNumber(m[1]);
      return a !== null && a >= 1 && a <= 365 ? `${a}${m[2]}` : null;
    },
  ],
  [
    new RegExp(`(?<![\\d.])(${NUM})(${DOSE_UNIT})(?=ずつ|を|、|。|$|\\s)`, 'g'),
    (m) => {
      const a = kanjiToNumber(m[1]);
      return a !== null && a >= 1 && a <= 99 ? `${a}${m[2]}` : null;
    },
  ],
  [
    new RegExp(`(?<![\\d.])(${NUM})回(${NUM})(${DOSE_UNIT})`, 'g'),
    (m) => {
      const a = kanjiToNumber(m[1]);
      const b = kanjiToNumber(m[2]);
      return a !== null && b !== null && a <= 6 && b >= 1 ? `${a}回${b}${m[3]}` : null;
    },
  ],
];

function formatDosage(text: string): string {
  let result = text;
  for (const [re, fn] of DOSAGE_RULES) {
    result = result.replace(re, (whole, ...rest) => {
      const m = Object.assign([whole, ...rest.slice(0, -2)], {
        index: 0,
      }) as unknown as RegExpExecArray;
      return fn(m) ?? whole;
    });
  }
  return result;
}

// ---- 検査値の読み上げ（「CRP0.3 白血球5800 ヘモグロビン13.5」を、項目ごとに「、」で区切る）----
const LAB_ITEMS =
  'CRP|WBC|RBC|Hb|Plt|AST|ALT|γGTP|ALP|LDH|BUN|eGFR|HbA1c|LDL|HDL|TG|TSH|BNP|白血球|赤血球|ヘモグロビン|血小板|クレアチニン|血糖|尿酸|中性脂肪|カリウム|ナトリウム|ALB|アルブミン';
const LAB_PAIR = `(?:${LAB_ITEMS})(?:は|が|の値は|値)?${DEC}(?:mg/dL|g/dL|mEq/L|mmol/L|U/L|IU/L|%|mg|g)?`;
const LAB_JOIN = new RegExp(`(${LAB_PAIR})(?=(?:${LAB_ITEMS}))`, 'g');

function formatLabValues(text: string): string {
  // 項目と値が2つ以上並んでいるときだけ、間に「、」を入れる
  if (!new RegExp(`${LAB_PAIR}(?:${LAB_ITEMS})`).test(text)) return text;
  return text.replace(LAB_JOIN, '$1、');
}

/** 医療の数値・単位を整形する */
export function formatMedicalNumbers(text: string): string {
  if (!text) return text;
  let result = toHalfWidthDigits(text);
  result = formatBloodPressure(result);
  result = formatTemperature(result);
  result = formatUnits(result);
  result = formatDosage(result);
  result = formatLabValues(result);
  return result;
}
