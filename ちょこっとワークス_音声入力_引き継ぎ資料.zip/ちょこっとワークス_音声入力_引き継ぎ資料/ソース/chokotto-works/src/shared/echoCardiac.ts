/**
 * 心エコー: 音声（「LVDd 48 LVDs 30 …」）から項目と数値を読み取り、テンプレート（心エコー.txt）に当てはめる。
 *
 * 方針
 * - 数値は AI に任せず、ルールで拾う（項目名の別名 → 直後の数値）。作り話や読み違えが起きないようにするため。
 * - 話していない項目は空欄のまま。EF・E/A・平均E/e'・TRPG・体表面積から出す指標などは自動計算（src='calc'）。
 * - 心嚢液・胸水・右室の所見は、話さなければ「なし」（テンプレートどおり。src='default'）。
 * - 話した内容と計算値は毎回、全文から作り直す（言い直し・訂正は後の発言が優先、「取り消し」で削除）。
 */
import {
  aliasRegExp,
  formatNum,
  leadingNumber,
  normalizeEchoSpeech,
  scanAliases,
} from './echoSpeech';

export type EchoSrc = 'voice' | 'calc' | 'manual' | 'default';
export interface EchoValue {
  v: number | string;
  src: EchoSrc;
  /** 範囲外・換算などの注意（画面で目立たせる） */
  warn?: string;
}
export type EchoValues = Record<string, EchoValue>;

type UnitKind = 'mm' | 'cm' | 'mps' | 'plain';

export interface NumField {
  id: string;
  label: string;
  unit: string;
  aliases: string[];
  min: number;
  max: number;
  dec: number;
  kind: UnitKind;
}

const f = (
  id: string,
  label: string,
  unit: string,
  kind: UnitKind,
  min: number,
  max: number,
  dec: number,
  aliases: string[]
): NumField => ({ id, label, unit, kind, min, max, dec, aliases });

/** 音声で入力できる数値項目（別名は音声認識の揺れを含む） */
export const NUM_FIELDS: NumField[] = [
  f('height', '身長', 'cm', 'plain', 100, 220, 1, ['身長', 'しんちょう']),
  f('weight', '体重', 'kg', 'plain', 20, 200, 1, ['体重', 'たいじゅう']),
  f('lvdd', 'LVDd', '㎜', 'mm', 30, 90, 1, [
    'lvdd',
    'lvid',
    '左室拡張末期径',
    '左室拡張期径',
    'エルブイディーディー',
    'エルブイディーデー',
  ]),
  f('lvds', 'LVDs', '㎜', 'mm', 15, 80, 1, [
    'lvds',
    '左室収縮末期径',
    '左室収縮期径',
    'エルブイディーエス',
  ]),
  f('ivstd', 'IVSTd', '㎜', 'mm', 4, 30, 1, [
    'ivstd',
    'ivs',
    '心室中隔厚',
    '心室中隔壁厚',
    '中隔厚',
    'アイブイエスティーディー',
  ]),
  f('plvwd', 'PLVWd', '㎜', 'mm', 4, 30, 1, [
    'plvwd',
    'lvpw',
    'pw',
    '後壁厚',
    '左室後壁厚',
    'ピーエルブイダブリューディー',
  ]),
  f('efT', '%EF', '%', 'plain', 10, 90, 0, ['teichholz ef', 'テイコルツ ef', 'ティッコルツ ef']),
  f('fs', '%FS', '%', 'plain', 5, 60, 0, ['fs', '%fs', 'エフエス', '内径短縮率']),
  f('edv', 'EDV', 'ml', 'plain', 20, 400, 0, ['edv', '拡張末期容積', 'イーディーブイ']),
  f('esv', 'ESV', 'ml', 'plain', 5, 300, 0, ['esv', '収縮末期容積', 'イーエスブイ']),
  f('efS', '%EF', '%', 'plain', 5, 90, 0, [
    'ef',
    'lvef',
    '左室駆出率',
    '駆出率',
    'イーエフ',
    'シンプソン ef',
  ]),
  f('aoAnnulus', '弁輪部', '㎜', 'mm', 10, 40, 1, [
    '弁輪部',
    '大動脈弁輪',
    '弁輪',
    'av annulus',
    'アニュラス',
  ]),
  f('sov', 'バルサルバ洞', '㎜', 'mm', 15, 60, 1, [
    'バルサルバ洞',
    'バルサルバ',
    'valsalva',
    'sov',
  ]),
  f('stj', 'ST junction', '㎜', 'mm', 15, 60, 1, [
    'st junction',
    'stj',
    'stジャンクション',
    'sinotubular junction',
    'エスティージェイ',
  ]),
  f('ascAo', '上行大動脈', '㎜', 'mm', 15, 70, 1, [
    '上行大動脈',
    '上行',
    'asc ao',
    'ascending aorta',
  ]),
  f('lad', 'LAD', '㎜', 'mm', 15, 80, 1, ['lad', '左房径', '左房', 'エルエーディー']),
  f('lvotVti', 'LVOT VTI', 'cm', 'cm', 5, 40, 1, [
    'lvot vti',
    'lvotvti',
    'lvot',
    'vti',
    'ブイティーアイ',
  ]),
  f('sv', 'SV', 'ml', 'plain', 20, 200, 0, [
    'sv',
    '一回拍出量',
    '1回拍出量',
    'stroke volume',
    'エスブイ',
  ]),
  f('co', 'CO', 'L/min', 'plain', 1, 15, 1, ['co', '心拍出量', 'シーオー']),
  f('eVel', 'E vel', 'm/sec', 'mps', 0.2, 3, 2, [
    'e vel',
    'e velocity',
    'e velo',
    'e ベロシティ',
    'e波',
    'イー波',
    'イーベル',
  ]),
  f('aVel', 'A vel', 'm/sec', 'mps', 0.1, 3, 2, [
    'a vel',
    'a velocity',
    'a velo',
    'a ベロシティ',
    'a波',
    'エー波',
    'エーベル',
  ]),
  f('edct', 'E Dct', 'ms', 'plain', 80, 450, 0, [
    'e dct',
    'dct',
    'dt',
    'deceleration time',
    'decel time',
    '減速時間',
    'ディーシーティー',
  ]),
  f('eSep', "中隔e'", 'cm/sec', 'plain', 2, 30, 1, [
    "中隔e'",
    "e'中隔",
    "septal e'",
    "e' septal",
    "セプタルe'",
  ]),
  f('eLat', "側壁e'", 'cm/sec', 'plain', 2, 30, 1, [
    "側壁e'",
    "e'側壁",
    "lateral e'",
    "e' lateral",
    "ラテラルe'",
  ]),
  f('trVel', 'Velocity', 'm/sec', 'mps', 1, 5, 2, [
    'tr velocity',
    'tr velo',
    'tr vel',
    'tr ベロシティ',
    'tr速度',
    'trv',
    'tr流速',
  ]),
  f('lav', 'LAV', 'ml', 'plain', 10, 300, 0, ['lav', '左房容積', 'エルエーブイ']),
  f('trpg', 'TRPG', 'mmHg', 'plain', 5, 150, 0, ['trpg', 'tr pg', 'ティーアールピージー']),
  f('rap', 'RA圧(仮定)', 'mmHg', 'plain', 0, 25, 0, [
    'ra圧',
    'rap',
    '右房圧',
    'ra pressure',
    'アールエー圧',
  ]),
  f('spap', '推定PA圧(収縮期)', 'mmHg', 'plain', 10, 150, 0, [
    '推定pa圧',
    'pa収縮期圧',
    '収縮期pa圧',
    '肺動脈収縮期圧',
    'pasp',
    'spap',
    'pa圧',
    '肺動脈圧',
  ]),
  f('dpap', '推定PA圧(拡張期)', 'mmHg', 'plain', 0, 100, 0, [
    'pa拡張期圧',
    '拡張期pa圧',
    '肺動脈拡張期圧',
    'dpap',
  ]),
  f('mpap', '平均推定圧', 'mmHg', 'plain', 5, 120, 0, [
    '平均推定圧',
    '平均pa圧',
    '平均肺動脈圧',
    'mpap',
  ]),
  f('actet', 'ACT/ET(RVOT)', '', 'plain', 0.05, 1, 2, [
    'act/et',
    'act et',
    'ace',
    'アクセレーションタイム',
  ]),
  f('fac', 'FAC', '%', 'plain', 10, 80, 0, ['fac', 'ファック']),
  f('tapse', 'TAPSE', '㎜', 'mm', 5, 40, 1, ['tapse', 'タプス', 'タプセ', 'タップス']),
  f('sPrime', "S'", 'cm/sec', 'plain', 3, 30, 1, ["s'", "右室s'", "rv s'", 'エスプライム']),
  // IVC は「IVC 15 8 変動 60」の専用読み取りがあるので別名は持たない（順番入力で使う）
  f('ivcD', 'IVC 拡張期', '㎜', 'mm', 5, 40, 1, []),
  f('ivcS', 'IVC 収縮期', '㎜', 'mm', 0, 40, 1, []),
  f('ivcCollapse', 'IVC 呼吸性変動', '%', 'plain', 0, 100, 0, []),
];

/** 「この欄から入れ直す」の目印（発話の文章に混ぜる。表示のときは消す） */
export function jumpMarker(id: string): string {
  return `§${id.toLowerCase()}§`;
}
export function stripJumpMarkers(text: string): string {
  return text.replace(/\s*§[a-z]+§\s*/gi, ' ').trim();
}

const NUM_BY_ID: Record<string, NumField> = Object.fromEntries(NUM_FIELDS.map((x) => [x.id, x]));

/** 自動計算される項目（話さなくてよい）の小数桁数 */
const CALC_DEC: Record<string, number> = {
  efT: 0,
  fs: 0,
  efS: 0,
  ea: 2,
  eee: 1,
  svi: 0,
  ci: 1,
  lavi: 0,
  trpg: 0,
  spap: 0,
  rap: 0,
  ivcCollapse: 0,
  bsa: 2,
};

type Target =
  | { k: 'num'; f: NumField }
  | { k: 'qual'; id: 'pericardial' | 'pleural' }
  | { k: 'rv'; id: 'rvEnlarge' | 'rvHyper' | 'rvSys' }
  | { k: 'rvAll' }
  | { k: 'valve'; id: 'ar' | 'mr' | 'tr' | 'pr' }
  | { k: 'ivc' }
  | { k: 'jump'; f: NumField };

const TABLE: Array<{ aliases: string[]; target: Target }> = [
  ...NUM_FIELDS.map((x) => ({ aliases: x.aliases, target: { k: 'num', f: x } as Target })),
  // 画面で欄をクリックしたときに発話へ足す目印（§項目id§）
  ...NUM_FIELDS.map((x) => ({
    aliases: [jumpMarker(x.id)],
    target: { k: 'jump', f: x } as Target,
  })),
  {
    aliases: ['心嚢液', '心のう液', '心嚢水', '心嚢', 'しんのうえき'],
    target: { k: 'qual', id: 'pericardial' },
  },
  { aliases: ['胸水', 'きょうすい'], target: { k: 'qual', id: 'pleural' } },
  {
    aliases: ['右室拡大', '右心室拡大', 'rv拡大', '右室の拡大'],
    target: { k: 'rv', id: 'rvEnlarge' },
  },
  {
    aliases: ['右室壁肥厚', '右室肥厚', 'rv壁肥厚', 'rv肥厚', '右心室壁肥厚'],
    target: { k: 'rv', id: 'rvHyper' },
  },
  {
    aliases: ['右室収縮低下', '右室収縮', 'rv収縮低下', 'rv収縮', '右心室収縮'],
    target: { k: 'rv', id: 'rvSys' },
  },
  {
    aliases: ['右室正常', '右室異常なし', '右室機能正常', 'rv正常', 'rv異常なし', '右心室正常'],
    target: { k: 'rvAll' },
  },
  { aliases: ['ivc', 'アイブイシー', '下大静脈'], target: { k: 'ivc' } },
  {
    aliases: ['ar', 'エーアール', '大動脈弁閉鎖不全', '大動脈弁逆流'],
    target: { k: 'valve', id: 'ar' },
  },
  {
    aliases: ['mr', 'エムアール', '僧帽弁閉鎖不全', '僧帽弁逆流'],
    target: { k: 'valve', id: 'mr' },
  },
  {
    aliases: ['tr', 'ティーアール', '三尖弁閉鎖不全', '三尖弁逆流'],
    target: { k: 'valve', id: 'tr' },
  },
  {
    aliases: ['pr', 'ピーアール', '肺動脈弁閉鎖不全', '肺動脈弁逆流'],
    target: { k: 'valve', id: 'pr' },
  },
];

const CANCEL = /取り消|取消|クリア|消去|削除|やり直/;
const NONE = /なし|無し|ない|正常|保たれ|認めず/;
const SOME = /あり|低下|拡大|肥厚|認める|認め/;

/** 逆流の程度の言い方 → (+++) などの表記。読み取れなければ null */
export function parseGrade(seg: string): string | null {
  const s = seg.slice(0, 16);
  if (/プラスマイナス|微量|トリビアル|trivial|±|わずか|ごく軽度/.test(s)) return '(±)';
  if (/軽度?\s*(?:から|〜|~)\s*中等度?|mild\s*(?:to|-)\s*moderate/.test(s)) return '(+~++)';
  if (/中等度?\s*(?:から|〜|~)\s*高度|moderate\s*to\s*severe/.test(s)) return '(++~+++)';
  if (/プラスプラスプラス|\+\+\+|3\s*\+|スリープラス|高度|重度|severe|(?<![\d.])3(?![\d.])/.test(s))
    return '(+++)';
  if (/プラスプラス|\+\+|2\s*\+|ツープラス|中等度|中等|moderate|(?<![\d.])2(?![\d.])/.test(s))
    return '(++)';
  if (/プラス|\+|ワンプラス|軽度|mild|(?<![\d.])1(?![\d.])/.test(s)) return '(+)';
  if (/なし|無し|ない|マイナス|ゼロ|正常|認めず|\(-\)|(?<![\d.])0(?![\d.])/.test(s)) return '(-)';
  return null;
}

/** 心嚢液・胸水: なし／少量あり など */
function parseEffusion(seg: string): string | null {
  const s = seg.slice(0, 16);
  const grade = /微量|少量|中等量|大量/.exec(s);
  if (grade) return `${grade[0]}あり`;
  if (NONE.test(s)) return 'なし';
  if (/あり|貯留|認め/.test(s)) return 'あり';
  return null;
}

function unitOf(after: string): 'cm' | 'mm' | 'pct' | '' {
  const a = after.slice(0, 8).trim();
  if (/^(?:センチ|cm)/.test(a)) return 'cm';
  if (/^(?:ミリ|mm)/.test(a)) return 'mm';
  if (/^(?:%|パーセント)/.test(a)) return 'pct';
  return '';
}

export interface CardiacParse {
  values: EchoValues;
  /** 聞き取れなかった・直した項目の説明（画面に出す） */
  notes: string[];
  /** 順番入力で、次に入る項目の id（最後まで入れたら null） */
  next?: string | null;
}

/**
 * 値を入れる。strict=true（順番入力）のときは、通常の範囲外なら入れずに false を返す
 * （順番が1つずれているサインのことが多いため）。
 */
function setNum(
  values: EchoValues,
  notes: string[],
  fld: NumField,
  value: number,
  after: string,
  strict = false
): boolean {
  let v = value;
  let warn: string | undefined;
  const unit = unitOf(after);
  if (fld.kind === 'mm' && unit === 'cm') v *= 10;
  else if (fld.kind === 'cm' && unit === 'mm') v /= 10;
  else if (fld.kind === 'mps' && v > 10) {
    v /= 100;
    warn = 'cm/sから換算';
  }
  if (v < fld.min || v > fld.max) {
    if (strict) {
      notes.push(
        `${fld.label} に ${formatNum(v, fld.dec)} は通常の範囲外なので入れていません（順番がずれていないか確認。「飛ばす」「戻る」で直せます）`
      );
      return false;
    }
    warn = `${warn ? `${warn}・` : ''}範囲外?`;
    notes.push(
      `${fld.label} ${formatNum(v, fld.dec)} は通常の範囲外です。聞き間違いがないか確認してください`
    );
  }
  values[fld.id] = { v: Number(v.toFixed(3)), src: 'voice', ...(warn ? { warn } : {}) };
  return true;
}

/** 順番入力の初期の順番（心エコー.txt の上から。自動計算される項目は除く） */
export const DEFAULT_ORDER: string[] = [
  'lvdd',
  'lvds',
  'ivstd',
  'plvwd',
  'edv',
  'esv',
  'aoAnnulus',
  'sov',
  'stj',
  'ascAo',
  'lad',
  'lvotVti',
  'sv',
  'co',
  'eVel',
  'aVel',
  'edct',
  'eSep',
  'eLat',
  'trVel',
  'lav',
  'actet',
  'fac',
  'tapse',
  'sPrime',
  'ivcD',
  'ivcS',
  'ivcCollapse',
];

const SEQ_WORDS =
  /(\d+(?:\.\d+)?)|(次|つぎ|ネクスト|飛ばす|とばす|スキップ|パス|戻る|もどる|戻って|バック)/g;

/** 全文（累積した発話）から、話された項目と値を読み取る（計算値・既定値は含まない） */
export function parseCardiac(raw: string, order: string[] = DEFAULT_ORDER): CardiacParse {
  const text = normalizeEchoSpeech(raw);
  const toks = scanAliases(text, TABLE);
  const values: EchoValues = {};
  const notes: string[] = [];
  /** 順番入力で、次に入れる項目の位置 */
  let ptr = 0;
  const idx = (id: string) => order.indexOf(id);
  /** 項目名なしの数字・「次」「飛ばす」「戻る」を、順番どおりに入れていく */
  const seq = (chunk: string): void => {
    for (const m of chunk.matchAll(SEQ_WORDS)) {
      if (m[2]) {
        ptr = /戻|もどる|バック/.test(m[2])
          ? Math.max(0, ptr - 1)
          : Math.min(order.length, ptr + 1);
        continue;
      }
      if (ptr >= order.length) {
        notes.push(`順番の最後まで入力済みです（余分な数字 ${m[1]}）`);
        continue;
      }
      const fld = NUM_BY_ID[order[ptr]];
      if (!fld) {
        ptr++;
        continue;
      }
      const after = chunk.slice((m.index ?? 0) + m[0].length);
      if (setNum(values, notes, fld, Number(m[1]), after, true)) ptr++;
    }
  };
  seq(text.slice(0, toks.length ? toks[0].start : text.length));
  for (let i = 0; i < toks.length; i++) {
    const t = toks[i];
    const seg = text.slice(t.end, i + 1 < toks.length ? toks[i + 1].start : text.length);
    const target = t.target;
    switch (target.k) {
      case 'num': {
        if (CANCEL.test(seg)) {
          delete values[target.f.id];
          break;
        }
        const n = leadingNumber(seg);
        if (!n) {
          notes.push(`${target.f.label}：数値が聞き取れませんでした`);
          break;
        }
        setNum(values, notes, target.f, n.value, n.after);
        if (idx(target.f.id) >= 0) ptr = idx(target.f.id) + 1; // 名前で呼んだ項目の次から順番入力を続ける
        seq(n.after);
        break;
      }
      case 'jump': {
        // 画面で欄をクリックしたとき: その欄から順番入力を再開する
        if (idx(target.f.id) >= 0) ptr = idx(target.f.id);
        seq(seg);
        break;
      }
      case 'qual': {
        if (CANCEL.test(seg)) {
          delete values[target.id];
          break;
        }
        const r = parseEffusion(seg);
        if (r) values[target.id] = { v: r, src: 'voice' };
        break;
      }
      case 'rv': {
        if (CANCEL.test(seg)) {
          delete values[target.id];
          break;
        }
        const s = seg.slice(0, 12);
        if (NONE.test(s)) values[target.id] = { v: 'なし', src: 'voice' };
        else if (SOME.test(s)) values[target.id] = { v: 'あり', src: 'voice' };
        break;
      }
      case 'rvAll':
        for (const id of ['rvEnlarge', 'rvHyper', 'rvSys'])
          values[id] = { v: 'なし', src: 'voice' };
        break;
      case 'valve': {
        if (CANCEL.test(seg)) {
          delete values[target.id];
          break;
        }
        const g = parseGrade(seg);
        const num = leadingNumber(seg, 3);
        if (target.id === 'tr' && num && g === null) {
          // 「TR 2.5」のように程度の言葉がなく数値だけ → TR の流速として扱う
          setNum(values, notes, NUM_BY_ID.trVel, num.value, num.after);
        } else if (g) {
          values[target.id] = { v: g, src: 'voice' };
        } else {
          notes.push(`${target.id.toUpperCase()}：程度が聞き取れませんでした`);
        }
        break;
      }
      case 'ivc': {
        if (CANCEL.test(seg)) {
          for (const id of ['ivcD', 'ivcS', 'ivcCollapse']) delete values[id];
          break;
        }
        parseIvc(seg, values, notes);
        for (const id of ['ivcD', 'ivcS', 'ivcCollapse'])
          if (values[id] && idx(id) >= 0) ptr = Math.max(ptr, idx(id) + 1);
        break;
      }
    }
  }
  return { values, notes, next: ptr < order.length ? order[ptr] : null };
}

function parseIvc(seg: string, values: EchoValues, notes: string[]): void {
  let rest = seg;
  const cm = /(?:センチ|cm)/.test(seg) ? 10 : 1;
  const col = /(?:変動|虚脱)[^\d]{0,6}(\d+(?:\.\d+)?)/.exec(rest);
  if (col) {
    values.ivcCollapse = { v: Number(col[1]), src: 'voice' };
    rest = rest.replace(col[0], ' ');
  } else if (/変動\s*(?:なし|無し|ない|消失)/.test(rest)) {
    values.ivcCollapse = { v: 'なし', src: 'voice' };
  }
  let d: number | undefined;
  let s: number | undefined;
  const dm = /(?:拡張期?|最大|呼気)[^\d]{0,4}(\d+(?:\.\d+)?)/.exec(rest);
  if (dm) {
    d = Number(dm[1]);
    rest = rest.replace(dm[0], ' ');
  }
  const sm = /(?:収縮期?|最小|吸気)[^\d]{0,4}(\d+(?:\.\d+)?)/.exec(rest);
  if (sm) {
    s = Number(sm[1]);
    rest = rest.replace(sm[0], ' ');
  }
  const nums = (rest.match(/\d+(?:\.\d+)?/g) ?? []).map(Number);
  if (d === undefined && s === undefined && nums.length >= 2) {
    d = Math.max(nums[0], nums[1]);
    s = Math.min(nums[0], nums[1]);
  } else {
    if (d === undefined && nums.length) d = nums.shift();
    if (s === undefined && nums.length) s = nums.shift();
  }
  if (d !== undefined) values.ivcD = { v: d * cm, src: 'voice' };
  if (s !== undefined) values.ivcS = { v: s * cm, src: 'voice' };
  if (d === undefined && s === undefined && !col && !values.ivcCollapse)
    notes.push('IVC：数値が聞き取れませんでした');
}

const num = (values: EchoValues, id: string): number | undefined => {
  const x = values[id]?.v;
  return typeof x === 'number' && Number.isFinite(x) ? x : undefined;
};

function putCalc(out: EchoValues, id: string, v: number, warn?: string): void {
  if (!Number.isFinite(v) || v <= 0) return;
  if (out[id]) return; // 話した値・手で直した値を優先
  out[id] = {
    v: Number(v.toFixed(CALC_DEC[id] !== undefined ? CALC_DEC[id] + 2 : 3)),
    src: 'calc',
    ...(warn ? { warn } : {}),
  };
}

/** Teichholz 法の容積（ml）。径は mm */
export function teichholzVolume(dMm: number): number {
  const d = dMm / 10;
  return (7 * d ** 3) / (2.4 + d);
}

/** 体表面積（DuBois、m²） */
export function bodySurfaceArea(heightCm: number, weightKg: number): number {
  return 0.007184 * weightKg ** 0.425 * heightCm ** 0.725;
}

/** IVC 径と呼吸性変動から推定右房圧（ASE 2010）。 */
export function estimateRap(ivcD: number, collapsePct: number | null): number {
  if (ivcD <= 21) return collapsePct !== null && collapsePct < 50 ? 8 : 3;
  return collapsePct !== null && collapsePct >= 50 ? 8 : 15;
}

/** 話した値・手入力の値に、計算で出せる値と「なし」の既定値を足す */
export function withDerived(base: EchoValues): EchoValues {
  const out: EchoValues = { ...base };
  const lvdd = num(out, 'lvdd');
  const lvds = num(out, 'lvds');
  if (lvdd && lvds && lvdd > lvds) {
    const edv = teichholzVolume(lvdd);
    const esv = teichholzVolume(lvds);
    putCalc(out, 'efT', ((edv - esv) / edv) * 100);
    putCalc(out, 'fs', ((lvdd - lvds) / lvdd) * 100);
  }
  const edv = num(out, 'edv');
  const esv = num(out, 'esv');
  if (edv && esv && edv > esv) putCalc(out, 'efS', ((edv - esv) / edv) * 100);

  const h = num(out, 'height');
  const w = num(out, 'weight');
  const bsa = h && w ? bodySurfaceArea(h, w) : undefined;
  if (bsa) {
    putCalc(out, 'bsa', bsa);
    const sv = num(out, 'sv');
    const co = num(out, 'co');
    const lav = num(out, 'lav');
    if (sv) putCalc(out, 'svi', sv / bsa);
    if (co) putCalc(out, 'ci', co / bsa);
    if (lav) putCalc(out, 'lavi', lav / bsa);
  }

  const e = num(out, 'eVel');
  const a = num(out, 'aVel');
  if (e && a) putCalc(out, 'ea', e / a);
  const sep = num(out, 'eSep');
  const lat = num(out, 'eLat');
  const eps = sep && lat ? (sep + lat) / 2 : (sep ?? lat);
  if (e && eps) putCalc(out, 'eee', (e * 100) / eps);

  const trVel = num(out, 'trVel');
  if (trVel) putCalc(out, 'trpg', 4 * trVel * trVel);

  const ivcD = num(out, 'ivcD');
  const ivcS = num(out, 'ivcS');
  if (ivcD && ivcS && ivcD > ivcS && !out.ivcCollapse)
    putCalc(out, 'ivcCollapse', ((ivcD - ivcS) / ivcD) * 100);
  if (ivcD && !out.rap) {
    const c = num(out, 'ivcCollapse');
    putCalc(out, 'rap', estimateRap(ivcD, c ?? null), 'IVCからの仮定値');
  }
  const trpg = num(out, 'trpg');
  const rap = num(out, 'rap');
  if (trpg !== undefined && rap !== undefined) putCalc(out, 'spap', trpg + rap);

  for (const id of ['pericardial', 'pleural', 'rvEnlarge', 'rvHyper', 'rvSys']) {
    if (!out[id]) out[id] = { v: 'なし', src: 'default' };
  }
  return out;
}

/** 画面で手直しした文字を値にする（数値項目は数値に。空文字は「空欄にする」の意味で残す） */
export function manualValue(id: string, text: string): EchoValue {
  const t = normalizeEchoSpeech(text).trim();
  const fld = NUM_BY_ID[id];
  if (t !== '' && (fld || CALC_DEC[id] !== undefined || id === 'ivcD' || id === 'ivcS')) {
    const m = /^\d+(?:\.\d+)?$/.exec(t);
    if (m) return { v: Number(t), src: 'manual' };
  }
  return { v: text.trim(), src: 'manual' };
}

/** 話した全文＋手直しから、画面・出力に使う最終の値を作る */
export function buildCardiac(
  raw: string,
  manual: Record<string, string> = {},
  order: string[] = DEFAULT_ORDER
): CardiacParse {
  const parsed = parseCardiac(raw, order);
  const base: EchoValues = { ...parsed.values };
  for (const [id, text] of Object.entries(manual)) base[id] = manualValue(id, text);
  return { values: withDerived(base), notes: parsed.notes, next: parsed.next };
}

// ---- 出力（心エコー.txt のテンプレートに合わせる） ----

export interface LayoutItem {
  id: string;
  label: string;
  unit: string;
  /** 入力欄の種類（画面用）。num=数値 / text=文字 */
  type: 'num' | 'text';
  /** 補助項目（出力しない。体表面積の計算に使う） */
  hidden?: boolean;
}
export interface LayoutSub {
  title: string;
  items: LayoutItem[];
}
export interface LayoutSection {
  header: string;
  subs: LayoutSub[];
}

const n = (id: string, label: string, unit: string): LayoutItem => ({
  id,
  label,
  unit,
  type: 'num',
});
const t = (id: string, label: string, unit = ''): LayoutItem => ({ id, label, unit, type: 'text' });

export const CARDIAC_LAYOUT: LayoutSection[] = [
  {
    header: '【基本計測】',
    subs: [
      {
        title: '《LV teichholz》',
        items: [
          n('lvdd', 'LVDd', '㎜'),
          n('lvds', 'LVDs', '㎜'),
          n('ivstd', 'IVSTd', '㎜'),
          n('plvwd', 'PLVWd', '㎜'),
          n('efT', '%EF', '%'),
          n('fs', '%FS', '%'),
        ],
      },
      {
        title: '《LV simpson》',
        items: [n('edv', 'EDV', 'ml'), n('esv', 'ESV', 'ml'), n('efS', '%EF', '%')],
      },
      {
        title: '《Ao》',
        items: [
          n('aoAnnulus', '弁輪部', '㎜'),
          n('sov', 'バルサルバ洞', '㎜'),
          n('stj', 'ST junction', '㎜'),
          n('ascAo', '上行大動脈', '㎜'),
        ],
      },
      { title: '《LA》', items: [n('lad', 'LAD', '㎜')] },
      {
        title: '《心拍出量》',
        items: [
          n('lvotVti', 'LVOT VTI', 'cm'),
          n('sv', 'SV', 'ml'),
          n('svi', 'SVI', 'ml/㎡'),
          n('co', 'CO', 'L/min'),
          n('ci', 'CI', 'L/min/㎡'),
        ],
      },
      { title: '《心嚢液》', items: [t('pericardial', '心嚢液')] },
      { title: '《胸水》', items: [t('pleural', '胸水')] },
    ],
  },
  {
    header: '【拡張能評価】',
    subs: [
      {
        title: '《LV inflow》',
        items: [
          n('eVel', 'E vel', 'm/sec'),
          n('aVel', 'A vel', 'm/sec'),
          n('ea', 'E/A', ''),
          n('edct', 'E Dct', 'ms'),
        ],
      },
      {
        title: '《TDI》',
        items: [
          n('eSep', "中隔e'", 'cm/sec'),
          n('eLat', "側壁e'", 'cm/sec'),
          n('eee', "平均E/e'", ''),
        ],
      },
      { title: '《TR》', items: [n('trVel', 'Velocity', 'm/sec')] },
      { title: '《LA》', items: [n('lav', 'LAV', 'ml'), n('lavi', 'LAVI', 'ml/㎡')] },
    ],
  },
  {
    header: '【肺高血圧評価】',
    subs: [
      {
        title: '',
        items: [
          n('trpg', 'TRPG', 'mmHg'),
          n('rap', 'RA圧(仮定)', 'mmHg'),
          n('spap', '推定PA圧(収縮期)', 'mmHg'),
          n('dpap', '推定PA圧(拡張期)', 'mmHg'),
          n('mpap', '平均推定圧', 'mmHg'),
          n('actet', 'ACT/ET(RVOT)', ''),
        ],
      },
    ],
  },
  {
    header: '【右室機能】',
    subs: [
      {
        title: '',
        items: [
          t('rvEnlarge', '拡大'),
          t('rvHyper', '壁肥厚'),
          t('rvSys', '収縮低下'),
          n('fac', 'FAC', '%'),
          n('tapse', 'TAPSE', '㎜'),
          n('sPrime', "S'", 'cm/sec'),
        ],
      },
    ],
  },
  {
    header: '【IVC】',
    subs: [
      {
        title: '',
        items: [
          n('ivcD', '拡張期', '㎜'),
          n('ivcS', '収縮期', '㎜'),
          t('ivcCollapse', '呼吸性変動', '%'),
        ],
      },
    ],
  },
  {
    header: '【弁膜症】',
    subs: [{ title: '', items: [t('ar', 'AR'), t('mr', 'MR'), t('tr', 'TR'), t('pr', 'PR')] }],
  },
];

/** 身長・体重（体表面積の計算用。出力には含めない） */
export const CARDIAC_BODY_ITEMS: LayoutItem[] = [
  n('height', '身長', 'cm'),
  n('weight', '体重', 'kg'),
];

/** 項目の表示用文字（数値は桁をそろえる）。値がなければ '' */
export function valueText(values: EchoValues, id: string): string {
  const x = values[id];
  if (!x) return '';
  if (typeof x.v === 'number') {
    const dec = NUM_BY_ID[id]?.dec ?? CALC_DEC[id] ?? 1;
    return formatNum(x.v, dec);
  }
  return String(x.v);
}

function itemText(values: EchoValues, it: LayoutItem, showEmpty: boolean): string | null {
  const v = valueText(values, it.id);
  if (v === '') return showEmpty ? `${it.label}：${it.unit}` : null;
  if (it.id === 'ar' || it.id === 'mr' || it.id === 'tr' || it.id === 'pr')
    return `${it.label}${v}`;
  return `${it.label}：${v}${it.unit}`;
}

/** 出力用の本文。showEmpty=true なら話していない項目も枠だけ残す（テンプレートそのまま） */
export function formatCardiac(values: EchoValues, showEmpty = false): string {
  const lines: string[] = [];
  for (const sec of CARDIAC_LAYOUT) {
    const body: string[] = [];
    for (const sub of sec.subs) {
      let line: string | null = null;
      if (sec.header === '【右室機能】') {
        const parts: string[] = [];
        for (const it of sub.items) {
          if (it.id === 'rvEnlarge' || it.id === 'rvHyper' || it.id === 'rvSys') {
            const v = valueText(values, it.id);
            if (v) parts.push(`${it.label}${v}`);
            else if (showEmpty) parts.push(`${it.label}なし`);
          } else {
            const s = itemText(values, it, showEmpty);
            if (s) parts.push(s);
          }
        }
        line = parts.length ? parts.join('、') : null;
      } else if (sec.header === '【IVC】') {
        const d = valueText(values, 'ivcD');
        const s = valueText(values, 'ivcS');
        const c = valueText(values, 'ivcCollapse');
        const parts: string[] = [];
        if (d || s || showEmpty) parts.push(`拡張期${d}㎜～収縮期${s}㎜`);
        if (c === 'なし') parts.push('呼吸性変動なし');
        else if (c || showEmpty) parts.push(`呼吸性変動あり：${c}%`);
        line = parts.length ? parts.join('、') : null;
      } else if (sec.header === '【弁膜症】') {
        const parts = sub.items
          .map((it) => itemText(values, it, false))
          .filter((x): x is string => !!x);
        line = parts.length
          ? parts.join('、')
          : showEmpty
            ? 'AR(+++)、MR(+++)、TR(+++)、PR(+++)'
            : null;
      } else if (sub.title === '《心嚢液》' || sub.title === '《胸水》') {
        const v = valueText(values, sub.items[0].id);
        line = v || (showEmpty ? 'なし' : null);
      } else {
        const parts = sub.items
          .map((it) => itemText(values, it, showEmpty))
          .filter((x): x is string => !!x);
        line = parts.length ? parts.join('、') : null;
      }
      if (line === null) continue;
      if (sub.title) body.push(sub.title);
      body.push(line);
    }
    if (body.length) lines.push(sec.header, ...body);
  }
  return lines.join('\n');
}

/** 音声認識に渡す聞き取りのヒント（英字の項目名・用語） */
export const ECHO_PHRASE_HINTS: string[] = [
  'LVDd',
  'LVDs',
  'IVSTd',
  'PLVWd',
  'EDV',
  'ESV',
  'LVEF',
  'LAD',
  'LAV',
  'LAVI',
  'LVOT',
  'VTI',
  'TRPG',
  'TAPSE',
  'FAC',
  'E/A',
  'Dct',
  'Teichholz',
  'Simpson',
  'IVC',
  'バルサルバ洞',
  'ST junction',
  '上行大動脈',
  '弁輪部',
  '心嚢液',
  '胸水',
  '右室拡大',
  '壁肥厚',
  '収縮低下',
  '呼吸性変動',
  '脂肪肝',
  '胆嚢ポリープ',
  '胆嚢結石',
  '腎嚢胞',
  '膵管拡張',
  '肝腎コントラスト',
  '腎盂腎杯',
  '胆管拡張',
  '前立腺肥大',
];

export { aliasRegExp };
