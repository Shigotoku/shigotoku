/**
 * 訂正の学習（純粋関数）。
 * 認識結果（original）と、ユーザーが直した文章（corrected）を比べて、
 * ユーザー辞書に登録できる「誤り→正」の候補を取り出す。
 *
 * 認識した文章はディスクに保存しない（メモリ上の直近の入力だけを比べる）。
 */

export interface CorrectionPair {
  from: string;
  to: string;
}

interface Hunk {
  /** original 中の置換範囲 [aStart, aEnd) */
  aStart: number;
  aEnd: number;
  /** corrected 中の置換範囲 [bStart, bEnd) */
  bStart: number;
  bEnd: number;
}

/** 文字単位の差分（LCS）。入力は短い文章（数百文字）を想定 */
function diffHunks(a: string[], b: string[]): Hunk[] {
  const n = a.length;
  const m = b.length;
  // dp[i][j] = a[i..] と b[j..] の LCS 長
  const dp: Uint16Array[] = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const hunks: Hunk[] = [];
  let i = 0;
  let j = 0;
  let open: Hunk | null = null;
  const close = () => {
    if (open) hunks.push(open);
    open = null;
  };
  while (i < n || j < m) {
    if (i < n && j < m && a[i] === b[j]) {
      close();
      i++;
      j++;
    } else {
      if (!open) open = { aStart: i, aEnd: i, bStart: j, bEnd: j };
      if (j < m && (i >= n || dp[i][j + 1] >= dp[i + 1][j])) {
        j++;
        open.bEnd = j;
      } else {
        i++;
        open.aEnd = i;
      }
    }
  }
  close();
  return hunks;
}

/** 近い差分（間の一致が gap 文字以下）を1つにまとめる */
function mergeHunks(hunks: Hunk[], gap: number): Hunk[] {
  const merged: Hunk[] = [];
  for (const h of hunks) {
    const last = merged[merged.length - 1];
    if (last && h.aStart - last.aEnd <= gap) {
      last.aEnd = h.aEnd;
      last.bEnd = h.bEnd;
    } else {
      merged.push({ ...h });
    }
  }
  return merged;
}

const MIN_FROM = 2;
const MAX_LEN = 30;

/**
 * 訂正の候補を返す。
 * - 1文字だけの誤りは、辞書に入れると他の文章を壊すので、前後の文字を足して2文字以上にする
 * - 追加・削除だけの差分（置換でないもの）、長すぎる差分は候補にしない
 */
export function diffCorrections(original: string, corrected: string): CorrectionPair[] {
  if (!original || !corrected || original === corrected) return [];
  const a = Array.from(original);
  const b = Array.from(corrected);
  if (a.length > 600 || b.length > 600) return [];

  const hunks = mergeHunks(diffHunks(a, b), 1);
  const pairs: CorrectionPair[] = [];
  const seen = new Set<string>();
  for (const h of hunks) {
    let aStart = h.aStart;
    let aEnd = h.aEnd;
    let bStart = h.bStart;
    let bEnd = h.bEnd;
    if (aStart === aEnd || bStart === bEnd) continue; // 追加・削除だけは対象外
    // 短すぎるときは前後の文字を足す（前を優先、足りなければ後ろ）
    while (aEnd - aStart < MIN_FROM) {
      if (aStart > 0 && bStart > 0) {
        aStart--;
        bStart--;
      } else if (aEnd < a.length && bEnd < b.length) {
        aEnd++;
        bEnd++;
      } else {
        break;
      }
    }
    const from = a.slice(aStart, aEnd).join('');
    const to = b.slice(bStart, bEnd).join('');
    if (from.length < MIN_FROM || !to || from === to) continue;
    if (from.length > MAX_LEN || to.length > MAX_LEN) continue;
    if (/^[\s、。！？!?,.]+$/.test(from)) continue;
    const key = `${from}→${to}`;
    if (seen.has(key)) continue;
    seen.add(key);
    pairs.push({ from, to });
  }
  return pairs;
}

/** 辞書ファイルに追記する行（「誤り→正」） */
export function dictionaryLines(pairs: CorrectionPair[]): string[] {
  return pairs
    .filter(
      (p) => p.from.trim() && p.to.trim() && p.from !== p.to && !/[\r\n→]/.test(p.from + p.to)
    )
    .map((p) => `${p.from.trim()}→${p.to.trim()}`);
}

/**
 * 差分形式の返答（1行1件「誤→正」、無ければ「なし」）を元の文章に適用する。
 * 元の文章に無い「誤」・同じ文字列・極端に長い置換は無視する（AIの勝手な書き換えを防ぐ）。
 * 1件も適用できなければ null。
 */
export function applyDiffReply(original: string, reply: string): string | null {
  let text = original;
  let applied = 0;
  for (const line of reply.split(/\r?\n/)) {
    const m = /^\s*[-*・]?\s*(.+?)\s*(?:→|->|=>)\s*(.+?)\s*$/.exec(line);
    if (!m) continue;
    const from = m[1].replace(/^[「『"]|[」』"]$/g, '');
    const to = m[2].replace(/^[「『"]|[」』"]$/g, '');
    if (!from || !to || from === to) continue;
    if (Array.from(to).length > Array.from(from).length * 3 + 6) continue;
    if (!text.includes(from)) continue;
    text = text.replace(from, to);
    applied++;
  }
  return applied > 0 ? text : null;
}

export interface VisibleChange {
  from: string;
  to: string;
  /** original 中の位置 [aStart, aEnd) と corrected 中の位置 [bStart, bEnd) */
  aStart: number;
  aEnd: number;
  bStart: number;
  bEnd: number;
}

/**
 * 画面に見える変更（追加・削除・置換のすべて）を返す。学習用の diffCorrections と違い、挿入だけ・削除だけの変更も含む。
 * 修正件数の計算と、校正の妥当性の検査に使う。同じ文章なら空。
 */
export function visibleDiff(original: string, corrected: string): VisibleChange[] {
  if (original === corrected) return [];
  const a = Array.from(original);
  const b = Array.from(corrected);
  if (a.length > 1200 || b.length > 1200) {
    return [
      { from: original, to: corrected, aStart: 0, aEnd: a.length, bStart: 0, bEnd: b.length },
    ];
  }
  return mergeHunks(diffHunks(a, b), 1).map((h) => ({
    from: a.slice(h.aStart, h.aEnd).join(''),
    to: b.slice(h.bStart, h.bEnd).join(''),
    aStart: h.aStart,
    aEnd: h.aEnd,
    bStart: h.bStart,
    bEnd: h.bEnd,
  }));
}
