/**
 * 書式・言い直しの音声コマンド（純粋関数）。
 *
 * どれも「発話全体がそのコマンドのとき」だけ命令として扱い、文章の一部に含まれているだけなら
 * 普通のテキストとして入力する（誤作動防止）。
 *
 *   箇条書き:   「箇条書き」→ ・ を付けて開始、「改行」「次」で次の ・、「箇条書き終わり」で抜ける
 *   番号付き:   「番号」→ 1. 2. 3. と自動採番、「次」「改行」で次の番号
 *   段落:       「段落」→ 空行
 *   言い直し:   「違う ロキソニン じゃなくて ボルタレン」→ 直前の「ロキソニン」だけ差し替え
 *               「訂正 ロキソニン を ボルタレン に」も同じ
 */

export type ListStyle = 'bullet' | 'number';

export type FormatCommand =
  | { kind: 'list-start'; style: ListStyle }
  | { kind: 'list-end' }
  | { kind: 'list-next' }
  | { kind: 'paragraph' }
  | { kind: 'fix'; from: string; to: string };

const BULLET =
  /^(?:箇条書き|過剰書き|かじょうがき|箇条書き開始|箇条書きにして|箇条書きスタート|リスト|リスト開始|黒丸)$/;
const NUMBER =
  /^(?:番号付き|番号つき|番号付きリスト|番号リスト|番号付き箇条書き|ナンバリング|連番|番号|番号開始)$/;
const LIST_END =
  /^(?:箇条書き|過剰書き|リスト|番号付きリスト|番号付き|番号リスト|番号|ナンバリング)(?:を)?(?:終わり|おわり|終了|終わる|終わります|やめ|やめる|解除|おしまい|終わって)$/;
const LIST_NEXT = /^(?:次|つぎ|次の項目|つぎの項目|次へ|次の行|次の番号|項目)$/;
const PARAGRAPH = /^(?:新しい段落|段落|段落分け|改段落|空行|くうぎょう)$/;

const FIX_A =
  /^(?:違う|ちがう|間違えた|まちがえた|いや)[、,]?\s*(.{1,30}?)\s*(?:じゃなくて|ではなくて|じゃなく|ではなく|じゃない|ではない)[、,]?\s*(.{1,40}?)(?:でした|です)?$/;
const FIX_B =
  /^(?:訂正|修正|直して)[、,]?\s*(.{1,30}?)\s*を\s*(.{1,40}?)\s*(?:に訂正|にして|に直して|に修正|に)$/;

function norm(text: string): string {
  return text.replace(/[\s\u3000、。，．,.!！?？]+/g, '');
}

function trimTail(text: string): string {
  return text.trim().replace(/[。、，．,.!！?？\s\u3000]+$/g, '');
}

/**
 * 発話全体が書式コマンドなら、その内容を返す。
 * inList: 箇条書き・番号リストの入力中か（「次」はリスト中だけコマンドにする）
 */
export function parseFormatCommand(text: string, inList = false): FormatCommand | null {
  const t = norm(text);
  if (!t || t.length > 60) return null;
  if (t.length <= 14) {
    if (LIST_END.test(t)) return { kind: 'list-end' };
    if (BULLET.test(t)) return { kind: 'list-start', style: 'bullet' };
    if (NUMBER.test(t)) return { kind: 'list-start', style: 'number' };
    if (PARAGRAPH.test(t)) return { kind: 'paragraph' };
    if (inList && LIST_NEXT.test(t)) return { kind: 'list-next' };
  }
  const body = trimTail(text);
  const m = FIX_A.exec(body) ?? FIX_B.exec(body);
  if (m) {
    const from = m[1].trim();
    const to = m[2].trim();
    if (from && to && from !== to) return { kind: 'fix', from, to };
  }
  return null;
}

/** 箇条書き・番号の行頭記号 */
export function listMarker(style: ListStyle, n: number): string {
  return style === 'bullet' ? '・' : `${n}. `;
}

/** 直前に出てきた from を to に差し替える（見つからなければ ok=false） */
export function applyFix(buffer: string, from: string, to: string): { text: string; ok: boolean } {
  const idx = buffer.lastIndexOf(from);
  if (idx < 0) return { text: buffer, ok: false };
  return { text: buffer.slice(0, idx) + to + buffer.slice(idx + from.length), ok: true };
}

/** 空の行頭記号で終わっていれば取り除く（リストを閉じるとき・次の項目へ進むとき用） */
export function stripEmptyMarker(buffer: string, marker: string): string {
  if (!marker || !buffer.endsWith(marker)) return buffer;
  const head = buffer.slice(0, buffer.length - marker.length);
  return head.replace(/\n$/, '');
}

/** 「かっこ ○○ とじ」「かぎかっこ ○○ とじ」を記号に変換する */
export function applySpokenBrackets(text: string): string {
  return text
    .replace(
      /(?:かぎかっこ|カギカッコ|かぎ括弧|カギ括弧)(.+?)(?:かぎかっことじ|かぎかっこ閉じ|とじかっこ|閉じかっこ|とじ|閉じ)/g,
      '「$1」'
    )
    .replace(
      /(?:かっこ|カッコ|括弧)(.+?)(?:かっことじ|かっこ閉じ|とじかっこ|閉じかっこ|とじ|閉じ)/g,
      '（$1）'
    );
}
