/**
 * 音声コマンド（純粋関数）。発話全体がコマンドのときだけ命令として扱い、
 * 文章の一部に含まれているだけのときは普通のテキストとして入力する。
 *
 *   編集:  「いまの取り消し」「それを削除」→ 直前の1文を消す
 *          「全部消して」→ 今回の入力をすべて消す
 *          「一文字削除」「3文字削除」→ 末尾から指定の文字数を消す
 *          「入力終了」→ Enter と同じ（音声入力を終える）
 *   定型文: 「定型 風邪」「テンプレート 紹介状」→ 登録済みの定型文を入力
 */
import { kanjiToNumber } from './medicalFormat';

export type EditCommand =
  { kind: 'undo' } | { kind: 'clear' } | { kind: 'chars'; n: number } | { kind: 'finish' };

const MAX_DELETE_CHARS = 50;

const UNDO =
  /^(?:(?:いまの|今の|さっきの|直前の)?(?:取り消し|取消し?|とりけし|やり直し|やりなおし)|(?:それを|いまの|今の|直前の|さっきの)(?:削除|消去|消して|消す))$/;
const CLEAR =
  /^(?:(?:全部|すべて|全て|ぜんぶ|全文|全体)(?:を)?(?:消して|消す|削除|消去|取り消し|取消し|クリア)(?:ください)?|全削除|全消去|最初からやり直し|はじめからやり直し)$/;
const CHARS = /^([0-9〇零一二三四五六七八九十]+)文字(?:を)?(?:削除|消して|消す|消去)(?:ください)?$/;
const FINISH =
  /^(?:(?:音声)?入力(?:を)?(?:終了|終わり|おわり|完了|確定)|(?:聞き取り|ディクテーション|音声入力)(?:を)?(?:終了|停止)|入力確定)(?:する|します|して|してください)?$/;

/** 「前の文を消して」「さっきの文を削除」など、文を指定した取り消し */
const SENTENCE_UNDO =
  /^(?:今の|いまの|その|前の|直前の|さっきの|最後の)(?:文|ぶん|一文|1文)(?:を)?(?:消して|けして|削除|消去|取り消し|取り消して|やり直し)(?:ください)?$/;

function normalizeCommand(text: string): string {
  return text.replace(/[\s\u3000]+/g, '').replace(/[。、．，,.!！?？]+$/g, '');
}

/** 発話全体が編集コマンドならその内容を返す */
export function parseEditCommand(text: string): EditCommand | null {
  const t = normalizeCommand(text);
  if (!t || t.length > 20) return null;
  if (UNDO.test(t) || SENTENCE_UNDO.test(t)) return { kind: 'undo' };
  if (CLEAR.test(t)) return { kind: 'clear' };
  if (FINISH.test(t)) return { kind: 'finish' };
  const m = CHARS.exec(t);
  if (m) {
    const n = kanjiToNumber(m[1]);
    if (n !== null && n >= 1 && n <= MAX_DELETE_CHARS) return { kind: 'chars', n };
  }
  return null;
}

/** 末尾から n 文字（サロゲートペア・結合文字を1文字として）取り除く */
export function removeLastChars(text: string, n: number): string {
  if (n <= 0) return text;
  const Segmenter = (
    Intl as unknown as {
      Segmenter?: new (
        l?: string,
        o?: object
      ) => { segment(s: string): Iterable<{ segment: string }> };
    }
  ).Segmenter;
  const parts = Segmenter
    ? Array.from(new Segmenter('ja', { granularity: 'grapheme' }).segment(text), (x) => x.segment)
    : Array.from(text);
  return parts.slice(0, Math.max(0, parts.length - n)).join('');
}

// ---- 日付・時刻の入力（「今日の日付」「いまの時刻」）----
export interface InsertCommand {
  kind: 'date' | 'datetime' | 'time';
  western: boolean;
}

const INSERT_TAIL = '(?:を)?(?:入力|挿入|入れて|いれて)?(?:して|してください)?';
const INSERT_DATETIME = new RegExp(
  `^(西暦)?(?:今日の|きょうの|本日の|いまの|今の)?(?:日時|にちじ)${INSERT_TAIL}$`
);
const INSERT_DATE = new RegExp(`^(西暦)?(?:今日の|きょうの|本日の)?(?:日付|ひづけ)${INSERT_TAIL}$`);
const INSERT_TIME =
  /^(?:(?:いまの|今の|現在の)?(?:時刻|じこく)(?:を)?(?:入力|挿入|入れて|いれて)(?:して|してください)?|(?:いまの|今の|現在の)(?:時刻|じこく))$/;

/** 発話全体が日付・時刻の入力コマンドなら、その内容を返す */
export function parseInsertCommand(text: string): InsertCommand | null {
  const t = normalizeCommand(text);
  if (!t || t.length > 16) return null;
  let m = INSERT_DATETIME.exec(t);
  if (m) return { kind: 'datetime', western: Boolean(m[1]) };
  m = INSERT_DATE.exec(t);
  if (m) return { kind: 'date', western: Boolean(m[1]) };
  if (INSERT_TIME.test(t)) return { kind: 'time', western: false };
  return null;
}

/** 日付・時刻の文字列（令和8年10月30日 / 2026年10月30日、18時05分） */
export function formatInsert(cmd: InsertCommand, now: Date = new Date()): string {
  const y = now.getFullYear();
  const year = cmd.western || y < 2019 ? `${y}年` : `令和${y - 2018}年`;
  const date = `${year}${now.getMonth() + 1}月${now.getDate()}日`;
  const time = `${now.getHours()}時${String(now.getMinutes()).padStart(2, '0')}分`;
  if (cmd.kind === 'date') return date;
  if (cmd.kind === 'time') return time;
  return `${date} ${time}`;
}

// ---- 見出しテンプレート（SOAP・内視鏡所見） ----
// 「SOAP」と言うと見出し入力モードになり、「O」「エー」などの一言で次の見出しが入る。
// 見出しの中身は話した言葉のまま。AI による補完・推測はしない（診断欄も空のまま）。
// モードに入っている間だけ有効なので、普段の文章に「評価」などの単語を入れても誤爆しない。

export interface TemplateSection {
  /** 入力される見出し（改行のあとに入る） */
  header: string;
  /** この見出しを呼ぶ発話（発話全体が一致したときだけ） */
  phrases: string[];
}

export interface TemplateMode {
  id: string;
  label: string;
  /** このモードを始める発話 */
  startPhrases: string[];
  /** 始めたとき最初に入る見出し（sections の header のどれか） */
  firstHeader: string;
  sections: TemplateSection[];
}

export const TEMPLATE_MODES: TemplateMode[] = [
  {
    id: 'soap',
    label: 'SOAP',
    startPhrases: [
      'SOAP',
      'ソープ',
      'ソープ開始',
      'SOAP開始',
      'カルテモード',
      'SOAPモード',
      'カルテ',
      'カルテ入力',
      'カルテ開始',
      'SOAP入力',
      // 「SOAP」が聞き違えられやすい言い方
      'OAP',
      'オーエーピー',
      'ソアップ',
    ],
    firstHeader: 'S)',
    sections: [
      {
        header: 'S)',
        phrases: ['S', 'エス', 'エスです', '主観', '主観的情報', 'サブジェクティブ'],
      },
      {
        header: 'O)',
        phrases: ['O', 'オー', 'オーです', '客観', '客観的情報', 'オブジェクティブ'],
      },
      { header: 'A)', phrases: ['A', 'エー', 'エーです', '評価', 'アセスメント'] },
      { header: 'P)', phrases: ['P', 'ピー', 'ピーです', '方針', '計画', 'プラン'] },
    ],
  },
  {
    id: 'endoscopy',
    label: '内視鏡所見',
    startPhrases: ['内視鏡モード', '内視鏡所見', '内視鏡テンプレート', '所見モード'],
    firstHeader: '部位：',
    sections: [
      { header: '部位：', phrases: ['部位', '所見部位'] },
      { header: '病変：', phrases: ['病変', '所見'] },
      { header: '処置：', phrases: ['処置', '施行'] },
      { header: '診断：', phrases: ['診断', '診断欄'] },
    ],
  },
];

const TEMPLATE_END =
  /^(?:テンプレート|見出し|SOAP|ソープ|内視鏡|所見)(?:モード)?(?:を)?(?:終了|終わり|おしまい|解除|オフ)$/i;

function templateKey(text: string): string {
  return text
    .normalize('NFKC')
    .replace(/[\s\u3000、。，．,.!！?？]+/g, '')
    .toLowerCase();
}

/** 発話全体がテンプレートモードの開始なら、そのモードを返す */
export function matchTemplateStart(text: string): TemplateMode | null {
  const k = templateKey(text);
  if (!k || k.length > 12) return null;
  return TEMPLATE_MODES.find((m) => m.startPhrases.some((p) => templateKey(p) === k)) ?? null;
}

/** モード中の「次」: 今の見出しの次の見出しへ進む合図 */
const TEMPLATE_NEXT =
  /^(?:次|つぎ|次へ|つぎへ|次の項目|次の見出し|次いきます|はい次|はいつぎ|ネクスト|next)$/;
export function isTemplateNext(text: string): boolean {
  const k = templateKey(text);
  return Boolean(k) && k.length <= 8 && TEMPLATE_NEXT.test(k);
}

/** 今の見出しの次の見出し（最後ならnull） */
export function nextTemplateHeader(mode: TemplateMode, current: string): string | null {
  const i = mode.sections.findIndex((s) => s.header === current);
  return mode.sections[i + 1]?.header ?? null;
}

/** モード中に、発話全体が見出しの呼び出しなら、その見出しを返す */
export function matchTemplateSection(text: string, mode: TemplateMode): string | null {
  const k = templateKey(text);
  if (!k) return null;
  const hit = mode.sections.find((s) => s.phrases.some((p) => templateKey(p) === k));
  return hit?.header ?? null;
}

/** 発話全体がテンプレートモードの終了か */
export function isTemplateEnd(text: string): boolean {
  const k = templateKey(text);
  return Boolean(k) && TEMPLATE_END.test(k);
}

// ---- 定型文の音声呼び出し ----
const SNIPPET_PREFIX =
  /^(?:定型文|ていけいぶん|定型|ていけい|テンプレート|テンプレ|スニペット)(?:を)?[、,\s]*/;
const SNIPPET_SUFFIX = /(?:を)?(?:入力|挿入|お願いします|お願い|ください|出して|入れて)$/;

/** 照合用に正規化（全半角・空白・句読点・カタカナ/ひらがなの差を吸収） */
export function normalizeForMatch(text: string): string {
  return text
    .normalize('NFKC')
    .replace(/[\s\u3000、。，．,.!！?？「」『』]/g, '')
    .replace(/[\u30A1-\u30F6]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0x60))
    .toLowerCase();
}

/**
 * 「定型 ○○」のような発話なら、登録済み定型文の名前（names の要素）を返す。
 * 名前に一致するものが無ければ null（普通の文章として入力する）。
 */
export function matchSnippetCommand(text: string, names: string[]): string | null {
  const head = SNIPPET_PREFIX.exec(text.trim());
  if (!head) return null;
  let query = text
    .trim()
    .slice(head[0].length)
    .replace(/[。、．，,.!！?？\s\u3000]+$/g, '');
  query = query.replace(SNIPPET_SUFFIX, '');
  const q = normalizeForMatch(query);
  if (q.length < 2) return null;

  let best: { name: string; score: number } | null = null;
  for (const name of names) {
    const n = normalizeForMatch(name);
    if (!n) continue;
    let score = 0;
    if (n === q) score = 1000;
    else if (n.length >= 2 && n.includes(q)) score = 500 - (n.length - q.length);
    else if (n.length >= 2 && q.includes(n)) score = 300 + n.length;
    if (score > 0 && (!best || score > best.score)) best = { name, score };
  }
  return best?.name ?? null;
}
