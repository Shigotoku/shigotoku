import { DISEASE_DATA } from './diseaseNames';

/**
 * 病名の補正: 音声認識が病名をひらがな・カタカナで返したとき、標準病名マスターの病名（漢字）へ直す。
 * 例: 「きゅうせいいんとうえん」→「急性咽頭炎」。読みが6文字以上で、1つの病名に決まるものだけ。
 */
let table: Map<string, string> | null = null;
const MIN_LEN = 6;
const MAX_LEN = 30;

function load(): Map<string, string> {
  if (!table) {
    table = new Map();
    for (const line of DISEASE_DATA.split('\n')) {
      const i = line.indexOf('\t');
      if (i > 0) table.set(line.slice(0, i), line.slice(i + 1));
    }
  }
  return table;
}

const toHira = (s: string): string =>
  s.replace(/[ァ-ヶ]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0x60));

/** 読み（ひらがな）から病名。なければ null */
export function diseaseByReading(reading: string): string | null {
  return load().get(toHira(reading)) ?? null;
}

/** 文中のかな書きの病名を、病名（漢字）へ。かな以外の文字は 1 文字単位でそのまま通す */
export function correctDiseaseNames(text: string): string {
  if (!/[ぁ-ゖァ-ヶ]{6}/.test(text)) return text;
  const map = load();
  const hira = toHira(text); // 1 文字ずつ対応（長さは変わらない）
  let out = '';
  let i = 0;
  while (i < text.length) {
    let hit = '';
    let len = 0;
    if (/[ぁ-ゖー]/.test(hira[i])) {
      for (let l = Math.min(MAX_LEN, text.length - i); l >= MIN_LEN; l--) {
        const name = map.get(hira.slice(i, i + l));
        if (name) {
          hit = name;
          len = l;
          break;
        }
      }
    }
    if (hit) {
      out += hit;
      i += len;
    } else {
      out += text[i];
      i++;
    }
  }
  return out;
}
