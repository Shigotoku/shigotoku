/**
 * マイク診断の判定（純粋関数）。
 * 認識エンジン（Chrome）のページで「静かな時の音量」と「話した時の音量」を測り、
 * その数値からマイクが音声入力に向いているかと、改善のアドバイスを日本語で返す。
 */

export interface MicMeasurement {
  /** マイクのデバイス名 */
  label: string;
  /** 静かにしている間の音量（dBFS。小さいほど静か） */
  noiseDb: number;
  /** 話している間の音量（dBFS。大きい声の区間の目安） */
  speechDb: number;
  /** 音が割れている（振幅が上限に張り付く）サンプルの割合 0〜1 */
  clipRatio: number;
}

export type MicLevel = 'good' | 'fair' | 'poor';

export interface MicVerdict {
  level: MicLevel;
  title: string;
  /** 結果の詳細とアドバイス（1行ずつ） */
  lines: string[];
}

const RANK: Record<MicLevel, number> = { good: 0, fair: 1, poor: 2 };

function worse(a: MicLevel, b: MicLevel): MicLevel {
  return RANK[a] >= RANK[b] ? a : b;
}

/** ノートPC内蔵・マイクアレイなど、口元から離れがちなマイクの名前 */
const BUILT_IN_MIC =
  /array|内蔵|internal|built-?in|マイク配列|microphone\s*\(realtek|stereo\s*mix/i;

export function evaluateMic(m: MicMeasurement): MicVerdict {
  const snr = m.speechDb - m.noiseDb;
  const lines: string[] = [];
  let level: MicLevel = 'good';

  lines.push(`マイク: ${m.label || '（名前を取得できませんでした）'}`);
  lines.push(
    `話した声 ${m.speechDb.toFixed(0)} dB ／ 周囲の音 ${m.noiseDb.toFixed(0)} dB ／ 差 ${snr.toFixed(0)} dB`
  );

  if (snr < 8) {
    level = 'poor';
    lines.push(
      '・声がほとんど検出されませんでした。マイクのミュート、使用するマイクの選択、マイクとの距離を確認してください。'
    );
  } else {
    if (m.speechDb < -42) {
      level = worse(level, 'poor');
      lines.push(
        '・声が小さすぎます。マイクに近づくか、Windows の設定でマイクの入力音量を上げてください。'
      );
    } else if (m.speechDb < -34) {
      level = worse(level, 'fair');
      lines.push(
        '・声がやや小さめです。マイクに近づくか、入力音量を少し上げると認識が安定します。'
      );
    }
    if (m.clipRatio >= 0.01) {
      level = worse(level, 'poor');
      lines.push('・音が割れています。マイクから少し離れるか、入力音量を下げてください。');
    }
    if (snr < 20) {
      level = worse(level, 'poor');
      lines.push(
        '・周囲の雑音が大きく、認識の精度が落ちます。静かな場所、またはヘッドセットを使ってください。'
      );
    } else if (snr < 28) {
      level = worse(level, 'fair');
      lines.push('・周囲の音がやや目立ちます。口元で使えるヘッドセットだと、さらに安定します。');
    }
  }

  if (level !== 'good' && BUILT_IN_MIC.test(m.label)) {
    lines.push(
      '・ノートPC内蔵のマイクは口から遠く、雑音も拾いがちです。USB ヘッドセットを強くおすすめします。'
    );
  }
  if (level === 'good') {
    lines.push('・このマイクで問題なく使えます。');
  }

  const title =
    level === 'good'
      ? 'マイクの状態は良好です'
      : level === 'fair'
        ? 'マイクは使えますが、改善の余地があります'
        : 'マイクの状態に問題があります';
  return { level, title, lines };
}

/** 振幅（0〜1）を dBFS に。無音は -100 に丸める */
export function toDb(amplitude: number): number {
  if (!(amplitude > 0)) return -100;
  return Math.max(-100, 20 * Math.log10(amplitude));
}
