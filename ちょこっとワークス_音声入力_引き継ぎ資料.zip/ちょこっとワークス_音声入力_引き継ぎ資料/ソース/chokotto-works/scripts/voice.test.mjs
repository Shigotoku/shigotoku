// 数値整形・音声コマンド・訂正の学習・マイク判定の確認。実行: npm test（先に tsc でビルドされる）
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const f = require('../dist/shared/medicalFormat.js');
const v = require('../dist/shared/voiceCommands.js');
const c = require('../dist/shared/corrections.js');
const m = require('../dist/shared/micCheck.js');

const fmt = f.formatMedicalNumbers;

// ---- 漢数字 ----
assert.equal(f.kanjiToNumber('三十六'), 36);
assert.equal(f.kanjiToNumber('百三十'), 130);
assert.equal(f.kanjiToNumber('八十'), 80);
assert.equal(f.kanjiToNumber('十'), 10);
assert.equal(f.kanjiToNumber('二百五十'), 250);
assert.equal(f.kanjiToNumber('一三〇'), 130);
assert.equal(f.kanjiToNumber('12'), 12);
assert.equal(f.kanjiToNumber('あ'), null);

// ---- 血圧 ----
assert.equal(fmt('血圧は130の80です'), '血圧は130/80です');
assert.equal(fmt('血圧130の80'), '血圧130/80');
assert.equal(fmt('血圧は百三十の八十'), '血圧は130/80');
assert.equal(fmt('BP 150の90'.replace(' ', '')), 'BP150/90');
assert.equal(fmt('血圧は１３０の８０でした'), '血圧は130/80でした');
assert.equal(fmt('130の80ミリ'), '130/80ミリ');
// 文脈が無い・数値が血圧らしくないときは変えない
assert.equal(fmt('100の50を比べる'), '100の50を比べる');
assert.equal(fmt('血圧は80の130'), '血圧は80の130'); // 上が下より小さい
assert.equal(fmt('今日は3つの2'), '今日は3つの2');

// ---- 体温 ----
assert.equal(fmt('体温は36度5分です'), '体温は36.5℃です');
assert.equal(fmt('三十八度二分の熱'), '38.2℃の熱');
assert.equal(fmt('体温36.5度'), '体温36.5℃');
assert.equal(fmt('38度以上の発熱'), '38℃以上の発熱');
assert.equal(fmt('37度台'), '37℃台');
// 関節の角度や体温らしくない値は変えない
assert.equal(fmt('膝の屈曲は40度です'), '膝の屈曲は40度です');
assert.equal(fmt('90度回転'), '90度回転');
assert.equal(fmt('25度の部屋'), '25度の部屋');
assert.equal(fmt('36度5分'), '36.5℃');

// ---- 単位 ----
assert.equal(fmt('ロキソニン60ミリグラム'), 'ロキソニン60mg');
assert.equal(fmt('五十ミリグラム'), '50mg');
assert.equal(fmt('0.5マイクログラム'), '0.5μg');
assert.equal(fmt('零点五ミリグラム'), '0.5mg');
assert.equal(fmt('2点5ミリグラム'), '2.5mg');
assert.equal(fmt('体重60キログラム'), '体重60kg');
assert.equal(fmt('10ミリリットル'), '10mL');
assert.equal(fmt('3センチ'), '3cm');
assert.equal(fmt('5ミリメートル'), '5mm');
assert.equal(fmt('塩分5パーセント'), '塩分5%');
assert.equal(fmt('百パーセント'), '100%');
assert.equal(fmt('グラム陽性菌'), 'グラム陽性菌'); // 数字が無ければ変えない
assert.equal(fmt('1日3回毎食後'), '1日3回毎食後');
assert.equal(fmt(''), '');

// ---- 編集コマンド ----
const p = v.parseEditCommand;
assert.deepEqual(p('いまの取り消し'), { kind: 'undo' });
assert.deepEqual(p('取り消し。'), { kind: 'undo' });
assert.deepEqual(p('それを削除'), { kind: 'undo' });
assert.deepEqual(p('それを消して'), { kind: 'undo' });
assert.deepEqual(p('やり直し'), { kind: 'undo' });
assert.deepEqual(p('全部消して'), { kind: 'clear' });
assert.deepEqual(p('すべて削除'), { kind: 'clear' });
assert.deepEqual(p('全削除'), { kind: 'clear' });
assert.deepEqual(p('一文字削除'), { kind: 'chars', n: 1 });
assert.deepEqual(p('1文字削除'), { kind: 'chars', n: 1 });
assert.deepEqual(p('三文字消して'), { kind: 'chars', n: 3 });
assert.deepEqual(p('10文字削除'), { kind: 'chars', n: 10 });
assert.deepEqual(p('入力終了'), { kind: 'finish' });
assert.deepEqual(p('音声入力を終了'), { kind: 'finish' });
assert.deepEqual(p('聞き取り停止'), { kind: 'finish' });
// 文章の一部・長い文は命令にしない
assert.equal(p('昨日の薬を全部消して'), null);
assert.equal(p('今日の入力終了までに間に合わせます'), null);
assert.equal(p('100文字削除'), null);
assert.equal(p('0文字削除'), null);
assert.equal(p('頭痛があります'), null);
assert.equal(p(''), null);

assert.equal(v.removeLastChars('こんにちは。', 1), 'こんにちは');
assert.equal(v.removeLastChars('こんにちは。', 3), 'こんに');
assert.equal(v.removeLastChars('あ', 5), '');
assert.equal(v.removeLastChars('abc', 0), 'abc');
assert.equal(v.removeLastChars('a😀', 1), 'a');

// ---- 定型文の音声呼び出し ----
const names = ['風邪の説明', '診療情報提供書（冒頭）', '今日の日付', '予約変更のご案内'];
const s = v.matchSnippetCommand;
assert.equal(s('定型風邪の説明', names), '風邪の説明');
assert.equal(s('定型 風邪', names), '風邪の説明'); // 名前の一部
assert.equal(s('テンプレート紹介状', names), null);
assert.equal(s('定型文、今日の日付', names), '今日の日付');
assert.equal(s('定型今日の日付を入力', names), '今日の日付');
assert.equal(s('スニペット予約変更のご案内。', names), '予約変更のご案内');
assert.equal(s('定型診療情報提供書', names), '診療情報提供書（冒頭）');
// 一致する名前が無い・先頭が違う・短すぎるときは普通の文章
assert.equal(s('定型の薬を出します', names), null);
assert.equal(s('風邪の説明', names), null);
assert.equal(s('定型あ', names), null);
assert.equal(s('定型', names), null);
assert.equal(v.normalizeForMatch('ＡＢＣ　あいう'), 'abcあいう');
assert.equal(v.normalizeForMatch('カゼ'), 'かぜ');

// ---- 訂正の学習 ----
const d = c.diffCorrections;
assert.deepEqual(d('逆流性食堂炎です', '逆流性食道炎です'), [{ from: '食堂', to: '食道' }]);
assert.deepEqual(d('ろきそにんを出します', 'ロキソニンを出します'), [{ from: 'ろきそにん', to: 'ロキソニン' }]);
// 1文字だけの誤りは前後の文字を足して2文字以上にする
const one = d('胃が痛いです', '医が痛いです');
assert.equal(one.length, 1);
assert.ok(Array.from(one[0].from).length >= 2);
assert.ok(one[0].from.includes('胃') && one[0].to.includes('医'));
// 複数の訂正
const two = d('食堂炎と慢成腎臓病', '食道炎と慢性腎臓病');
assert.equal(two.length, 2);
// 変更なし・追加のみ・削除のみは候補なし
assert.deepEqual(d('同じ', '同じ'), []);
assert.deepEqual(d('頭痛です', '頭痛ですね'), []);
assert.deepEqual(d('頭痛ですね', '頭痛です'), []);
assert.deepEqual(d('', 'あ'), []);
assert.deepEqual(c.dictionaryLines([{ from: ' 食堂 ', to: '食道' }, { from: 'a', to: 'a' }, { from: '', to: 'x' }]), ['食堂→食道']);
assert.deepEqual(c.dictionaryLines([{ from: 'あ→い', to: 'う' }]), []);

// ---- AI校正の差分返答（誤→正）を元の文章へ適用 ----
const applyDiff = c.applyDiffReply;
assert.equal(applyDiff('逆流性食堂炎です', '食堂炎→食道炎'), '逆流性食道炎です');
assert.equal(applyDiff('食堂炎と慢成腎臓病', '食堂炎→食道炎\n慢成腎臓病→慢性腎臓病'), '食道炎と慢性腎臓病');
assert.equal(applyDiff('頭痛です', 'なし'), null);
assert.equal(applyDiff('頭痛です', '「頭痛」→「偏頭痛」'), '偏頭痛です');
assert.equal(applyDiff('頭痛です', '- 頭痛->片頭痛'), '片頭痛です'); // 箇条書き・ASCII矢印も許容
assert.equal(applyDiff('頭痛です', '腹痛→胃痛'), null); // 元の文に無い「誤」は無視
assert.equal(applyDiff('頭痛です', '頭痛→頭痛'), null); // 同一は無視
assert.equal(applyDiff('頭痛です', '頭痛→' + 'あ'.repeat(40)), null); // 極端に長い置換は無視
assert.equal(applyDiff('頭痛です', '説明文だけ'), null);

// ---- マイク判定 ----
const mic = (o) => m.evaluateMic({ label: 'USB ヘッドセット', noiseDb: -60, speechDb: -22, clipRatio: 0, ...o });
assert.equal(mic({}).level, 'good');
assert.equal(mic({ speechDb: -45 }).level, 'poor'); // 小さすぎ
assert.equal(mic({ speechDb: -38 }).level, 'fair'); // やや小さい
assert.equal(mic({ clipRatio: 0.05 }).level, 'poor'); // 割れ
assert.equal(mic({ noiseDb: -35, speechDb: -22 }).level, 'poor'); // 雑音が大きい(差13dB)
assert.equal(mic({ noiseDb: -50, speechDb: -25 }).level, 'fair'); // 差25dB
assert.equal(mic({ noiseDb: -40, speechDb: -35 }).level, 'poor'); // 声が検出されない
const builtIn = mic({ label: 'Microphone Array (Realtek)', noiseDb: -40, speechDb: -30 });
assert.notEqual(builtIn.level, 'good');
assert.ok(builtIn.lines.some((l) => l.includes('ヘッドセット')));
assert.equal(m.toDb(1), 0);
assert.equal(m.toDb(0), -100);
assert.ok(Math.abs(m.toDb(0.1) + 20) < 1e-9);

// ---- 内視鏡所見の「ミリ」 ----
assert.equal(fmt('5ミリぐらいの陥凹性病変'), '5mmぐらいの陥凹性病変');
assert.equal(fmt('5ミリ秒'), '5ミリ秒');
assert.equal(fmt('130の80ミリ'), '130/80ミリ');
assert.equal(fmt('血圧は130/80ミリ水銀柱'), '血圧は130/80ミリ水銀柱');

// ---- 言い直し ----
const r = require('../dist/shared/rephrase.js').applyRephrase;
// 曜日・日付・時刻
assert.equal(r('来週火曜日、いや水曜日の午前10時', true), '来週水曜日の午前10時');
assert.equal(r('火曜日いや水曜日', true), '水曜日');
assert.equal(r('月曜日、あ、違う、金曜日に来院', true), '金曜日に来院');
assert.equal(r('10月5日、いや6日に予約', false), '10月6日に予約');
assert.equal(r('10時、いや11時に集合', false), '11時に集合');
// 医療モード（strict）: 数値・左右は「いや」では置き換えず、両方を残す
assert.equal(r('50mg、いや100mg', true), '50mg、いや100mg');
assert.equal(r('右、いや左の膝', true), '右、いや左の膝');
// 明示的な訂正語なら置き換える
assert.equal(r('50mg、違う、100mg', true), '100mg');
assert.equal(r('右、間違えた、左の膝', true), '左の膝');
assert.equal(r('3回、訂正、5回服用', true), '5回服用');
// 医療モードでない（日常）ときは「いや」でも置き換える
assert.equal(r('50mg、いや100mg', false), '100mg');
assert.equal(r('右、いや左の膝', false), '左の膝');
// 種類・単位が違うときは何もしない
assert.equal(r('3日、いや5回', false), '3日、いや5回');
assert.equal(r('火曜日、いや5日', false), '火曜日、いや5日');
assert.equal(r('いや、それは違います', false), 'いや、それは違います');
assert.equal(r('今日は晴れです', true), '今日は晴れです');
assert.equal(r('', true), '');

// ---- 見出しテンプレート ----
const soap = v.TEMPLATE_MODES.find((x) => x.id === 'soap');
const endo = v.TEMPLATE_MODES.find((x) => x.id === 'endoscopy');
assert.equal(v.matchTemplateStart('SOAP')?.id, 'soap');
assert.equal(v.matchTemplateStart('ソープ。')?.id, 'soap');
assert.equal(v.matchTemplateStart('カルテモード')?.id, 'soap');
assert.equal(v.matchTemplateStart('内視鏡モード')?.id, 'endoscopy');
assert.equal(v.matchTemplateStart('今日はソープランドの話'), null);
assert.equal(v.matchTemplateStart('評価'), null); // モード外では見出しにならない
assert.equal(v.matchTemplateSection('O', soap), 'O)');
assert.equal(v.matchTemplateSection('オー', soap), 'O)');
assert.equal(v.matchTemplateSection('エー。', soap), 'A)');
assert.equal(v.matchTemplateSection('方針', soap), 'P)');
assert.equal(v.matchTemplateSection('頭痛があります', soap), null);
assert.equal(v.matchTemplateSection('所見', endo), '病変：');
assert.equal(v.matchTemplateSection('診断', endo), '診断：');
assert.equal(v.matchTemplateSection('O', endo), null); // 別モードの呼び名は無効
assert.equal(v.isTemplateEnd('SOAP終了'), true);
assert.equal(v.isTemplateEnd('テンプレート終了'), true);
assert.equal(v.isTemplateEnd('見出しモードを終了'), true);
assert.equal(v.isTemplateEnd('終了までに'), false);

// ---- 内視鏡の用語パック ----
const sp = require('../dist/shared/specialties.js');
const endoPack = sp.findSpecialty('endoscopy');
assert.equal(endoPack.id, 'endoscopy');
assert.deepEqual(endoPack.readings['胃角部'], ['いかくぶ']);
assert.ok(sp.SPECIALTIES.every((s) => Object.values(s.readings).flat().every((x) => Array.from(x).length >= 4)));

// ---- 診察会話 → SOAP 下書き（話された言葉をそのまま振り分ける）----
const sd = require('../dist/shared/soapDraft.js');
{
  const talk =
    'おはようございます。昨日から頭が痛くて、熱もあります。血圧は130/80、体温は37.5℃です。' +
    '風邪の可能性が高いです。ロキソニン60mgを3日分出します。来週また来てください。お大事に。';
  const d = sd.draftSoap(talk);
  assert.deepEqual(d.s, ['昨日から頭が痛くて、熱もあります。']);
  assert.deepEqual(d.o, ['血圧は130/80、体温は37.5℃です。']);
  assert.deepEqual(d.a, ['風邪の可能性が高いです。']);
  assert.deepEqual(d.p, ['ロキソニン60mgを3日分出します。', '来週また来てください。']);
  // あいさつは落ちるが、それ以外の文字は1つも失われない
  const joined = [...d.s, ...d.o, ...d.a, ...d.p].join('');
  assert.equal(joined, talk.replace('おはようございます。', '').replace('お大事に。', ''));
}
{
  // 1文に別の種類が混ざるときは、読点で分けて振り分ける
  const d = sd.draftSoap('胃炎の疑いです、ガスターを出します。');
  assert.deepEqual(d.a, ['胃炎の疑いです。']);
  assert.deepEqual(d.p, ['ガスターを出します。']);
  // 質問は医師の見立て・計画にしない（患者さんの「インフルエンザですか」を評価にしない）
  const q = sd.draftSoap('インフルエンザですか。');
  assert.deepEqual(q.s, ['インフルエンザですか。']);
  assert.equal(q.a.length, 0);
  // 該当が無い欄は空のまま（診断を作らない）
  const none = sd.draftSoap('お腹が痛いです。');
  assert.equal(none.a.length + none.p.length + none.o.length, 0);
  // 否定・左右はそのまま
  const neg = sd.draftSoap('発熱はありません。右の膝が痛いです。');
  assert.deepEqual(neg.s, ['発熱はありません。', '右の膝が痛いです。']);
  assert.equal(sd.formatSoap({ s: 'a', o: '', a: '', p: 'b\nc' }), 'S) a\nO)\nA)\nP) b\nc');
}

// ---- 入力先アプリごとの動作 ----
const ap = require('../dist/shared/appProfiles.js');
{
  assert.equal(ap.resolveAppBehavior('line').noFinalPeriod, true);
  assert.equal(ap.resolveAppBehavior('slack').noFinalPeriod, false);
  assert.equal(ap.resolveAppBehavior('slack').confirm, false);
  assert.equal(ap.resolveAppBehavior('WindowsTerminal').confirm, true);
  assert.deepEqual(
    [ap.resolveAppBehavior('notepad').noFinalPeriod, ap.resolveAppBehavior('notepad').confirm],
    [false, false]
  );
  assert.equal(ap.resolveAppBehavior('').confirm, false);
  // ユーザー規則が優先。壊れた規則は捨てる
  const rules = ap.sanitizeAppRules([{ match: '^karte', confirm: true, label: '電子カルテ' }, { match: '(' }, 5]);
  assert.equal(rules.length, 1);
  assert.equal(ap.resolveAppBehavior('karte2', rules).label, '電子カルテ');
  assert.equal(ap.resolveAppBehavior('karte2', rules).confirm, true);
  assert.equal(ap.stripFinalPeriod('よろしくお願いします。'), 'よろしくお願いします');
  assert.equal(ap.stripFinalPeriod('いいですか？'), 'いいですか？');
}

// ---- カーソルを動かした先の行頭に句読点を付けない ----
{
  const lm = require('../dist/shared/leadMarks.js');
  // 「〜です」を入力済み(7文字)でカーソルを動かし、続きが「。次の文」になったとき、頭の「。」は入力しない
  assert.equal(lm.stripMarksAt('今日は晴れです。次の文', 7), '今日は晴れです次の文');
  assert.equal(lm.stripMarksAt('今日は晴れです。次の文', 8), '今日は晴れです。次の文'); // 入力済みの範囲は触らない
  assert.equal(lm.stripMarksAt('。、はじめ', 0), 'はじめ');
  assert.equal(lm.stripMarksAt('はじめ', 0), 'はじめ');
  assert.equal(lm.stripMarksAt('はじめ', 99), 'はじめ');
}

// ---- 薬剤名の補正（厚労省 薬価基準収載品目リスト由来） ----
{
  const d = require('../dist/shared/drugMatch.js');
  assert.equal(d.isKnownDrug('ロキソニン'), true);
  assert.equal(d.isKnownDrug('アムロジピン'), true);
  assert.equal(d.nearestDrug('ロキソニン'), 'ロキソニン'); // 合っている語は変えない
  assert.equal(d.nearestDrug('ロキソニ'), 'ロキソニ'); // 4文字以下は触らない
  assert.equal(d.nearestDrug('アムロジビン'), 'アムロジピン'); // 1文字違い
  assert.equal(d.nearestDrug('コミュニケーション'), 'コミュニケーション'); // 普通の語は変えない
  assert.equal(d.nearestDrug('アイスクリーム'), 'アイスクリーム');
  assert.equal(d.nearestDrug('アムロジヒン'), 'アムロジピン'); // 濁点・半濁点の違い
  assert.equal(d.correctDrugNames('アムロジビンを処方'), 'アムロジピンを処方');
  assert.equal(d.nearestDrug('アムロジヒン'), 'アムロジピン'); // 濁点・半濁点の違い
  assert.equal(d.correctDrugNames('アムロジビンを処方', new Set(['アムロジビン'])), 'アムロジビンを処方');
}

// ---- 病名の補正（MEDIS 標準病名マスター由来） ----
{
  const dm = require('../dist/shared/diseaseMatch.js');
  assert.equal(dm.diseaseByReading('きゅうせいいんとうえん'), '急性咽頭炎');
  assert.equal(dm.diseaseByReading('キュウセイイントウエン'), '急性咽頭炎');
  assert.equal(dm.correctDiseaseNames('きゅうせいいんとうえんと診断した'), '急性咽頭炎と診断した');
  assert.equal(dm.correctDiseaseNames('今日はいい天気です'), '今日はいい天気です');
  assert.equal(dm.correctDiseaseNames('急性咽頭炎です'), '急性咽頭炎です');
}

// ---- 用法・検査値の整形 ----
assert.equal(fmt('一日三回毎食後'), '1日3回毎食後');
assert.equal(fmt('七日分処方します'), '7日分処方します');
assert.equal(fmt('一回一錠'), '1回1錠');
assert.equal(fmt('一日中寝ていた'), '一日中寝ていた'); // 普通の文は変えない
assert.equal(fmt('CRP0.3白血球5800ヘモグロビン13.5'), 'CRP0.3、白血球5800、ヘモグロビン13.5');
assert.equal(fmt('CRPは0.3でした'), 'CRPは0.3でした'); // 1項目だけなら変えない

// ---- みんなの辞書・自動学習の安全判定 ----
{
  const vo = require('../dist/shared/vocab.js');
  assert.equal(vo.isKnownMedicalTerm('咽頭発赤'), true);
  assert.equal(vo.isKnownMedicalTerm('ロキソニン'), true);
  assert.equal(vo.isKnownMedicalTerm('急性咽頭炎'), true);
  assert.equal(vo.isKnownMedicalTerm('田中太郎'), false);
  assert.equal(vo.isSafeLearnPair('いんとうほっせき', '咽頭発赤'), true);
  assert.equal(vo.isSafeLearnPair('田中', '田中太郎'), false); // 正が医学用語でなければ覚えない
  assert.equal(vo.isSafeLearnPair('火曜日', '水曜日'), false);
  assert.equal(vo.isSafeLearnPair('ろきそにん60', 'ロキソニン'), false); // 数字を含む誤りは除く
}

// ---- かな漢字変換（医学語彙）----
{
  const ks = require('../dist/shared/kanaSegment.js');
  assert.equal(ks.segmentKana('ヒダリカハイヤシンジュンエイ'), '左下肺野浸潤影');
  assert.equal(ks.convertKanaRuns('ヒダリカハイヤシンジュンエイヲミトメル'), '左下肺野浸潤影を認める');
  assert.equal(ks.convertKanaRuns('みぎじょうはいやにけっせつえいをみとめる'), '右上肺野に結節影を認める');
  assert.equal(ks.convertKanaRuns('キュウセイインとうえん'), 'キュウセイインとうえん'.replace('キュウセイインとうえん', ks.convertKanaRuns('キュウセイインとうえん')));
  assert.equal(ks.convertKanaRuns('コーヒーフィルター'), 'コーヒーフィルター'); // 普通の語は変えない
  assert.equal(ks.convertKanaRuns('ありがとうございます'), 'ありがとうございます');
  assert.equal(ks.convertKanaRuns('今日はいい天気です'), '今日はいい天気です');
  for (const w of ['ありがとうございました','よろしくおねがいします','コミュニケーション','アイスクリーム','インターネット','ミーティング','スケジュール','ハンバーガー','おはようございます','コンピュータ','たいへんおせわになっております','キーボードマウス']) assert.equal(ks.convertKanaRuns(w), w, w);
  ks.setUserReadings([{ from: 'ひなたクリニック', to: '日向クリニック' }]);
  assert.equal(ks.convertKanaRuns('ひなたクリニックです'), 'ひなたクリニックです'); // 全体を説明できなければ変えない
  ks.setUserReadings([]);
}

// ---- IME 単語登録の取り込み ----
{
  const im = require('../dist/shared/imeDict.js');
  const text = '!Microsoft IME Dictionary Tool\n!Version:1.0\nいんとうほっせき\t咽頭発赤\t名詞\nロキソニン\t抗炎症薬\t名詞\nあ\t愛\t名詞\nきおうれき\tきおうれき\t名詞\nだいたい\t\t名詞\n';
  const p = im.parseImeDictionary(text);
  assert.deepEqual(p, [
    { reading: 'いんとうほっせき', word: '咽頭発赤' },
    { reading: 'ろきそにん', word: '抗炎症薬' },
  ]);
  const u16 = Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from('いんとう\t咽頭\t名詞', 'utf16le')]);
  assert.equal(im.decodeImeFile(u16), '\uFEFFいんとう\t咽頭\t名詞'.replace('\uFEFF', ''));
}

// ---- 日付・時刻の入力 ----
{
  assert.deepEqual(v.parseInsertCommand('今日の日付'), { kind: 'date', western: false });
  assert.deepEqual(v.parseInsertCommand('西暦日付'), { kind: 'date', western: true });
  assert.deepEqual(v.parseInsertCommand('日時を入力'), { kind: 'datetime', western: false });
  assert.deepEqual(v.parseInsertCommand('今の時刻'), { kind: 'time', western: false });
  assert.equal(v.parseInsertCommand('今日の日付は晴れです'), null);
  assert.equal(v.parseInsertCommand('時間がかかります'), null);
  const d0 = new Date(2026, 9, 30, 18, 5);
  assert.equal(v.formatInsert({ kind: 'date', western: false }, d0), '令和8年10月30日');
  assert.equal(v.formatInsert({ kind: 'datetime', western: true }, d0), '2026年10月30日 18時05分');
}

// ---- 読点の推測 ----
{
  const { inferCommas } = await import('../dist/shared/punctInfer.js');
  assert.equal(inferCommas('しかし経過は良好です'), 'しかし、経過は良好です');
  assert.equal(inferCommas('昨日から発熱があります。また咳もあります'), '昨日から発熱があります。また、咳もあります');
  assert.equal(inferCommas('痛みますが歩けます'), '痛みますが、歩けます');
  assert.equal(inferCommas('経過を見るため再診します'), '経過を見るため、再診します');
  assert.equal(inferCommas('痛むので受診しました'), '痛むので、受診しました');
  assert.equal(inferCommas('熱が下がらないから来ました'), '熱が下がらないから、来ました');
  // 付けない: 既に句読点がある・文の途中の別の語・文末
  assert.equal(inferCommas('しかし、良好です'), 'しかし、良好です');
  assert.equal(inferCommas('または来週'), 'または来週');
  assert.equal(inferCommas('食べてから来ました'), '食べてから来ました');
  assert.equal(inferCommas('のでしょうか'), 'のでしょうか');
  assert.equal(inferCommas('患者のために'), '患者のために');
  assert.equal(inferCommas('ありがとうございます'), 'ありがとうございます');
  assert.equal(inferCommas('痛みますが'), '痛みますが');
}
// ---- 専門用語フォルダ ----
{
  const { parseTermFile } = await import('../dist/shared/termFile.js');
  const r = parseTermFile(
    '# 説明\n心窩部痛\nしんかぶつう,心窩部痛\nたいじょうほうしん→帯状疱疹\n咽頭発赤、扁桃腫大、白苔\nろきそにん\tロキソニン\t名詞\n12\n。\n'
  );
  assert.deepEqual(r.pairs, [
    { from: 'しんかぶつう', to: '心窩部痛' },
    { from: 'たいじょうほうしん', to: '帯状疱疹' },
    { from: 'ろきそにん', to: 'ロキソニン' },
  ]);
  for (const w of ['心窩部痛', '帯状疱疹', '咽頭発赤', '扁桃腫大', '白苔', 'ロキソニン']) assert.ok(r.terms.includes(w), w);
  assert.ok(!r.terms.includes('12') && !r.terms.includes('#') && !r.terms.includes('。'));
  // 読みが短い行は辞書にしない（普通の文を壊すため）
  assert.deepEqual(parseTermFile('あい,愛').pairs, []);
  // カタカナの用語は、薬剤名と同じように聞き間違いを直せる
  const dm = await import('../dist/shared/drugMatch.js');
  assert.equal(dm.nearestDrug('ゾコーバジン'), 'ゾコーバジン');
  dm.setExtraNames(['ゾコーバダイン']);
  assert.equal(dm.nearestDrug('ゾコーバタイン'), 'ゾコーバダイン');
  dm.setExtraNames([]);
  assert.equal(dm.nearestDrug('ゾコーバタイン'), 'ゾコーバタイン');
}
console.log('voice.test.mjs: OK');
