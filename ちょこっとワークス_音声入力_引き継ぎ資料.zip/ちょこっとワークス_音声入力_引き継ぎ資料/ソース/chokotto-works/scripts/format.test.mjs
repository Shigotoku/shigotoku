// 書式・言い直しの音声コマンド。実行: npm test
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const f = require('../dist/shared/formatCommands.js');
const v = require('../dist/shared/voiceCommands.js');
const p = f.parseFormatCommand;

assert.deepEqual(p('箇条書き'), { kind: 'list-start', style: 'bullet' });
assert.deepEqual(p('箇条書き。'), { kind: 'list-start', style: 'bullet' });
assert.deepEqual(p('番号'), { kind: 'list-start', style: 'number' });
assert.deepEqual(p('箇条書き終わり'), { kind: 'list-end' });
assert.deepEqual(p('番号付き終了'), { kind: 'list-end' });
assert.deepEqual(p('段落'), { kind: 'paragraph' });
// 文章の一部は命令にしない
assert.equal(p('この箇条書きを見てください'), null);
assert.equal(p('番号を教えてください'), null);
// 「次」はリスト中だけ
assert.equal(p('次'), null);
assert.deepEqual(p('次', true), { kind: 'list-next' });
// 言い直し
assert.deepEqual(p('違う、ロキソニンじゃなくてボルタレン'), { kind: 'fix', from: 'ロキソニン', to: 'ボルタレン' });
assert.deepEqual(p('訂正 ロキソニン を ボルタレン に'), { kind: 'fix', from: 'ロキソニン', to: 'ボルタレン' });
assert.equal(p('今日は暑いじゃなくてどうでもいい話'), null);

assert.deepEqual(f.applyFix('ロキソニンを処方。ロキソニン60mg', 'ロキソニン', 'ボルタレン'), {
  text: 'ロキソニンを処方。ボルタレン60mg',
  ok: true,
});
assert.equal(f.applyFix('abc', 'x', 'y').ok, false);
assert.equal(f.listMarker('bullet', 3), '・');
assert.equal(f.listMarker('number', 3), '3. ');
assert.equal(f.stripEmptyMarker('・a\n・', '・'), '・a');
assert.equal(f.stripEmptyMarker('・a', '・'), '・a');
assert.equal(f.applySpokenBrackets('かっこ山田とじ'), '（山田）');
assert.equal(f.applySpokenBrackets('かぎかっこ了解とじ'), '「了解」');
assert.equal(f.applySpokenBrackets('括弧が多い'), '括弧が多い');

// 文を指定した取り消し
assert.equal(v.parseEditCommand('前の文を消して')?.kind, 'undo');
assert.equal(v.parseEditCommand('さっきの文を削除')?.kind, 'undo');
console.log('format.test ok');

// SOAP の「次」で順に進む
const mode = v.matchTemplateStart('SOAP');
assert.ok(mode);
assert.equal(v.matchTemplateStart('OAP')?.id, 'soap');
assert.equal(v.matchTemplateStart('カルテ')?.id, 'soap');
assert.equal(v.isTemplateNext('次'), true);
assert.equal(v.isTemplateNext('はい次'), true);
assert.equal(v.isTemplateNext('次の患者さんは'), false);
assert.equal(v.nextTemplateHeader(mode, 'S)'), 'O)');
assert.equal(v.nextTemplateHeader(mode, 'A)'), 'P)');
assert.equal(v.nextTemplateHeader(mode, 'P)'), null);
console.log('soap flow ok');
