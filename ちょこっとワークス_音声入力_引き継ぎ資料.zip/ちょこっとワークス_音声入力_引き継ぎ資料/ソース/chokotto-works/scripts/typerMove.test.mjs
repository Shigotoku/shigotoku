// ライブ入力: 入力の途中で別の場所へカーソルを動かしたときの試験（実際の Windows には触れない模擬の入力欄で確認する）。
// 守ること:
//  - 動かす前の場所の文字は、動かしたあとに消さない・増やさない
//  - 動かした先に、前の文の終わりの文字や「、。」が入らない／前の文の途中から始まらない
//  - 動かしたあとに終了しても、全文を貼り直したりしない（hasTyped が保たれる）
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { LiveTyper } = require('../dist/main/typer.js');
const { newPartAfter } = require('../dist/shared/leadMarks.js');

// ---- 区切りの規則 ----
assert.equal(newPartAfter('', '。はじめ'), 'はじめ');
assert.equal(newPartAfter('こんにちは', 'こんにちは、よろしく'), 'よろしく');
assert.equal(newPartAfter('こんにちは', 'こんにちは。'), '');
assert.equal(newPartAfter('こんにちわ', 'こんにちは。よろしく'), 'よろしく'); // 末尾が書き換わっても、前の文の「は」が残らない
assert.equal(newPartAfter('今日は天気', '今日は、天気がいい。次です'), 'がいい。次です');
assert.equal(newPartAfter('今日は三', '今日は3回です'), '回です'); // 数字への置き換え
assert.equal(newPartAfter('あいう', 'あ'), ''); // 短くなっても例外にならない
assert.equal(newPartAfter('abc', 'abc'), '');

// ---- 模擬の入力欄 ----
function makeWorld() {
  const w = { fields: [''], cur: 0, pendingClick: false, log: [] };
  w.click = (to) => {
    if (to === undefined) {
      w.fields.push('');
      to = w.fields.length - 1;
    }
    w.cur = to;
    w.pendingClick = true;
  };
  w.request = async (line) => {
    const cmd = line[0];
    const arg = line.slice(1);
    if (cmd === 'E') return 'no';
    if (cmd === 'F') return 'ok:noime:Chrome_RenderWidgetHostHWND:False';
    if (cmd === 'X') {
      if (w.pendingClick) {
        w.pendingClick = false;
        return 'moved';
      }
      const [back, b64] = arg.split('|');
      const add = b64 ? Buffer.from(b64, 'base64').toString('utf8') : '';
      const n = Number(back);
      const chars = Array.from(w.fields[w.cur]);
      assert.ok(n <= chars.length, `消そうとした文字数(${n})が、入力欄の文字数(${chars.length})より多い`);
      w.fields[w.cur] = chars.slice(0, chars.length - n).join('') + add;
      return 'ok';
    }
    return 'ok';
  };
  return w;
}
async function startTyper(w) {
  const lt = new LiveTyper();
  lt.proc = { stdin: { write() {} }, kill() {} };
  lt.ready = true;
  lt.request = (l) => w.request(l);
  assert.equal(await lt.begin(1, 'test'), true);
  return lt;
}
const settle = async (lt, text) => {
  lt.setDesired(text);
  await lt.flush(text);
};

// 1) 動かす前の文が、動かしたあとに句読点で書き換わっても、新しい場所には入らない
{
  const w = makeWorld();
  const lt = await startTyper(w);
  await settle(lt, 'こんにちは');
  w.click();
  await settle(lt, 'こんにちは、よろしく');
  assert.deepEqual(w.fields, ['こんにちは', 'よろしく']);
  await settle(lt, 'こんにちは、よろしくお願いします。');
  assert.deepEqual(w.fields, ['こんにちは', 'よろしくお願いします。']);
  assert.equal(lt.hasTyped, true);
}
// 2) 認識の書き直しで文字数がずれても、前の文の途中から始まらない
{
  const w = makeWorld();
  const lt = await startTyper(w);
  await settle(lt, '今日は天気');
  w.click();
  await settle(lt, '今日は、天気がいい。次です');
  assert.equal(w.fields[0], '今日は天気');
  assert.ok(!/^[。、]/.test(w.fields[1]));
  assert.ok(!w.fields[1].includes('今日'), w.fields[1]);
  assert.ok('今日は、天気がいい。次です'.endsWith(w.fields[1]), w.fields[1]);
}
// 3) 動かしたあと何も話さずに終了: 新しい場所には何も入らず、「入力済み」は保たれる（全文の貼り直しをしない）
{
  const w = makeWorld();
  const lt = await startTyper(w);
  await settle(lt, 'こんにちは');
  w.click();
  const rest = await lt.flush('こんにちは。');
  assert.equal(rest, '');
  assert.deepEqual(w.fields, ['こんにちは', '']);
  assert.equal(lt.hasTyped, true);
}
// 4) 2回動かす。それぞれの場所に、その間に話した分だけが入る
{
  const w = makeWorld();
  const lt = await startTyper(w);
  await settle(lt, 'あ行です');
  w.click();
  await settle(lt, 'あ行です。か行です');
  w.click();
  await settle(lt, 'あ行です。か行です。さ行です。');
  assert.deepEqual(w.fields, ['あ行です', 'か行です', 'さ行です。']);
}
// 5) 動かした先でも、聞き取りの途中結果の書き直しは、その場所の中だけで直す
{
  const w = makeWorld();
  const lt = await startTyper(w);
  await settle(lt, 'おはよう');
  w.click();
  await settle(lt, 'おはようきょうわ');
  await settle(lt, 'おはよう今日は');
  await settle(lt, 'おはよう今日は晴れ');
  assert.deepEqual(w.fields, ['おはよう', '今日は晴れ']);
}
// 6) 以前の場所へ戻って続ける（クリック）。戻った場所の続きに、新しい部分だけが入る
{
  const w = makeWorld();
  const lt = await startTyper(w);
  await settle(lt, 'いち');
  w.click();
  await settle(lt, 'いち、に');
  w.click(0);
  await settle(lt, 'いち、に、さん');
  assert.deepEqual(w.fields, ['いちさん', 'に']);
}
// 7) 入力先から離れている間に話した分は、戻ったあとに入る（前の入力は消さない）
{
  const w = makeWorld();
  const lt = await startTyper(w);
  await settle(lt, 'こんにちは');
  let away = true;
  const orig = w.request;
  w.request = async (l) => (l[0] === 'X' && away ? 'nofocus' : orig(l));
  lt.setDesired('こんにちは、元気です');
  await new Promise((r) => setTimeout(r, 600));
  away = false;
  await lt.flush('こんにちは、元気です。');
  assert.equal(w.fields[0], 'こんにちは元気です。');
}

// ---- 乱数で多数の場面を試す（動かす回数・書き直し・句読点・数字への置き換えを混ぜる）----
let seed = 20261111;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 2 ** 32);
const pick = (a) => a[Math.floor(rnd() * a.length)];
const WORDS = ['今日は', '天気が', 'いいです', '血圧は', '百二十', 'です', '薬を', '出します', 'お大事に', '右の', '胃の', '検査を', '行いました'];
let runs = 0;
for (let n = 0; n < 120; n++) {
  const w = makeWorld();
  const lt = await startTyper(w);
  let text = '';
  const history = []; // 各欄が「動かされた時点の内容」
  const steps = 3 + Math.floor(rnd() * 8);
  for (let i = 0; i < steps; i++) {
    const r = rnd();
    if (r < 0.55) {
      // 話し足す（途中結果の書き直しも混ぜる）
      if (text && rnd() < 0.35) text = Array.from(text).slice(0, -1 - Math.floor(rnd() * 2)).join('');
      text += pick(WORDS);
      if (rnd() < 0.3) text += pick(['、', '。']);
      if (rnd() < 0.15) text = text.replace('百二十', '120');
    } else if (r < 0.7 && text) {
      // すでに話した部分に、句読点が入る
      const arr = Array.from(text);
      const at = 1 + Math.floor(rnd() * Math.max(1, arr.length - 1));
      arr.splice(at, 0, pick(['、', '。']));
      text = arr.join('');
    } else if (r < 0.85 && text) {
      history[w.cur] = w.fields[w.cur];
      w.click();
    }
    await settle(lt, text);
    // 動かす前の場所の内容が、動かしたあとに変わっていない
    for (const [i, v] of Object.entries(history)) if (Number(i) !== w.cur) assert.equal(w.fields[i], v, `欄${i}が変わった (run ${n})`);
  }
  const fin = text + (rnd() < 0.5 ? '。' : '');
  const rest = await lt.flush(fin);
  assert.equal(rest, '', `貼り直しの残りが出た (run ${n})`);
  for (const f of w.fields) {
    assert.ok(!/^[。、，．]/.test(f), `行頭に句読点 (run ${n}): ${JSON.stringify(w.fields)}`);
  }
  const last = w.fields[w.cur];
  if (last) {
    const norm = (s) => s.replace(/[。、，．]/g, '');
    assert.ok(norm(fin).endsWith(norm(last)), `最後の欄が全文の末尾と合わない (run ${n}): ${JSON.stringify(w.fields)} / ${fin}`);
  }
  lt.end();
  runs++;
}
console.log(`typerMove: ok (${runs} runs)`);
