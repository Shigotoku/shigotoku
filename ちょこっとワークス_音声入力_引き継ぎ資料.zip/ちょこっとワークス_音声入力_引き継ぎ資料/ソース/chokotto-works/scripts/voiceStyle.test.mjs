// 音声入力のカルテ文体・SOAP・実行記録の試験（架空の文章・架空のAIだけ。ネットワークは使わない）
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const v = require('../dist/shared/voiceStyle.js');
const r = require('../dist/shared/aiRun.js');

const src = '昨日から咳が出ています。熱はありません。右の胸の音は異常ありません。アムロジピン5ミリグラムを飲んでいます。';

// ---- 守るべきものの検査 ----
assert.deepEqual(v.preservationIssues(src, '昨日より咳あり。発熱なし。右胸部の呼吸音に異常なし。アムロジピン5mg内服中。'), []);
assert.ok(v.preservationIssues(src, '昨日より咳あり。発熱なし。右胸部の呼吸音に異常なし。アムロジピン10mg内服中。').length, '用量の変更を検出');
assert.ok(v.preservationIssues(src, '昨日より咳あり。発熱あり。右胸部の呼吸音に異常あり。アムロジピン5mg内服中。').length, '否定の消失を検出');
assert.ok(v.preservationIssues(src, '昨日より咳あり。発熱なし。左胸部の呼吸音に異常なし。アムロジピン5mg内服中。').length, '左右の入れ替わりを検出');
assert.ok(v.preservationIssues(src, '昨日より咳あり。発熱なし。右胸部の呼吸音に異常なし。ニフェジピン5mg内服中。').length, '薬剤名の変更を検出');
assert.ok(v.preservationIssues('熱は38度です', '発熱38度、39度').length, '数値の増加を検出');
assert.deepEqual(v.preservationIssues('５ミリグラム飲んでいます', '5mg内服'), [], '全角数字・単位の書き換えは許容');

// ---- カルテ文体（架空のAI）----
const good = async () => '昨日より咳あり。発熱なし。右胸部の呼吸音に異常なし。アムロジピン5mg内服中。';
let res = await v.rewriteChart(src, good);
assert.equal(res.ok, true);
assert.match(res.text, /アムロジピン5mg/);

const sys = [];
await v.rewriteChart(src, async (s, u) => (sys.push(s, u), good()));
assert.match(sys[0], /推測しない/);
assert.match(sys[0], /要確認/);
assert.equal(sys[1], src, '送るのは発話そのもの');

// 数値を変えて返したAIは採用しない
res = await v.rewriteChart(src, async () => '昨日より咳あり。発熱なし。右胸部の呼吸音に異常なし。アムロジピン50mg内服中。');
assert.equal(res.ok, false);
assert.match(res.reason, /使いませんでした/);

// 失敗・空・極端な返答は、理由つきで採用しない（例外は外へ出さない）
res = await v.rewriteChart(src, async () => { throw new Error('院内AIサーバーの証明書が、登録された証明書と一致しません'); });
assert.equal(res.ok, false); assert.equal(res.status, 'error'); assert.match(res.reason, /証明書/);
res = await v.rewriteChart(src, async () => '');
assert.equal(res.ok, false);
res = await v.rewriteChart(src, async () => 'あ');
assert.equal(res.ok, false);

// 短い文はAIを呼ばない
let called = false;
res = await v.rewriteChart('はい', async () => ((called = true), 'x'));
assert.equal(res.ok, false); assert.equal(res.status, 'skipped'); assert.equal(called, false);

// コードブロックは取り除く
assert.equal(v.cleanReply('```\n診察\n```'), '診察');

// ---- SOAP: 空の欄は「記載なし」----
assert.equal(
  v.formatSoapWithNone({ s: '咳嗽あり', o: '', a: '  ', p: '経過観察' }),
  'S) 咳嗽あり\nO) 記載なし\nA) 記載なし\nP) 経過観察'
);

// ---- 実行記録（本文は保存しない）----
assert.match(r.describeAiRun(null), /まだ実行されていません/);
r.recordAiRun({ kind: 'plain', status: 'ok', reason: '', ms: 800, changes: 1 });
assert.match(r.describeAiRun(r.lastAiRun()), /通常入力: 成功（1か所を修正・0\.8秒）/);
r.recordAiRun({ kind: 'learn', status: 'error', reason: 'x', ms: 1 });
assert.equal(r.lastAiRun().kind, 'plain', '陰の学習は直近の表示を上書きしない');
r.recordAiRun({ kind: 'chart', status: 'skipped', reason: '短い文のため（8文字未満）', ms: 0 });
assert.match(r.describeAiRun(r.lastAiRun()), /カルテ文体: AIは使いませんでした（短い文のため/);
r.recordAiRun({ kind: 'soap', status: 'error', reason: '数値が変わっているため使いませんでした', ms: 2100 });
assert.match(r.describeAiRun(r.lastAiRun()), /失敗（数値が変わっている.*元の文章のまま/);
r.recordAiRun({ kind: 'plain', status: 'unchanged', reason: '', ms: 900 });
assert.match(r.describeAiRun(r.lastAiRun()), /直す箇所はありませんでした/);
console.log('voiceStyle ok');