import { defineConfig } from 'vite';
import { resolve } from 'path';

export default defineConfig({
  base: './',
  root: '.',
  build: {
    outDir: 'dist/renderer',
    emptyOutDir: true,
    rollupOptions: {
      input: {
        speech: resolve(__dirname, 'index.html'),
        overlay: resolve(__dirname, 'overlay.html'),
        setup: resolve(__dirname, 'setup.html'),
        launcher: resolve(__dirname, 'launcher.html'),
        editor: resolve(__dirname, 'editor.html'),
        correction: resolve(__dirname, 'correction.html'),
        soap: resolve(__dirname, 'soap.html'),
        report: resolve(__dirname, 'report.html'),
        echo: resolve(__dirname, 'echo.html'),
        confirm: resolve(__dirname, 'confirm.html'),
        schedule: resolve(__dirname, 'schedule.html'),
        tasks: resolve(__dirname, 'tasks.html'),
        board: resolve(__dirname, 'board.html'),
        manual: resolve(__dirname, 'manual.html'),
        storage: resolve(__dirname, 'storage.html'),
        google: resolve(__dirname, 'google.html'),
        lan: resolve(__dirname, 'lan.html'),
        deck: resolve(__dirname, 'deck.html'),
        license: resolve(__dirname, 'license.html'),
        boardpopup: resolve(__dirname, 'boardpopup.html'),
        taskpopup: resolve(__dirname, 'taskpopup.html'),
        stock: resolve(__dirname, 'stock.html'),
        pdf: resolve(__dirname, 'pdf.html'),
        pdfmerge: resolve(__dirname, 'pdfmerge.html'),
        pdftools: resolve(__dirname, 'pdftools.html'),
        dock: resolve(__dirname, 'dock.html'),
        home: resolve(__dirname, 'home.html'),
        form: resolve(__dirname, 'form.html'),
      },
    },
  },
  resolve: {
    alias: {
      '@meditoku/speech-common': resolve(__dirname, '../../packages/speech-common/src/index.ts'),
    },
  },
});
