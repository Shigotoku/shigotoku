//#region src/background.ts
var voiceTranscriptFull = "";
var voiceAtLastClick = 0;
var recording = false;
var paused = false;
var recordingWindowId = null;
var steps = [];
var injectingTabs = /* @__PURE__ */ new Set();
function isClipitAppTab(url) {
	try {
		const u = new URL(url);
		if (u.hostname === "app.clipit.shigotoku.com") return true;
		if (u.hostname === "localhost" && (u.port === "5173" || u.port === "5176")) return true;
	} catch {
		return false;
	}
	return false;
}
function isInjectableUrl(url) {
	if (!url) return false;
	if (url.startsWith("chrome://") || url.startsWith("chrome-extension://") || url.startsWith("edge://")) return false;
	if (url.startsWith("about:") || url.startsWith("chrome-search://")) return false;
	if (isClipitAppTab(url)) return false;
	return true;
}
function isRecordingWindow(windowId) {
	return recording && recordingWindowId != null && windowId === recordingWindowId;
}
var CAPTURE_OPTS = {
	format: "jpeg",
	quality: 96
};
/** タブ単位キャプチャ（対応ブラウザ）→ フォールバックでウィンドウキャプチャ。高画質 JPEG */
function captureStepScreenshot(windowId, tabId) {
	return new Promise((resolve) => {
		const fallback = () => {
			chrome.tabs.captureVisibleTab(windowId, CAPTURE_OPTS, (dataUrl) => {
				if (chrome.runtime.lastError || !dataUrl) resolve(void 0);
				else resolve(dataUrl);
			});
		};
		const captureTab = chrome.tabs.captureTab;
		if (typeof captureTab === "function") captureTab(tabId, CAPTURE_OPTS, (dataUrl) => {
			if (chrome.runtime.lastError || !dataUrl) fallback();
			else resolve(dataUrl);
		});
		else fallback();
	});
}
/** SW 再起動で記録中が復元されると全ページへ注入が走りエラーが溜まるため、記録フラグは復元しない */
async function clearStaleRecordingSession() {
	try {
		await chrome.storage.session.remove("clipitRecording");
	} catch {}
	recording = false;
	paused = false;
	recordingWindowId = null;
}
clearStaleRecordingSession();
chrome.runtime.onInstalled.addListener(() => {
	clearStaleRecordingSession();
});
chrome.runtime.onStartup.addListener(() => {
	clearStaleRecordingSession();
});
async function persistRecordingMeta() {
	try {
		if (!recording) {
			await chrome.storage.session.remove("clipitRecording");
			return;
		}
		await chrome.storage.session.set({ clipitRecording: {
			recording: true,
			paused,
			recordingWindowId,
			stepCount: steps.length
		} });
	} catch {}
}
function sleep(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
function tabMessage(tabId, payload) {
	return new Promise((resolve) => {
		chrome.tabs.sendMessage(tabId, payload, () => {
			resolve(!chrome.runtime.lastError);
		});
	});
}
async function notifyRecorderTab(tabId, retries = 4) {
	const payload = {
		type: "CLIPIT_RECORDING_STATE",
		active: true,
		paused,
		stepCount: steps.length
	};
	for (let i = 0; i < retries; i += 1) {
		if (await tabMessage(tabId, payload)) return;
		await sleep(i < 2 ? 120 : 280);
	}
}
async function safeInjectRecorder(tabId) {
	if (injectingTabs.has(tabId)) return;
	injectingTabs.add(tabId);
	try {
		const tab = await chrome.tabs.get(tabId);
		if (!isRecordingWindow(tab.windowId) || !isInjectableUrl(tab.url)) return;
		await chrome.scripting.executeScript({
			target: { tabId },
			files: ["recorder.js"]
		});
		await notifyRecorderTab(tabId);
	} catch {} finally {
		injectingTabs.delete(tabId);
	}
}
async function broadcastRecordingState(active) {
	if (recordingWindowId == null) return;
	try {
		const tabs = await chrome.tabs.query({ windowId: recordingWindowId });
		const msg = active ? {
			type: "CLIPIT_RECORDING_STATE",
			active: true,
			paused,
			stepCount: steps.length
		} : {
			type: "CLIPIT_RECORDING_STATE",
			active: false
		};
		for (const tab of tabs) if (tab.id != null) tabMessage(tab.id, msg);
	} catch {}
}
async function scheduleReinject(tabId, url) {
	if (!recording || !isInjectableUrl(url)) return;
	try {
		if (!isRecordingWindow((await chrome.tabs.get(tabId)).windowId)) return;
		await safeInjectRecorder(tabId);
	} catch {}
}
chrome.tabs.onActivated.addListener((info) => {
	if (!isRecordingWindow(info.windowId)) return;
	safeInjectRecorder(info.tabId);
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
	if (!isRecordingWindow(tab.windowId)) return;
	if (changeInfo.status === "complete" || changeInfo.url && isInjectableUrl(changeInfo.url)) scheduleReinject(tabId, changeInfo.url ?? tab.url);
});
chrome.webNavigation.onCompleted.addListener((details) => {
	if (!recording || details.frameId !== 0) return;
	scheduleReinject(details.tabId, details.url);
});
chrome.webNavigation.onHistoryStateUpdated.addListener((details) => {
	if (!recording || details.frameId !== 0) return;
	scheduleReinject(details.tabId, details.url);
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
	if (msg.type === "CLIPIT_START") {
		recording = true;
		paused = false;
		steps.length = 0;
		voiceTranscriptFull = "";
		voiceAtLastClick = 0;
		chrome.tabs.query({
			active: true,
			currentWindow: true
		}, (queryTabs) => {
			(async () => {
				const tab = queryTabs[0];
				const tabId = tab?.id;
				const windowId = tab?.windowId;
				if (!tabId || windowId == null || !isInjectableUrl(tab?.url)) {
					recording = false;
					recordingWindowId = null;
					sendResponse({
						ok: false,
						message: "記録できないページです。業務サイトのタブを開いてから記録開始してください（クリッピット編集画面では記録できません）。"
					});
					return;
				}
				recordingWindowId = windowId;
				await persistRecordingMeta();
				try {
					await safeInjectRecorder(tabId);
					sendResponse({ ok: true });
				} catch {
					recording = false;
					recordingWindowId = null;
					await persistRecordingMeta();
					sendResponse({
						ok: false,
						message: "記録の開始に失敗しました。ページを再読み込みしてやり直してください。"
					});
				}
			})();
		});
		return true;
	}
	if (msg.type === "CLIPIT_PAUSE") {
		paused = !paused;
		persistRecordingMeta();
		broadcastRecordingState(true);
		sendResponse({
			ok: true,
			paused
		});
		return true;
	}
	if (msg.type === "CLIPIT_STOP") {
		recording = false;
		paused = false;
		const windowId = recordingWindowId;
		recordingWindowId = null;
		persistRecordingMeta();
		if (windowId != null) chrome.tabs.query({ windowId }, (tabs) => {
			for (const t of tabs) if (t.id != null) tabMessage(t.id, {
				type: "CLIPIT_RECORDING_STATE",
				active: false
			});
		});
		finishIngest().then((r) => sendResponse(r));
		return true;
	}
	if (msg.type === "CLIPIT_CLICK" && recording && !paused && isRecordingWindow(sender.tab?.windowId)) {
		const windowId = sender.tab.windowId;
		const tabId = sender.tab.id;
		captureStepScreenshot(windowId, tabId).then((dataUrl) => {
			if (!dataUrl) {
				sendResponse({
					ok: false,
					count: steps.length
				});
				return;
			}
			const isForce = String(msg.step.elementText || "").startsWith("【強制キャプチャ】");
			const voiceSegment = voiceTranscriptFull.slice(voiceAtLastClick).trim();
			voiceAtLastClick = voiceTranscriptFull.length;
			steps.push({
				title: isForce ? `強制キャプチャ ${steps.length + 1}` : `手順 ${steps.length + 1}`,
				elementText: msg.step.elementText,
				elementRole: msg.step.elementRole,
				pageTitle: msg.step.pageTitle,
				pageUrl: msg.step.pageUrl,
				clickX: msg.step.clickX,
				clickY: msg.step.clickY,
				screenshotBase64: dataUrl,
				...voiceSegment ? { voiceSegment } : {}
			});
			persistRecordingMeta();
			tabMessage(tabId, {
				type: "CLIPIT_RECORDING_STATE",
				active: true,
				paused,
				stepCount: steps.length
			});
			sendResponse({
				ok: true,
				count: steps.length
			});
		});
		return true;
	}
	if (msg.type === "CLIPIT_GET_STATUS") {
		sendResponse({
			recording,
			paused,
			stepCount: steps.length,
			windowId: recordingWindowId
		});
		return true;
	}
	if (msg.type === "CLIPIT_VOICE_UPDATE" && recording) {
		if (typeof msg.transcript === "string") {
			voiceTranscriptFull = msg.transcript;
			chrome.storage.local.set({ voiceTranscript: voiceTranscriptFull });
		}
		sendResponse({ ok: true });
		return true;
	}
	return false;
});
chrome.commands.onCommand.addListener((command) => {
	if (command !== "force-capture" || !recording || recordingWindowId == null) return;
	chrome.tabs.query({
		active: true,
		windowId: recordingWindowId
	}, (tabs) => {
		const tabId = tabs[0]?.id;
		if (tabId != null) tabMessage(tabId, { type: "CLIPIT_FORCE_CAPTURE" });
	});
});
async function finishIngest() {
	const { manualId, idToken, apiBase, voiceTranscript, polishVoiceWithAi } = await chrome.storage.local.get([
		"manualId",
		"idToken",
		"apiBase",
		"voiceTranscript",
		"polishVoiceWithAi"
	]);
	if (!manualId || !idToken) return {
		ok: false,
		message: "アプリの編集画面で「拡張と連携」を押してください"
	};
	if (steps.length === 0) return {
		ok: false,
		message: "記録された手順がありません。記録開始したウィンドウ内の業務サイトで操作してください。"
	};
	const base = apiBase || "https://app.clipit.shigotoku.com/api";
	try {
		const res = await fetch(`${base}/v1/manuals/${manualId}/ingest`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${idToken}`
			},
			body: JSON.stringify({
				steps,
				...typeof voiceTranscript === "string" && voiceTranscript.trim() ? { voiceTranscript: voiceTranscript.trim() } : {},
				...polishVoiceWithAi ? { polishWithAi: true } : {}
			})
		});
		const data = await res.json().catch(() => ({}));
		if (!res.ok) return {
			ok: false,
			message: data.error ?? "取り込みに失敗しました"
		};
		const count = data.stepCount ?? steps.length;
		steps.length = 0;
		await chrome.storage.local.remove("voiceTranscript");
		await persistRecordingMeta();
		chrome.tabs.create({ url: `https://app.clipit.shigotoku.com/manuals/${manualId}/edit` });
		return {
			ok: true,
			message: `${count} 手順を取り込みました`
		};
	} catch {
		return {
			ok: false,
			message: "取り込みに失敗しました（ネットワークを確認してください）"
		};
	}
}
//#endregion
