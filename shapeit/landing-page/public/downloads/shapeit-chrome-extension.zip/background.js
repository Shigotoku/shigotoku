//#region src/captureImage.ts
async function cropDataUrl(dataUrl, rect) {
	const dpr = rect.devicePixelRatio || 1;
	const sx = Math.max(0, Math.round(rect.x * dpr));
	const sy = Math.max(0, Math.round(rect.y * dpr));
	const sw = Math.max(1, Math.round(rect.width * dpr));
	const sh = Math.max(1, Math.round(rect.height * dpr));
	const blob = await (await fetch(dataUrl)).blob();
	const bitmap = await createImageBitmap(blob);
	const canvas = new OffscreenCanvas(sw, sh);
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("canvas unavailable");
	ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
	bitmap.close();
	return blobToDataUrl(await canvas.convertToBlob({
		type: "image/jpeg",
		quality: .9
	}));
}
function blobToDataUrl(blob) {
	if (typeof FileReader !== "undefined") return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result));
		reader.onerror = () => reject(reader.error);
		reader.readAsDataURL(blob);
	});
	return blob.arrayBuffer().then((buffer) => {
		const bytes = new Uint8Array(buffer);
		const chunk = 32768;
		let binary = "";
		for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
		return `data:${blob.type || "application/octet-stream"};base64,${btoa(binary)}`;
	});
}
//#endregion
//#region src/shared.ts
var APP_CANDIDATES = [
	"https://app.shapeit.shigotoku.com",
	"https://shigotoku-shapeit-app.web.app",
	"http://localhost:5178",
	"http://127.0.0.1:5178"
];
function isCapturableUrl(url) {
	if (!url) return false;
	if (url.startsWith("chrome://") || url.startsWith("chrome-extension://") || url.startsWith("edge://")) return false;
	return url.startsWith("http://") || url.startsWith("https://");
}
async function getPreferredAppBase() {
	const stored = await chrome.storage.sync.get("shapeitAppBase");
	if (typeof stored.shapeitAppBase === "string" && stored.shapeitAppBase) return stored.shapeitAppBase.replace(/\/$/, "");
	return APP_CANDIDATES[0];
}
async function enqueueReport(report) {
	const key = "shapeitPendingReports";
	const cur = await chrome.storage.local.get(key);
	const list = Array.isArray(cur[key]) ? cur[key] : [];
	list.unshift(report);
	await chrome.storage.local.set({ [key]: list.slice(0, 50) });
}
async function getActiveTabMeta() {
	const [tab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	});
	return {
		tabId: tab?.id,
		windowId: tab?.windowId,
		pageUrl: tab?.url ?? "",
		pageTitle: tab?.title ?? ""
	};
}
function sleep$1(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
/** キャプチャ直前に ShapeIt の UI を隠し、描画が落ち着くまで待つ */
async function prepareTabForCapture(tabId) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			func: () => {
				document.getElementById("shapeit-region-overlay")?.remove();
				document.getElementById("shapeit-element-overlay")?.remove();
				const fab = document.getElementById("shapeit-fab-host");
				if (fab) fab.style.display = "none";
				const overlay = document.getElementById("shapeit-overlay-host");
				if (overlay) overlay.style.display = "none";
			}
		});
	} catch {}
	await sleep$1(150);
}
async function restoreTabAfterCapture(tabId) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			func: () => {
				const fab = document.getElementById("shapeit-fab-host");
				if (fab) fab.style.display = "";
			}
		});
	} catch {}
}
async function captureVisibleTab(windowId) {
	return new Promise((resolve) => {
		chrome.tabs.captureVisibleTab(windowId, {
			format: "jpeg",
			quality: 92
		}, (dataUrl) => {
			if (chrome.runtime.lastError || !dataUrl) resolve(void 0);
			else resolve(dataUrl);
		});
	});
}
async function captureFullOnTab(tabId, windowId) {
	const tab = await chrome.tabs.get(tabId);
	const pageUrl = tab.url ?? "";
	const pageTitle = tab.title ?? "";
	if (!isCapturableUrl(pageUrl)) return {
		pageUrl,
		pageTitle,
		captureMode: "full"
	};
	await prepareTabForCapture(tabId);
	let screenshotDataUrl;
	try {
		screenshotDataUrl = await captureVisibleTab(windowId);
	} finally {
		await restoreTabAfterCapture(tabId);
	}
	return {
		pageUrl,
		pageTitle,
		screenshotDataUrl,
		captureMode: "full"
	};
}
async function captureRegionOnTab(tabId, windowId) {
	const tab = await chrome.tabs.get(tabId);
	const pageUrl = tab.url ?? "";
	const pageTitle = tab.title ?? "";
	if (!isCapturableUrl(pageUrl)) return {
		pageUrl,
		pageTitle,
		captureMode: "region"
	};
	const rect = await requestRegionSelection(tabId);
	if (!rect) return {
		pageUrl,
		pageTitle,
		captureMode: "region"
	};
	await prepareTabForCapture(tabId);
	let fullShot;
	try {
		fullShot = await captureVisibleTab(windowId);
	} finally {
		await restoreTabAfterCapture(tabId);
	}
	if (!fullShot) return {
		pageUrl,
		pageTitle,
		captureMode: "region"
	};
	try {
		return {
			pageUrl,
			pageTitle,
			screenshotDataUrl: await cropDataUrl(fullShot, rect),
			captureMode: "region"
		};
	} catch {
		return {
			pageUrl,
			pageTitle,
			screenshotDataUrl: fullShot,
			captureMode: "region"
		};
	}
}
async function captureElementOnTab(tabId, windowId) {
	const tab = await chrome.tabs.get(tabId);
	const pageUrl = tab.url ?? "";
	const pageTitle = tab.title ?? "";
	if (!isCapturableUrl(pageUrl)) return {
		pageUrl,
		pageTitle,
		captureMode: "element"
	};
	const rect = await requestElementSelection(tabId);
	if (!rect) return {
		pageUrl,
		pageTitle,
		captureMode: "element"
	};
	await prepareTabForCapture(tabId);
	let fullShot;
	try {
		fullShot = await captureVisibleTab(windowId);
	} finally {
		await restoreTabAfterCapture(tabId);
	}
	if (!fullShot) return {
		pageUrl,
		pageTitle,
		captureMode: "element"
	};
	try {
		return {
			pageUrl,
			pageTitle,
			screenshotDataUrl: await cropDataUrl(fullShot, rect),
			captureMode: "element",
			elementSelector: rect.selector,
			elementTag: rect.tagName
		};
	} catch {
		return {
			pageUrl,
			pageTitle,
			screenshotDataUrl: fullShot,
			captureMode: "element",
			elementSelector: rect.selector,
			elementTag: rect.tagName
		};
	}
}
function requestElementSelection(tabId) {
	return new Promise((resolve) => {
		const timeout = globalThis.setTimeout(() => {
			chrome.runtime.onMessage.removeListener(listener);
			resolve(null);
		}, 12e4);
		const listener = (msg, sender) => {
			if (sender.tab?.id !== tabId) return;
			if (msg?.type === "SHAPEIT_ELEMENT_DONE") {
				globalThis.clearTimeout(timeout);
				chrome.runtime.onMessage.removeListener(listener);
				resolve(msg.rect ?? null);
			}
			if (msg?.type === "SHAPEIT_ELEMENT_CANCEL") {
				globalThis.clearTimeout(timeout);
				chrome.runtime.onMessage.removeListener(listener);
				resolve(null);
			}
		};
		chrome.runtime.onMessage.addListener(listener);
		chrome.scripting.executeScript({
			target: { tabId },
			files: ["elementPicker.js"]
		}).catch(() => {
			globalThis.clearTimeout(timeout);
			chrome.runtime.onMessage.removeListener(listener);
			resolve(null);
		});
	});
}
function requestRegionSelection(tabId) {
	return new Promise((resolve) => {
		const timeout = globalThis.setTimeout(() => {
			chrome.runtime.onMessage.removeListener(listener);
			resolve(null);
		}, 12e4);
		const listener = (msg, sender) => {
			if (sender.tab?.id !== tabId) return;
			if (msg?.type === "SHAPEIT_REGION_DONE") {
				globalThis.clearTimeout(timeout);
				chrome.runtime.onMessage.removeListener(listener);
				resolve(msg.rect ?? null);
			}
			if (msg?.type === "SHAPEIT_REGION_CANCEL") {
				globalThis.clearTimeout(timeout);
				chrome.runtime.onMessage.removeListener(listener);
				resolve(null);
			}
		};
		chrome.runtime.onMessage.addListener(listener);
		chrome.scripting.executeScript({
			target: { tabId },
			files: ["captureOverlay.js"]
		}).catch(() => {
			globalThis.clearTimeout(timeout);
			chrome.runtime.onMessage.removeListener(listener);
			resolve(null);
		});
	});
}
//#endregion
//#region src/editorDraft.ts
var SESSION_KEY = "shapeitEditorDraft";
async function saveEditorDraft(draft) {
	await chrome.storage.session.set({ [SESSION_KEY]: draft });
}
//#endregion
//#region src/extensionContext.ts
/** Content script から chrome.* を安全に呼ぶ（再読み込み後の invalidated 対策） */
function extensionAlive() {
	try {
		return Boolean(chrome.runtime?.id);
	} catch {
		return false;
	}
}
function getExtensionVersion() {
	try {
		if (!extensionAlive()) return void 0;
		return chrome.runtime.getManifest().version;
	} catch {
		return;
	}
}
//#endregion
//#region src/submitFeedback.ts
var RECENT_KEY = "shapeitRecentSubmissions";
async function getApiUrl() {
	const stored = await chrome.storage.sync.get(["shapeitApiUrl", "shapeitAppBase"]);
	if (typeof stored.shapeitApiUrl === "string" && stored.shapeitApiUrl) return stored.shapeitApiUrl.replace(/\/$/, "");
	return `${typeof stored.shapeitAppBase === "string" && stored.shapeitAppBase ? stored.shapeitAppBase.replace(/\/$/, "") : "https://app.shapeit.shigotoku.com"}/api`;
}
async function getAppBase() {
	const stored = await chrome.storage.sync.get("shapeitAppBase");
	if (typeof stored.shapeitAppBase === "string" && stored.shapeitAppBase) return stored.shapeitAppBase.replace(/\/$/, "");
	return "https://app.shapeit.shigotoku.com";
}
async function getSession() {
	const stored = await chrome.storage.local.get([
		"shapeitIdToken",
		"shapeitEmail",
		"shapeitDisplayName"
	]);
	return {
		token: typeof stored.shapeitIdToken === "string" ? stored.shapeitIdToken : "",
		email: typeof stored.shapeitEmail === "string" ? stored.shapeitEmail : "",
		displayName: typeof stored.shapeitDisplayName === "string" ? stored.shapeitDisplayName : ""
	};
}
async function saveRecent(payload) {
	const cur = await chrome.storage.local.get(RECENT_KEY);
	const list = Array.isArray(cur[RECENT_KEY]) ? cur[RECENT_KEY] : [];
	list.unshift({
		rawText: payload.rawText,
		pageUrl: payload.pageUrl ?? "",
		pageTitle: payload.pageTitle ?? "",
		submittedAt: (/* @__PURE__ */ new Date()).toISOString()
	});
	await chrome.storage.local.set({ [RECENT_KEY]: list.slice(0, 8) });
}
async function notifySlack(text, pageUrl) {
	const stored = await chrome.storage.sync.get("shapeitSlackWebhook");
	const url = typeof stored.shapeitSlackWebhook === "string" ? stored.shapeitSlackWebhook : "";
	if (!url) return;
	try {
		await fetch(url, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ text: `ShapeIt 新規報告: ${text.slice(0, 120)}${pageUrl ? `\n${pageUrl}` : ""}` })
		});
	} catch {}
}
function showNotification(title, message) {
	try {
		chrome.notifications.create({
			type: "basic",
			iconUrl: "icon.png",
			title,
			message
		});
	} catch {}
}
async function checkDuplicateFeedback(rawText) {
	const session = await getSession();
	if (!session.token || !rawText.trim()) return { duplicates: [] };
	const apiUrl = await getApiUrl();
	try {
		const res = await fetch(`${apiUrl}/v1/feedback/check-duplicates`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${session.token}`
			},
			body: JSON.stringify({ rawText })
		});
		if (!res.ok) return { duplicates: [] };
		const data = await res.json();
		return { duplicates: Array.isArray(data.duplicates) ? data.duplicates : [] };
	} catch {
		return { duplicates: [] };
	}
}
async function submitExtensionFeedback(payload) {
	const session = await getSession();
	if (!session.token) return {
		ok: false,
		error: "auth",
		status: 401
	};
	const apiUrl = await getApiUrl();
	const body = {
		rawText: payload.rawText,
		pageUrl: payload.pageUrl ?? "",
		pageTitle: payload.pageTitle ?? "",
		screenshotDataUrl: payload.screenshotDataUrl,
		source: "chrome_extension",
		authorEmail: payload.authorEmail || session.email || void 0,
		authorDisplayName: payload.authorDisplayName || session.displayName || void 0,
		captureMode: payload.captureMode ?? "none",
		consoleSnippet: payload.consoleSnippet,
		elementSelector: payload.elementSelector,
		elementTag: payload.elementTag,
		extensionVersion: getExtensionVersion(),
		browser: typeof navigator !== "undefined" ? navigator.userAgent : void 0,
		os: typeof navigator !== "undefined" ? navigator.platform : void 0,
		locale: typeof navigator !== "undefined" ? navigator.language : void 0,
		timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
	};
	try {
		const res = await fetch(`${apiUrl}/v1/feedback`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${session.token}`
			},
			body: JSON.stringify(body)
		});
		if (!res.ok) {
			const errBody = await res.json().catch(() => ({}));
			return {
				ok: false,
				error: typeof errBody.error === "string" ? errBody.error : `HTTP ${res.status}`,
				status: res.status
			};
		}
		const data = await res.json().catch(() => ({}));
		await saveRecent(payload);
		notifySlack(payload.rawText, payload.pageUrl);
		showNotification("ShapeIt", "報告を送信しました");
		return {
			ok: true,
			feedbackId: data.id ?? data.feedback?.id
		};
	} catch {
		return {
			ok: false,
			error: "network",
			status: 0
		};
	}
}
async function openInboxTab() {
	const base = await getAppBase();
	await chrome.tabs.create({ url: `${base}/inbox` });
}
//#endregion
//#region src/offlineQueue.ts
var QUEUE_KEY = "shapeitOfflineQueue";
async function enqueueOffline(item) {
	const cur = await chrome.storage.local.get(QUEUE_KEY);
	const list = Array.isArray(cur[QUEUE_KEY]) ? cur[QUEUE_KEY] : [];
	list.unshift({
		...item,
		id: `q_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
		queuedAt: (/* @__PURE__ */ new Date()).toISOString(),
		retries: 0
	});
	await chrome.storage.local.set({ [QUEUE_KEY]: list.slice(0, 30) });
}
async function listOfflineQueue() {
	const cur = await chrome.storage.local.get(QUEUE_KEY);
	return Array.isArray(cur[QUEUE_KEY]) ? cur[QUEUE_KEY] : [];
}
async function removeFromOfflineQueue(id) {
	const list = await listOfflineQueue();
	await chrome.storage.local.set({ [QUEUE_KEY]: list.filter((x) => x.id !== id) });
}
//#endregion
//#region src/background.ts
var SHAPEIT_TAB_URLS = [
	"https://app.shapeit.shigotoku.com/*",
	"https://shigotoku-shapeit-app.web.app/*",
	"http://localhost:5178/*",
	"http://127.0.0.1:5178/*"
];
var EDITOR_URL = chrome.runtime.getURL("editor.html");
var ONBOARDING_URL = chrome.runtime.getURL("onboarding.html");
var TOKEN_STALE_MS = 27e5;
var AUTH_WAIT_MS = 12e3;
var INSTANT_DRAFT_KEY = "shapeitInstantDraft";
function sleep(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
async function hasStoredToken() {
	const token = (await chrome.storage.local.get("shapeitIdToken")).shapeitIdToken;
	return typeof token === "string" && token.length > 0;
}
async function hasFreshToken() {
	const stored = await chrome.storage.local.get(["shapeitIdToken", "shapeitTokenAt"]);
	const token = stored.shapeitIdToken;
	const at = Number(stored.shapeitTokenAt || 0);
	return typeof token === "string" && token.length > 0 && Date.now() - at < TOKEN_STALE_MS;
}
async function waitForStoredToken(maxMs) {
	const start = Date.now();
	while (Date.now() - start < maxMs) {
		if (await hasStoredToken()) return true;
		await sleep(250);
	}
	return false;
}
async function pingShapeitTabs() {
	const tabs = await chrome.tabs.query({ url: SHAPEIT_TAB_URLS });
	for (const tab of tabs) {
		if (!tab.id) continue;
		try {
			await chrome.tabs.sendMessage(tab.id, { type: "SHAPEIT_REFRESH_AUTH" });
		} catch {}
	}
}
async function ensureAuthFromApp() {
	if (await hasFreshToken()) return true;
	await pingShapeitTabs();
	if (await waitForStoredToken(3e3)) return true;
	const base = await getPreferredAppBase();
	let createdTabId;
	try {
		createdTabId = (await chrome.tabs.create({
			url: `${base}/capture?ext=1`,
			active: false
		})).id;
	} catch {
		return false;
	}
	const deadline = Date.now() + AUTH_WAIT_MS;
	while (Date.now() < deadline) {
		if (createdTabId) try {
			await chrome.tabs.sendMessage(createdTabId, { type: "SHAPEIT_REFRESH_AUTH" });
		} catch {}
		if (await hasStoredToken()) break;
		await sleep(400);
	}
	const ok = await hasStoredToken();
	if (createdTabId) try {
		await chrome.tabs.remove(createdTabId);
	} catch {}
	return ok;
}
async function resolveTab(tabHint) {
	let tabId = tabHint?.tabId;
	let windowId = tabHint?.windowId;
	if (!tabId || !windowId) {
		const [tab] = await chrome.tabs.query({
			active: true,
			currentWindow: true
		});
		if (!tabId) tabId = tab?.id;
		if (!windowId) windowId = tab?.windowId;
	}
	if (tabId && !windowId) try {
		windowId = (await chrome.tabs.get(tabId)).windowId;
	} catch {}
	return {
		tabId,
		windowId
	};
}
async function focusTab(tabId, windowId) {
	try {
		await chrome.tabs.update(tabId, { active: true });
		await chrome.windows.update(windowId, { focused: true });
	} catch {}
}
async function showInstantOverlayOnTab(tabId, payload) {
	await chrome.storage.session.set({ [INSTANT_DRAFT_KEY]: payload });
	try {
		await chrome.tabs.sendMessage(tabId, {
			type: "SHAPEIT_SHOW_INSTANT_OVERLAY",
			payload
		});
		return true;
	} catch {
		try {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: ["pageReporter.js"]
			});
			await sleep(200);
			await chrome.tabs.sendMessage(tabId, {
				type: "SHAPEIT_SHOW_INSTANT_OVERLAY",
				payload
			});
			return true;
		} catch {
			return false;
		}
	}
}
async function startFullReport(tabHint) {
	if (!await ensureAuthFromApp()) return {
		ok: false,
		error: "auth"
	};
	const { tabId, windowId } = await resolveTab(tabHint);
	if (!tabId || !windowId) return {
		ok: false,
		error: "active tab not found"
	};
	await focusTab(tabId, windowId);
	const cap = await captureFullOnTab(tabId, windowId);
	if (!cap?.screenshotDataUrl) return {
		ok: false,
		error: "capture failed"
	};
	return await showInstantOverlayOnTab(tabId, {
		screenshotDataUrl: cap.screenshotDataUrl,
		pageUrl: cap.pageUrl,
		pageTitle: cap.pageTitle,
		captureMode: "full"
	}) ? { ok: true } : {
		ok: false,
		error: "overlay failed"
	};
}
async function startInstantReport(tabHint) {
	if (!await ensureAuthFromApp()) return {
		ok: false,
		error: "auth"
	};
	const { tabId, windowId } = await resolveTab(tabHint);
	if (!tabId || !windowId) return {
		ok: false,
		error: "active tab not found"
	};
	await focusTab(tabId, windowId);
	const cap = await captureRegionOnTab(tabId, windowId);
	if (!cap?.screenshotDataUrl) return {
		ok: false,
		error: "cancelled"
	};
	return await showInstantOverlayOnTab(tabId, {
		screenshotDataUrl: cap.screenshotDataUrl,
		pageUrl: cap.pageUrl,
		pageTitle: cap.pageTitle,
		captureMode: "region"
	}) ? { ok: true } : {
		ok: false,
		error: "overlay failed"
	};
}
async function startCommentOnly(tabHint) {
	if (!await ensureAuthFromApp()) return {
		ok: false,
		error: "auth"
	};
	const { tabId } = await resolveTab(tabHint);
	if (!tabId) return {
		ok: false,
		error: "active tab not found"
	};
	const tab = await chrome.tabs.get(tabId).catch(() => null);
	return await showInstantOverlayOnTab(tabId, {
		commentOnly: true,
		pageUrl: tab?.url ?? "",
		pageTitle: tab?.title ?? "",
		captureMode: "none"
	}) ? { ok: true } : {
		ok: false,
		error: "overlay failed"
	};
}
async function startElementReport(tabHint) {
	if (!await ensureAuthFromApp()) return {
		ok: false,
		error: "auth"
	};
	const { tabId, windowId } = await resolveTab(tabHint);
	if (!tabId || !windowId) return {
		ok: false,
		error: "active tab not found"
	};
	await focusTab(tabId, windowId);
	const cap = await captureElementOnTab(tabId, windowId);
	if (!cap?.screenshotDataUrl) return {
		ok: false,
		error: "cancelled"
	};
	return await showInstantOverlayOnTab(tabId, {
		screenshotDataUrl: cap.screenshotDataUrl,
		pageUrl: cap.pageUrl,
		pageTitle: cap.pageTitle,
		captureMode: "element",
		elementSelector: cap.elementSelector,
		elementTag: cap.elementTag
	}) ? { ok: true } : {
		ok: false,
		error: "overlay failed"
	};
}
async function captureForEditor(mode, tabHint) {
	if (!await ensureAuthFromApp()) return {
		ok: false,
		error: "auth"
	};
	const { tabId, windowId } = await resolveTab(tabHint);
	if (!tabId || !windowId) return {
		ok: false,
		error: "active tab not found"
	};
	await focusTab(tabId, windowId);
	const cap = mode === "full" ? await captureFullOnTab(tabId, windowId) : await captureRegionOnTab(tabId, windowId);
	if (!cap) return {
		ok: false,
		error: "cancelled"
	};
	if (mode === "region" && !cap.screenshotDataUrl) return {
		ok: false,
		error: "cancelled"
	};
	await saveEditorDraft({
		pageUrl: cap.pageUrl,
		pageTitle: cap.pageTitle,
		screenshotDataUrl: cap.screenshotDataUrl,
		captureMode: cap.captureMode === "element" ? "region" : cap.captureMode,
		sourceTabId: tabId,
		sourceWindowId: windowId,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	});
	return { ok: true };
}
async function openEditorWindow() {
	const existing = (await chrome.windows.getAll({
		populate: true,
		windowTypes: ["popup"]
	})).find((w) => w.tabs?.some((t) => t.url === EDITOR_URL));
	if (existing?.id) {
		await chrome.windows.update(existing.id, { focused: true });
		return;
	}
	await chrome.windows.create({
		url: EDITOR_URL,
		type: "popup",
		width: 860,
		height: 780,
		focused: true
	});
}
async function startAnnotateReport(tabHint) {
	if (!await ensureAuthFromApp()) return {
		ok: false,
		error: "auth"
	};
	const { tabId, windowId } = await resolveTab(tabHint);
	if (!tabId || !windowId) return {
		ok: false,
		error: "active tab not found"
	};
	await focusTab(tabId, windowId);
	const cap = await captureRegionOnTab(tabId, windowId);
	if (!cap) return {
		ok: false,
		error: "cancelled"
	};
	await saveEditorDraft({
		pageUrl: cap.pageUrl,
		pageTitle: cap.pageTitle,
		screenshotDataUrl: cap.screenshotDataUrl,
		captureMode: "region",
		sourceTabId: tabId,
		sourceWindowId: windowId,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	});
	await openEditorWindow();
	return { ok: true };
}
async function openNoteEditor(tabHint) {
	const { tabId, windowId } = await resolveTab(tabHint);
	const tab = tabId ? await chrome.tabs.get(tabId).catch(() => null) : null;
	await saveEditorDraft({
		pageUrl: tab?.url ?? "",
		pageTitle: tab?.title ?? "",
		captureMode: "none",
		sourceTabId: tabId,
		sourceWindowId: windowId,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	});
	await openEditorWindow();
	return { ok: true };
}
async function submitWithOfflineFallback(payload) {
	const res = await submitExtensionFeedback(payload);
	if (res.ok) return res;
	if (res.status === 0 || res.status === 503) {
		await enqueueOffline(payload);
		return {
			ok: true,
			queued: true
		};
	}
	return res;
}
async function flushOfflineQueue() {
	const queue = await listOfflineQueue();
	for (const item of queue) {
		const { id, queuedAt: _q, retries: _r, ...payload } = item;
		if ((await submitExtensionFeedback(payload)).ok) await removeFromOfflineQueue(id);
	}
}
chrome.runtime.onInstalled.addListener((details) => {
	if (details.reason === "install") {
		chrome.tabs.create({ url: ONBOARDING_URL });
		return;
	}
	if (details.reason === "update") chrome.tabs.query({ url: SHAPEIT_TAB_URLS }).then((tabs) => {
		for (const tab of tabs) if (tab.id) chrome.tabs.reload(tab.id).catch(() => {});
	});
});
chrome.alarms.onAlarm.addListener((alarm) => {
	if (alarm.name === "shapeit-flush-queue") flushOfflineQueue();
});
chrome.runtime.onStartup.addListener(() => {
	chrome.alarms.create("shapeit-flush-queue", { periodInMinutes: 5 });
	flushOfflineQueue();
});
chrome.commands.onCommand.addListener(async (command) => {
	try {
		if (command === "full-report") {
			await startFullReport();
			return;
		}
		if (command === "region-report" || command === "instant-report") {
			await startInstantReport();
			return;
		}
		if (command === "comment-report") {
			await startCommentOnly();
			return;
		}
		if (command === "annotate-report") {
			await startAnnotateReport();
			return;
		}
	} catch {
		const base = await getPreferredAppBase();
		await chrome.tabs.create({ url: `${base}/capture?ext=1&focus=1` });
	}
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
	if (msg?.type === "SHAPEIT_ENSURE_AUTH" || msg?.type === "SHAPEIT_REFRESH_AUTH") {
		ensureAuthFromApp().then((ok) => sendResponse({ ok }));
		return true;
	}
	if (msg?.type === "SHAPEIT_START_FULL") {
		startFullReport().then((res) => sendResponse(res));
		return true;
	}
	if (msg?.type === "SHAPEIT_START_COMMENT") {
		startCommentOnly().then((res) => sendResponse(res));
		return true;
	}
	if (msg?.type === "SHAPEIT_START_INSTANT") {
		startInstantReport().then((res) => sendResponse(res));
		return true;
	}
	if (msg?.type === "SHAPEIT_START_ELEMENT") {
		startElementReport().then((res) => sendResponse(res));
		return true;
	}
	if (msg?.type === "SHAPEIT_START_ANNOTATE") {
		startAnnotateReport().then((res) => sendResponse(res));
		return true;
	}
	if (msg?.type === "SHAPEIT_ENQUEUE") {
		enqueueReport(msg.report).then(() => sendResponse({ ok: true }));
		return true;
	}
	if (msg?.type === "SHAPEIT_START_CAPTURE") {
		const openEditor = msg.openEditor !== false;
		const mode = msg.mode === "full" ? "full" : "region";
		const tabHint = typeof msg.tabId === "number" ? {
			tabId: Number(msg.tabId),
			windowId: typeof msg.windowId === "number" ? Number(msg.windowId) : void 0
		} : void 0;
		if (openEditor) startAnnotateReport(tabHint).then((res) => sendResponse(res));
		else captureForEditor(mode, tabHint).then((res) => sendResponse(res));
		return true;
	}
	if (msg?.type === "SHAPEIT_OPEN_EDITOR") {
		openEditorWindow().then(() => sendResponse({ ok: true }));
		return true;
	}
	if (msg?.type === "SHAPEIT_OPEN_NOTE_EDITOR") {
		openNoteEditor(typeof msg.tabId === "number" ? {
			tabId: Number(msg.tabId),
			windowId: typeof msg.windowId === "number" ? Number(msg.windowId) : void 0
		} : void 0).then((res) => sendResponse(res));
		return true;
	}
	if (msg?.type === "SHAPEIT_CHECK_DUPLICATES") {
		checkDuplicateFeedback(String(msg.rawText ?? "")).then((res) => sendResponse(res));
		return true;
	}
	if (msg?.type === "SHAPEIT_SUBMIT_FEEDBACK") {
		submitWithOfflineFallback({
			rawText: String(msg.rawText ?? ""),
			pageUrl: typeof msg.pageUrl === "string" ? msg.pageUrl : "",
			pageTitle: typeof msg.pageTitle === "string" ? msg.pageTitle : "",
			screenshotDataUrl: typeof msg.screenshotDataUrl === "string" ? msg.screenshotDataUrl : void 0,
			captureMode: typeof msg.captureMode === "string" ? msg.captureMode : "none",
			consoleSnippet: typeof msg.consoleSnippet === "string" ? msg.consoleSnippet : void 0,
			elementSelector: typeof msg.elementSelector === "string" ? msg.elementSelector : void 0,
			elementTag: typeof msg.elementTag === "string" ? msg.elementTag : void 0
		}).then((res) => sendResponse(res));
		return true;
	}
	if (msg?.type === "SHAPEIT_OPEN_INBOX") {
		openInboxTab().then(() => sendResponse({ ok: true }));
		return true;
	}
	if (msg?.type === "SHAPEIT_GET_TAB_META") {
		getActiveTabMeta().then((meta) => sendResponse({
			ok: true,
			meta
		}));
		return true;
	}
	if (msg?.type === "SHAPEIT_GET_PENDING") {
		chrome.storage.local.get("shapeitPendingReports").then((data) => {
			sendResponse({
				ok: true,
				reports: data.shapeitPendingReports ?? []
			});
		});
		return true;
	}
	if (msg?.type === "SHAPEIT_CLEAR_PENDING") {
		const ids = Array.isArray(msg.ids) ? msg.ids : [];
		chrome.storage.local.get("shapeitPendingReports").then(async (data) => {
			const next = (Array.isArray(data.shapeitPendingReports) ? data.shapeitPendingReports : []).filter((r) => !ids.includes(r.id));
			await chrome.storage.local.set({ shapeitPendingReports: next });
			sendResponse({ ok: true });
		});
		return true;
	}
	if (msg?.type === "SHAPEIT_REGION_DONE" || msg?.type === "SHAPEIT_REGION_CANCEL" || msg?.type === "SHAPEIT_ELEMENT_DONE" || msg?.type === "SHAPEIT_ELEMENT_CANCEL") return false;
	return false;
});
chrome.alarms.create("shapeit-flush-queue", { periodInMinutes: 5 });
//#endregion
