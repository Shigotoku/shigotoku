(() => {
  // src/extensionContext.ts
  function extensionAlive() {
    try {
      return Boolean(chrome.runtime?.id);
    } catch {
      return false;
    }
  }
  function sendRuntimeMessage(message) {
    return new Promise((resolve) => {
      if (!extensionAlive()) {
        resolve(void 0);
        return;
      }
      try {
        chrome.runtime.sendMessage(message, (res) => {
          void chrome.runtime.lastError;
          resolve(res);
        });
      } catch {
        resolve(void 0);
      }
    });
  }

  // src/pageReporter.ts
  var consoleBuffer = [];
  function hookConsole() {
    if (window.__shapeitConsole) return;
    window.__shapeitConsole = true;
    const push = (level, args) => {
      const line = `[${level}] ${args.map((a) => {
        try {
          return typeof a === "object" ? JSON.stringify(a) : String(a);
        } catch {
          return String(a);
        }
      }).join(" ").slice(0, 240)}`;
      consoleBuffer.push(line);
      if (consoleBuffer.length > 25) consoleBuffer.shift();
    };
    const origError = console.error.bind(console);
    const origWarn = console.warn.bind(console);
    console.error = (...args) => {
      push("error", args);
      origError(...args);
    };
    console.warn = (...args) => {
      push("warn", args);
      origWarn(...args);
    };
    window.addEventListener("error", (e) => {
      if (e.message) consoleBuffer.push(`[error] ${e.message}`.slice(0, 240));
    });
    window.addEventListener("unhandledrejection", (e) => {
      consoleBuffer.push(`[promise] ${String(e.reason)}`.slice(0, 240));
    });
  }
  hookConsole();
  var fabRoot = null;
  var overlayRoot = null;
  var speechRec = null;
  var speechWanted = false;
  function isCapturablePage() {
    const u = location.href;
    return u.startsWith("http://") || u.startsWith("https://");
  }
  function isShapeitAppPage() {
    try {
      const host = location.hostname;
      if (host === "app.shapeit.shigotoku.com") return true;
      if (host === "shigotoku-shapeit-app.web.app") return true;
      if ((host === "localhost" || host === "127.0.0.1") && location.port === "5178") return true;
    } catch {
    }
    return false;
  }
  function injectStyles(shadow) {
    const style = document.createElement("style");
    style.textContent = `
    * { box-sizing: border-box; font-family: "Segoe UI","Noto Sans JP",system-ui,sans-serif; }
    .fab {
      position: fixed; right: 18px; bottom: 18px; z-index: 2147483640;
      width: 52px; height: 52px; border-radius: 999px; border: none; cursor: pointer;
      background: #1f9d8a; color: #fff; box-shadow: 0 8px 24px rgba(31,157,138,.45);
      display: flex; align-items: center; justify-content: center;
    }
    .fab:hover { background: #188f7d; }
    .fab svg { width: 24px; height: 24px; fill: currentColor; }
    .menu {
      position: fixed; right: 18px; bottom: 78px; z-index: 2147483640;
      background: #fff; border-radius: 12px; box-shadow: 0 12px 40px rgba(11,19,32,.2);
      padding: 6px; min-width: 200px; display: none;
    }
    .menu.open { display: block; }
    .menu button {
      display: block; width: 100%; text-align: left; border: none; background: transparent;
      padding: 10px 12px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; color: #0b1320;
    }
    .menu button:hover { background: #f3f6f4; }
    .menu .sub { font-size: 10px; color: #5b6b7c; font-weight: 400; display: block; margin-top: 2px; }
    .overlay {
      position: fixed; inset: 0; z-index: 2147483645;
      background: rgba(11,19,32,.55); display: flex; align-items: center; justify-content: center; padding: 16px;
    }
    .card {
      background: #fff; border-radius: 16px; width: min(440px, 100%); padding: 20px;
      box-shadow: 0 24px 60px rgba(11,19,32,.25);
    }
    .card h2 { margin: 0 0 4px; font-size: 18px; }
    .card .sub { margin: 0 0 14px; font-size: 12px; color: #5b6b7c; }
    .thumb { width: 100%; max-height: 120px; object-fit: contain; border-radius: 8px; border: 1px solid #e5ebe8; background: #f3f6f4; margin-bottom: 12px; }
    textarea {
      width: 100%; min-height: 80px; border: 1px solid #c9d5ce; border-radius: 10px;
      padding: 10px 12px; font-size: 14px; resize: vertical; outline: none;
    }
    textarea:focus { border-color: #1f9d8a; }
    .row { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }
    .btn {
      border-radius: 10px; padding: 10px 14px; font-size: 13px; font-weight: 700; cursor: pointer; border: none;
    }
    .btn-primary { background: #1f9d8a; color: #fff; flex: 1; }
    .btn-primary:hover { background: #188f7d; }
    .btn-secondary { background: #fff; color: #0b1320; border: 1px solid #c9d5ce; }
    .btn-mic { background: #f3f6f4; color: #0b1320; border: 1px solid #c9d5ce; }
    .btn-mic.active { background: #e8f6f2; border-color: #1f9d8a; color: #1f9d8a; animation: pulse 1.2s infinite; }
    .warn { margin-top: 10px; padding: 8px 10px; background: #fffbeb; border-radius: 8px; font-size: 11px; color: #92400e; }
    .success { text-align: center; padding: 12px 0; }
    .success .check { width: 64px; height: 64px; line-height: 64px; border-radius: 999px; background: #1f9d8a; color: #fff; font-size: 32px; margin: 0 auto 12px; }
  `;
    shadow.append(style);
  }
  function setFabVisible(visible) {
    if (fabRoot) fabRoot.style.display = visible ? "" : "none";
  }
  function showFabToast(message) {
    const toast = document.createElement("div");
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      right: "18px",
      bottom: "84px",
      zIndex: "2147483641",
      maxWidth: "280px",
      padding: "10px 14px",
      borderRadius: "10px",
      background: "#0b1320",
      color: "#fff",
      fontSize: "12px",
      lineHeight: "1.5",
      boxShadow: "0 8px 24px rgba(11,19,32,.35)",
      fontFamily: '"Segoe UI","Noto Sans JP",system-ui,sans-serif'
    });
    document.documentElement.append(toast);
    globalThis.setTimeout(() => toast.remove(), 3200);
  }
  async function hideFab() {
    if (!extensionAlive()) return;
    await chrome.storage.sync.set({ shapeitFabHidden: true });
    setFabVisible(false);
    showFabToast("\u30D5\u30ED\u30FC\u30C6\u30A3\u30F3\u30B0\u30DC\u30BF\u30F3\u3092\u975E\u8868\u793A\u306B\u3057\u307E\u3057\u305F\u3002\u62E1\u5F35\u30A2\u30A4\u30B3\u30F3 \u2192\u300C\u53F3\u4E0B\u30DC\u30BF\u30F3\u3092\u8868\u793A\u300D\u3067\u623B\u305B\u307E\u3059\u3002");
  }
  function createFab() {
    if (!isCapturablePage() || isShapeitAppPage() || fabRoot) return;
    fabRoot = document.createElement("div");
    fabRoot.id = "shapeit-fab-host";
    const shadow = fabRoot.attachShadow({ mode: "closed" });
    injectStyles(shadow);
    const menu = document.createElement("div");
    menu.className = "menu";
    menu.innerHTML = `
    <button type="button" data-action="full">\u5168\u753B\u9762\u3092\u64AE\u3063\u3066\u8A71\u3059<span class="sub">Alt+Shift+G</span></button>
    <button type="button" data-action="instant">\u7BC4\u56F2\u3092\u9078\u3093\u3067\u8A71\u3059<span class="sub">Alt+Shift+R</span></button>
    <button type="button" data-action="element">\u8981\u7D20\u3092\u6307\u5B9A\u3057\u3066\u5831\u544A<span class="sub">Marker.io \u578B</span></button>
    <button type="button" data-action="annotate">\u7BC4\u56F2\u3092\u9078\u3093\u3067\u8A73\u3057\u304F\u7DE8\u96C6<span class="sub">Alt+Shift+A</span></button>
    <button type="button" data-action="comment">\u30B3\u30E1\u30F3\u30C8\u3060\u3051\u9001\u308B<span class="sub">Alt+Shift+N</span></button>
    <button type="button" data-action="hide-fab" style="color:#5b6b7c;font-weight:500">\u30DC\u30BF\u30F3\u3092\u975E\u8868\u793A\u306B\u3059\u308B</button>
  `;
    const fab = document.createElement("button");
    fab.type = "button";
    fab.className = "fab";
    fab.title = "ShapeIt \u306B\u5831\u544A\uFF08\u53F3\u30AF\u30EA\u30C3\u30AF\u3067\u975E\u8868\u793A\uFF09";
    fab.innerHTML = '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2Zm1 15h-2v-6h2Zm0-8h-2V7h2Z"/></svg>';
    fab.addEventListener("click", (e) => {
      e.stopPropagation();
      menu.classList.toggle("open");
    });
    fab.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      e.stopPropagation();
      menu.classList.remove("open");
      void hideFab();
    });
    menu.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-action]");
      if (!btn) return;
      menu.classList.remove("open");
      const action = btn.getAttribute("data-action");
      if (action === "hide-fab") {
        void hideFab();
        return;
      }
      if (action === "full") void sendRuntimeMessage({ type: "SHAPEIT_START_FULL" });
      if (action === "instant") void sendRuntimeMessage({ type: "SHAPEIT_START_INSTANT" });
      if (action === "element") void sendRuntimeMessage({ type: "SHAPEIT_START_ELEMENT" });
      if (action === "annotate") void sendRuntimeMessage({ type: "SHAPEIT_START_ANNOTATE" });
      if (action === "comment") void sendRuntimeMessage({ type: "SHAPEIT_START_COMMENT" });
    });
    document.addEventListener("click", () => menu.classList.remove("open"));
    shadow.append(menu, fab);
    document.documentElement.append(fabRoot);
    if (extensionAlive()) {
      void chrome.storage.sync.get("shapeitFabHidden").then((s) => {
        if (s.shapeitFabHidden) setFabVisible(false);
      }).catch(() => {
      });
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "sync" || !changes.shapeitFabHidden) return;
        setFabVisible(!changes.shapeitFabHidden.newValue);
      });
    }
  }
  function stopSpeech() {
    speechWanted = false;
    if (speechRec) {
      try {
        speechRec.stop();
      } catch {
      }
      speechRec = null;
    }
  }
  function startSpeech(textarea, micBtn) {
    const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Ctor) return;
    if (speechRec || speechWanted) {
      stopSpeech();
      micBtn.classList.remove("active");
      return;
    }
    speechWanted = true;
    let base = textarea.value.trim();
    const beginRecognition = () => {
      if (!speechWanted) return;
      const rec = new Ctor();
      rec.lang = "ja-JP";
      rec.continuous = true;
      rec.interimResults = true;
      rec.onresult = (ev) => {
        let finalChunk = "";
        let interim = "";
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          const t = ev.results[i][0]?.transcript ?? "";
          if (ev.results[i].isFinal) finalChunk += t;
          else interim += t;
        }
        if (interim) textarea.value = base ? `${base}${interim}` : interim;
        if (finalChunk) {
          base = base ? `${base}${finalChunk}` : finalChunk;
          textarea.value = base;
        }
      };
      rec.onerror = (ev) => {
        if (ev.error === "aborted" || !speechWanted) return;
        micBtn.classList.remove("active");
        speechWanted = false;
        speechRec = null;
      };
      rec.onend = () => {
        speechRec = null;
        if (speechWanted) {
          globalThis.setTimeout(() => beginRecognition(), 120);
          return;
        }
        micBtn.classList.remove("active");
      };
      try {
        rec.start();
        speechRec = rec;
        micBtn.classList.add("active");
      } catch {
        speechWanted = false;
        micBtn.classList.remove("active");
      }
    };
    beginRecognition();
  }
  function showInstantOverlay(payload) {
    closeOverlay();
    stopSpeech();
    overlayRoot = document.createElement("div");
    overlayRoot.id = "shapeit-overlay-host";
    const shadow = overlayRoot.attachShadow({ mode: "closed" });
    injectStyles(shadow);
    const wrap = document.createElement("div");
    wrap.className = "overlay";
    const card = document.createElement("div");
    card.className = "card";
    let step = "input";
    let dupWarning = "";
    card.innerHTML = `
    <h2>${payload.commentOnly ? "\u30B3\u30E1\u30F3\u30C8\u3092\u9001\u308B" : "\u6C17\u3065\u304D\u3092\u8A71\u3059"}</h2>
    <p class="sub">${payload.commentOnly ? "\u97F3\u58F0\u307E\u305F\u306F\u6587\u5B57\u3067\u5165\u529B \xB7 \u8A71\u3057\u7D42\u308F\u3063\u305F\u3089\u300C\u6B21\u3078\u300D" : "\u7BC4\u56F2\u9078\u629E\u6E08\u307F \xB7 \u8A71\u3059\u3068\u6587\u5B57\u306B\u306A\u308A\u307E\u3059 \xB7 \u7D42\u308F\u3063\u305F\u3089\u300C\u6B21\u3078\u300D"}</p>
    ${payload.screenshotDataUrl ? `<img class="thumb" src="${payload.screenshotDataUrl}" alt="" />` : ""}
    <textarea id="note" placeholder="\u8A71\u3059\u304B\u3001\u3053\u3053\u306B\u5165\u529B\u2026">${payload.recentText ?? ""}</textarea>
    <div class="row" id="inputActions">
      <button type="button" class="btn btn-mic" id="micBtn">\u{1F3A4} \u97F3\u58F0</button>
      <button type="button" class="btn btn-primary" id="nextBtn">\u6B21\u3078</button>
      <button type="button" class="btn btn-secondary" id="cancelBtn">\u30AD\u30E3\u30F3\u30BB\u30EB</button>
    </div>
    <div id="dupArea"></div>
  `;
    wrap.append(card);
    shadow.append(wrap);
    document.documentElement.append(overlayRoot);
    const textarea = card.querySelector("#note");
    const micBtn = card.querySelector("#micBtn");
    const nextBtn = card.querySelector("#nextBtn");
    const cancelBtn = card.querySelector("#cancelBtn");
    const dupArea = card.querySelector("#dupArea");
    const inputActions = card.querySelector("#inputActions");
    const goConfirm = async () => {
      const text = textarea.value.trim();
      if (!text) {
        textarea.focus();
        return;
      }
      stopSpeech();
      step = "confirm";
      const dupRes = await sendRuntimeMessage({
        type: "SHAPEIT_CHECK_DUPLICATES",
        rawText: text
      });
      if (dupRes?.duplicates?.length) {
        dupWarning = dupRes.duplicates.slice(0, 2).map((d) => `\u30FB${d.title}\uFF08\u985E\u4F3C ${Math.round(d.score * 100)}%\uFF09`).join("<br>");
        dupArea.innerHTML = `<div class="warn">\u4F3C\u305F\u5831\u544A\u304C\u3042\u308A\u307E\u3059:<br>${dupWarning}<br>\u3053\u306E\u307E\u307E\u9001\u4FE1\u3067\u304D\u307E\u3059\u3002</div>`;
      }
      card.querySelector("h2").textContent = "\u9001\u4FE1\u3057\u307E\u3059\u304B\uFF1F";
      card.querySelector(".sub").textContent = "Enter \u3067\u9001\u4FE1 \xB7 Esc \u3067\u623B\u308B";
      inputActions.innerHTML = `
      <button type="button" class="btn btn-primary" id="sendBtn">\u9001\u4FE1\u3059\u308B</button>
      <button type="button" class="btn btn-secondary" id="backBtn">\u623B\u308B</button>
    `;
      card.querySelector("#sendBtn").addEventListener("click", () => void doSend());
      card.querySelector("#backBtn").addEventListener("click", () => location.reload());
    };
    const doSend = async () => {
      const text = textarea.value.trim();
      if (!text) return;
      stopSpeech();
      card.querySelector("h2").textContent = "\u9001\u4FE1\u4E2D\u2026";
      inputActions.innerHTML = "";
      const res = await sendRuntimeMessage({
        type: "SHAPEIT_SUBMIT_FEEDBACK",
        rawText: text,
        pageUrl: payload.pageUrl || location.href,
        pageTitle: payload.pageTitle || document.title,
        screenshotDataUrl: payload.screenshotDataUrl,
        captureMode: payload.captureMode,
        consoleSnippet: consoleBuffer.slice(-8).join("\n"),
        elementSelector: payload.elementSelector,
        elementTag: payload.elementTag
      });
      if (!res?.ok) {
        card.querySelector("h2").textContent = "\u9001\u4FE1\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F";
        card.querySelector(".sub").textContent = res?.error === "auth" ? "ShapeIt \u306B\u30ED\u30B0\u30A4\u30F3\u3057\u3066\u304F\u3060\u3055\u3044" : res?.error || "\u30A8\u30E9\u30FC";
        inputActions.innerHTML = `<button type="button" class="btn btn-secondary" id="closeBtn">\u9589\u3058\u308B</button>`;
        card.querySelector("#closeBtn").addEventListener("click", closeOverlay);
        return;
      }
      step = "success";
      card.innerHTML = `
      <div class="success">
        <div class="check">\u2713</div>
        <h2>\u9001\u4FE1\u3057\u307E\u3057\u305F</h2>
        <p class="sub">ShapeIt \u306B\u5C4A\u304D\u307E\u3057\u305F</p>
        <div class="row" style="justify-content:center">
          <button type="button" class="btn btn-primary" id="inboxBtn">\u53D7\u4FE1\u7BB1\u3092\u958B\u304F</button>
          <button type="button" class="btn btn-secondary" id="closeOk">\u9589\u3058\u308B</button>
        </div>
      </div>
    `;
      card.querySelector("#inboxBtn").addEventListener("click", () => {
        void sendRuntimeMessage({ type: "SHAPEIT_OPEN_INBOX" });
        closeOverlay();
      });
      card.querySelector("#closeOk").addEventListener("click", closeOverlay);
      setTimeout(closeOverlay, 1200);
    };
    micBtn.addEventListener("click", () => startSpeech(textarea, micBtn));
    nextBtn.addEventListener("click", () => void goConfirm());
    cancelBtn.addEventListener("click", closeOverlay);
    wrap.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        if (step === "confirm") return;
        closeOverlay();
      }
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        if (step === "input") void goConfirm();
        else if (step === "confirm") void doSend();
      }
    });
    textarea.focus();
    if (!payload.commentOnly) {
      globalThis.setTimeout(() => startSpeech(textarea, micBtn), 300);
    }
  }
  function closeOverlay() {
    stopSpeech();
    overlayRoot?.remove();
    overlayRoot = null;
  }
  if (extensionAlive()) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (!extensionAlive()) return false;
      if (msg?.type === "SHAPEIT_SHOW_INSTANT_OVERLAY") {
        showInstantOverlay(msg.payload);
        try {
          sendResponse({ ok: true });
        } catch {
        }
        return true;
      }
      if (msg?.type === "SHAPEIT_HIDE_OVERLAY") {
        closeOverlay();
        try {
          sendResponse({ ok: true });
        } catch {
        }
        return true;
      }
      return false;
    });
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", createFab);
    } else {
      createFab();
    }
  }
})();
