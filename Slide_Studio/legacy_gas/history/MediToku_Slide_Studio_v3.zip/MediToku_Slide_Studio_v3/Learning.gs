/**
 * MediToku Slide Studio v3 — first-party design profile and review workflow.
 * Does not call an AI endpoint and contains no third-party slide-generator code.
 * Profiles live in the signed-in user's UserProperties or explicitly selected Drive JSON.
 */
const MT3 = {
  PROFILE: 'MT_DESIGN_PROFILE_V3', BASELINES: 'MT_BASELINE_INDEX_V3',
  MAX_REFERENCES: 5, MAX_BASELINES: 20, PROFILE_VERSION: 1,
  PPTX_MIME: 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
};
function mt3SafeText_(x, max) { return String(x == null ? '' : x).slice(0, max || 500); }
function mt3Color_(color) {
  try { return color.asRgbColor().asHexString().toUpperCase(); } catch (e) { return ''; }
}
function mt3Counter_(arr) {
  const map = {};
  arr.filter(Boolean).forEach(v => map[v] = (map[v] || 0) + 1);
  return Object.keys(map).sort((a,b) => map[b] - map[a])[0] || '';
}
function mt3GetShapeText_(element) {
  try { return element.getPageElementType() === SlidesApp.PageElementType.SHAPE ? element.asShape().getText().asString() : ''; }
  catch (e) { return ''; }
}
function mt3Snapshot_(presentation) {
  const slides = presentation.getSlides().map(slide => {
    const elements = slide.getPageElements().map(element => {
      const item = {kind:String(element.getPageElementType()),x:Math.round(element.getLeft()),y:Math.round(element.getTop()),w:Math.round(element.getWidth()),h:Math.round(element.getHeight())};
      const txt = mt3GetShapeText_(element);
      if (txt) {
        item.text = mt3SafeText_(txt, 3000);
        try { const st = element.asShape().getText().getTextStyle(); item.font=st.getFontFamily()||''; item.size=st.getFontSize()||0; item.color=mt3Color_(st.getForegroundColor()); } catch(e) {}
      }
      return item;
    });
    return {id:slide.getObjectId(),elements:elements};
  });
  return {version:1,deckId:presentation.getId(),capturedAt:new Date().toISOString(),pageWidth:presentation.getPageWidth(),pageHeight:presentation.getPageHeight(),slides:slides};
}
function mt3ProfileFromSnapshots_(snapshots) {
  const fonts=[],colors=[],sizes=[],titles=[],bodyLengths=[];
  snapshots.forEach(snap => (snap.slides||[]).forEach(sl => {
    const texts=sl.elements.filter(x=>x.text && !/^\[\[LAYOUT:/.test(x.text) && !/^MediToku$/.test(x.text));
    texts.forEach(x=>{if(x.font)fonts.push(x.font);if(x.color)colors.push(x.color);if(x.size)sizes.push(x.size)});
    const ordered=texts.slice().sort((a,b)=>a.y-b.y || a.x-b.x);
    if(ordered.length)titles.push(ordered[0].text.trim().length);
    ordered.slice(1).forEach(x=>bodyLengths.push(x.text.trim().length));
  }));
  const median=a=>a.length?a.slice().sort((x,y)=>x-y)[Math.floor(a.length/2)]:0;
  return {version:MT3.PROFILE_VERSION,kind:'personal',name:'My Design DNA',font:mt3Counter_(fonts),textColor:mt3Counter_(colors),typicalFontSize:median(sizes),medianTitleLength:median(titles),medianBodyLength:median(bodyLengths),preferredTemplateId:'',rules:[],sourceDecks:snapshots.map(x=>x.deckId).slice(0,MT3.MAX_REFERENCES),updatedAt:new Date().toISOString()};
}
function getDesignProfile() {
  const v=PropertiesService.getUserProperties().getProperty(MT3.PROFILE);
  return v?JSON.parse(v):{version:1,kind:'personal',name:'My Design DNA',font:'',textColor:'',typicalFontSize:0,medianTitleLength:0,medianBodyLength:0,preferredTemplateId:'',rules:[],sourceDecks:[]};
}
function learnFromReferenceDecks(urls) {
  if(!Array.isArray(urls) || !urls.length || urls.length>MT3.MAX_REFERENCES)throw Error('参考スライドは1〜5件指定してください。');
  const ids=Array.from(new Set(urls.map(parseDriveId_)));
  if(ids.some(x=>!x))throw Error('Google SlidesのURLまたはIDを指定してください。');
  const snaps=ids.map(id=>mt3Snapshot_(SlidesApp.openById(id)));
  const prior=getDesignProfile(), p=mt3ProfileFromSnapshots_(snaps);
  p.rules=(prior.rules||[]).slice(0,15);p.preferredTemplateId=prior.preferredTemplateId||'';
  PropertiesService.getUserProperties().setProperty(MT3.PROFILE,JSON.stringify(p));
  return p;
}
function setProfileRule(rule) {
  const p=getDesignProfile(); const s=mt3SafeText_(rule,180).trim();if(!s)throw Error('ルールを入力してください。');
  if((p.rules||[]).length>=15)throw Error('ルールは最大15件です。');
  p.rules=(p.rules||[]).concat(s);p.updatedAt=new Date().toISOString();
  PropertiesService.getUserProperties().setProperty(MT3.PROFILE,JSON.stringify(p));return p;
}
function removeProfileRule(index) {
  const p=getDesignProfile(),i=Number(index);if(!Number.isInteger(i)||i<0||i>=p.rules.length)throw Error('ルールがありません。');
  p.rules.splice(i,1);p.updatedAt=new Date().toISOString();
  PropertiesService.getUserProperties().setProperty(MT3.PROFILE,JSON.stringify(p));return p;
}
function mt3BaselineIndex_() {
  const s=PropertiesService.getUserProperties().getProperty(MT3.BASELINES);
  return s?JSON.parse(s):{};
}
function mt3SaveBaseline_(presentation) {
  const snapshot=mt3Snapshot_(presentation);
  const folderId=getAppConfig().outputFolder;
  const filename='MediToku_baseline_'+presentation.getId()+'.json';
  const blob=Utilities.newBlob(JSON.stringify(snapshot),'application/json',filename);
  const file=folderId?DriveApp.getFolderById(folderId).createFile(blob):DriveApp.createFile(blob);
  const idx=mt3BaselineIndex_();idx[presentation.getId()]={fileId:file.getId(),capturedAt:snapshot.capturedAt};
  const keys=Object.keys(idx).sort((a,b)=>idx[b].capturedAt.localeCompare(idx[a].capturedAt));
  keys.slice(MT3.MAX_BASELINES).forEach(k=>delete idx[k]);
  PropertiesService.getUserProperties().setProperty(MT3.BASELINES,JSON.stringify(idx));
  return {fileId:file.getId()};
}
function previewEditedDeckLearning(presentationUrl) {
  const id=parseDriveId_(presentationUrl),idx=mt3BaselineIndex_();
  if(!id||!idx[id])throw Error('このユーザーのStudio生成資料が見つかりません。生成後のGoogle Slides URLを指定してください。');
  const baseline=JSON.parse(DriveApp.getFileById(idx[id].fileId).getBlob().getDataAsString('UTF-8'));
  const current=mt3Snapshot_(SlidesApp.openById(id));
  const firstTitle=sl=>(sl.elements.filter(x=>x.text && x.text.trim() && x.text.trim()!=='MediToku' && !/^\[\[LAYOUT:/.test(x.text)).sort((a,b)=>a.y-b.y || a.x-b.x)[0]||{}).text||'';
  const changes=[];
  baseline.slides.forEach((old,i)=>{
    const now=current.slides[i];if(!now){changes.push({slide:i+1,type:'removed',before:firstTitle(old),after:''});return;}
    const before=firstTitle(old),after=firstTitle(now);
    if(before!==after)changes.push({slide:i+1,type:'title',before:mt3SafeText_(before,160),after:mt3SafeText_(after,160)});
    const oldText=old.elements.map(x=>x.text||'').join('\n'),newText=now.elements.map(x=>x.text||'').join('\n');
    if(oldText!==newText && before===after)changes.push({slide:i+1,type:'body',before:'本文が変更されました',after:'本文の編集を検出'});
    const sig=es=>es.map(x=>[x.x,x.y,x.w,x.h,x.font||'',x.size||0,x.color||''].join(':')).join('|');
    if(sig(old.elements)!==sig(now.elements))changes.push({slide:i+1,type:'layout',before:'元の配置',after:'配置・書式の変更を検出'});
  });
  if(current.slides.length>baseline.slides.length)changes.push({slide:0,type:'added',before:'',after:(current.slides.length-baseline.slides.length)+'枚追加'});
  const candidate=mt3ProfileFromSnapshots_([current]);
  return {deckId:id,changes:changes.slice(0,100),candidate:candidate,notice:'変更内容はまだ学習されません。「反映する」を押すと、統計的なデザイン設定のみ更新されます。本文や機密情報をプロフィールに保存しません。'};
}
function approveEditedDeckLearning(presentationUrl) {
  const preview=previewEditedDeckLearning(presentationUrl),prev=getDesignProfile(),next=preview.candidate;
  next.rules=(prev.rules||[]).slice(0,15);next.preferredTemplateId=prev.preferredTemplateId||'';
  next.sourceDecks=Array.from(new Set((prev.sourceDecks||[]).concat(preview.deckId))).slice(-MT3.MAX_REFERENCES);
  PropertiesService.getUserProperties().setProperty(MT3.PROFILE,JSON.stringify(next));
  return {profile:next,changeCount:preview.changes.length};
}
function exportDesignProfile() {
  const p=getDesignProfile(),name='MediToku_Design_DNA.json';
  const f=DriveApp.createFile(Utilities.newBlob(JSON.stringify(p,null,2),'application/json',name));
  return {url:f.getUrl(),id:f.getId()};
}
function importDesignProfile(url) {
  const id=parseDriveId_(url);if(!id)throw Error('プロフィールJSONのDriveファイルURLを入力してください。');
  const file=DriveApp.getFileById(id);if(file.getSize()>100000)throw Error('プロフィールファイルが大きすぎます。');
  const p=JSON.parse(file.getBlob().getDataAsString('UTF-8'));
  if(!p||p.version!==1||typeof p.name!=='string'||!Array.isArray(p.rules))throw Error('プロフィール形式が不正です。');
  const clean={version:1,kind:'imported',name:mt3SafeText_(p.name,60),font:mt3SafeText_(p.font,60),textColor:/^#[0-9A-Fa-f]{6}$/.test(p.textColor||'')?p.textColor:'',typicalFontSize:Number(p.typicalFontSize)||0,medianTitleLength:Number(p.medianTitleLength)||0,medianBodyLength:Number(p.medianBodyLength)||0,preferredTemplateId:'',rules:p.rules.slice(0,15).map(x=>mt3SafeText_(x,180)),sourceDecks:[],updatedAt:new Date().toISOString()};
  PropertiesService.getUserProperties().setProperty(MT3.PROFILE,JSON.stringify(clean));return clean;
}
function exportPptx(presentationUrl) {
  const id=parseDriveId_(presentationUrl);if(!id)throw Error('Google Slides URLを入力してください。');
  const source=DriveApp.getFileById(id);
  if(source.getMimeType()!=='application/vnd.google-apps.presentation')throw Error('Google Slides形式のみ出力できます。');
  const endpoint='https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(id)+'/export?mimeType='+encodeURIComponent(MT3.PPTX_MIME);
  const response=UrlFetchApp.fetch(endpoint,{headers:{Authorization:'Bearer '+ScriptApp.getOAuthToken()},muteHttpExceptions:true});
  if(response.getResponseCode()!==200)throw Error('PowerPoint変換エラー HTTP '+response.getResponseCode()+' : '+response.getContentText().slice(0,250));
  const blob=response.getBlob().setName(source.getName().replace(/[\\/:*?"<>|]/g,'_')+'.pptx');
  const folder=getAppConfig().outputFolder;const f=folder?DriveApp.getFolderById(folder).createFile(blob):DriveApp.createFile(blob);
  return {id:f.getId(),name:f.getName(),url:f.getUrl(),size:f.getSize()};
}
