/** MediToku Slide Studio — independent implementation, no third-party slide-generator code. */
const MT = { PROP_TEMPLATE:'MT_TEMPLATE_ID', PROP_OUTPUT:'MT_OUTPUT_FOLDER', PROP_MEDIA:'MT_MEDIA_FOLDER', MAX_SLIDES:40, PROP_PRESETS:'MT_SLIDE_PRESETS_V2', MAX_IMAGE_BYTES:8*1024*1024 };

function doGet() { return HtmlService.createHtmlOutputFromFile('Index').setTitle('MediToku Slide Studio').addMetaTag('viewport','width=device-width, initial-scale=1'); }
function getAppConfig() {
 const p=PropertiesService.getUserProperties();
 return {templateId:p.getProperty(MT.PROP_TEMPLATE)||'', outputFolder:p.getProperty(MT.PROP_OUTPUT)||'', mediaFolder:p.getProperty(MT.PROP_MEDIA)||'', email:Session.getActiveUser().getEmail()||''};
}
function saveAppConfig(config) {
 const p=PropertiesService.getUserProperties();
 const t=parseDriveId_(config.templateId); if(!t) throw Error('テンプレートのURLまたはIDを入力してください。');
 const f=DriveApp.getFileById(t); if(f.getMimeType()!=='application/vnd.google-apps.presentation') throw Error('Google Slides形式のテンプレートを指定してください。');
 const o=config.outputFolder?parseDriveId_(config.outputFolder):'';
 const m=config.mediaFolder?parseDriveId_(config.mediaFolder):'';
 if(o) DriveApp.getFolderById(o).getName(); if(m) DriveApp.getFolderById(m).getName();
 p.setProperty(MT.PROP_TEMPLATE,t);p.setProperty(MT.PROP_OUTPUT,o);p.setProperty(MT.PROP_MEDIA,m);
 return getAppConfig();
}
/** Preferences are stored per signed-in user; no third-party AI endpoint is called. */
function getSlidePresets(){
 const raw=PropertiesService.getUserProperties().getProperty(MT.PROP_PRESETS);
 return raw?JSON.parse(raw):{};
}
function saveSlidePreset(name,options){
 name=String(name||'').trim().slice(0,60);
 if(!name)throw Error('プリセット名を入力してください。');
 const clean=validateOptions_(options);
 const all=getSlidePresets();
 if(Object.keys(all).length>=20&&!Object.prototype.hasOwnProperty.call(all,name))throw Error('プリセットは最大20件です。');
 all[name]=clean;
 PropertiesService.getUserProperties().setProperty(MT.PROP_PRESETS,JSON.stringify(all));
 return all;
}
function deleteSlidePreset(name){
 const all=getSlidePresets();delete all[String(name||'')];
 PropertiesService.getUserProperties().setProperty(MT.PROP_PRESETS,JSON.stringify(all));
 return all;
}
function validateOptions_(x){
 x=x||{};
 const n=Number(x.slideCount);
 if(!Number.isInteger(n)||n<1||n>MT.MAX_SLIDES)throw Error('枚数は1〜40の整数で指定してください。');
 const allowed=(v,list,field)=>{v=String(v||'');if(!list.includes(v))throw Error(field+'が不正です。');return v;};
 return {slideCount:n,
  purpose:allowed(x.purpose,['sales','report','product','internal','training','custom'],'用途'),
  audience:String(x.audience||'').slice(0,160),
  density:allowed(x.density,['minimal','standard','detailed'],'文章量'),
  tone:allowed(x.tone,['factual','formal','friendly'],'文体'),
  evidence:allowed(x.evidence,['strict','standard'],'根拠'),
  visuals:allowed(x.visuals,['source_only','source_preferred','text_only'],'画像方針'),
  includeCover:!!x.includeCover,includeClosing:!!x.includeClosing,
  mustInclude:String(x.mustInclude||'').slice(0,2000),
  mustExclude:String(x.mustExclude||'').slice(0,2000),
  extra:String(x.extra||'').slice(0,3000)};
}
function parseDriveId_(v){let s=String(v||'').trim();let match=s.match(/\/d\/([\w-]+)/)||s.match(/[?&]id=([\w-]+)/);return match?match[1]:(/^[\w-]{15,}$/.test(s)?s:'');}
function makeStarterTemplate(){
 const p=SlidesApp.create('MediToku Slide Studio テンプレート（原本）');
 const first=p.getSlides()[0];
 const specs=[
  ['cover','{{TITLE}}','{{SUBTITLE}}'],
  ['statement','{{TITLE}}','{{MESSAGE}}'],
  ['evidence','{{TITLE}}','{{BODY}}','{{IMAGE_1}}'],
  ['two_column','{{TITLE}}','{{LEFT}}','{{RIGHT}}'],
  ['closing','{{TITLE}}','{{MESSAGE}}']
 ];
 const w=p.getPageWidth(),h=p.getPageHeight();
 specs.forEach((s,i)=>{
  const slide=p.appendSlide(SlidesApp.PredefinedLayout.BLANK);
  slide.getBackground().setSolidFill('#FFFFFF');
  const tag=slide.insertTextBox('[[LAYOUT:'+s[0]+']]',8,8,125,13);tag.getText().getTextStyle().setFontSize(5).setForegroundColor('#999999');
  const bar=slide.insertShape(SlidesApp.ShapeType.RECTANGLE,0,h-6,w,6);bar.getFill().setSolidFill('#176B86');bar.getBorder().setTransparent();
  const brand=slide.insertTextBox('MediToku',w-110,18,100,20);brand.getText().getTextStyle().setFontFamily('Arial').setFontSize(13).setBold(true).setForegroundColor('#176B86');
  const title=slide.insertTextBox(s[1],36,i===0?150:50,w-72,80);title.getText().getTextStyle().setFontFamily('Noto Sans JP').setFontSize(i===0?32:25).setBold(true).setForegroundColor('#183449');
  if(s[0]==='evidence'){
   addBox_(slide,s[2],36,145,w*.37,240,15);addBox_(slide,s[3],w*.44,145,w*.49,240,12);
  } else if(s[0]==='two_column'){
   addBox_(slide,s[2],36,145,w*.42,245,17);addBox_(slide,s[3],w*.52,145,w*.42,245,17);
  } else {addBox_(slide,s[2],36,i===0?258:155,w-72,195,i===0?18:21);}
  if(i!==0){const foot=slide.insertTextBox('{{SOURCE}}',36,h-30,w-72,17);foot.getText().getTextStyle().setFontSize(9).setForegroundColor('#64748B');}
 });
 first.remove();
 PropertiesService.getUserProperties().setProperty(MT.PROP_TEMPLATE,p.getId());
 return {url:p.getUrl(),id:p.getId()};
}
function addBox_(slide,text,x,y,w,h,font){const sh=slide.insertTextBox(text,x,y,w,h);sh.getText().getTextStyle().setFontFamily('Noto Sans JP').setFontSize(font).setForegroundColor('#243B53');return sh;}
function validateDeck_(deck){
 if(!deck||typeof deck!=='object'||Array.isArray(deck)) throw Error('JSONオブジェクトを入力してください。');
 if(!Array.isArray(deck.slides)||!deck.slides.length||deck.slides.length>MT.MAX_SLIDES) throw Error('slidesは1〜40枚の配列にしてください。');
 const allowed=['cover','statement','evidence','two_column','closing'];
 deck.slides.forEach((s,i)=>{if(!s||!allowed.includes(s.layout))throw Error((i+1)+'枚目: 不明なlayout');if(!String(s.title||'').trim())throw Error((i+1)+'枚目: titleが空です');});
 return deck;
}
function createDeck(payload){
 const deck=validateDeck_(payload.deck);if(payload.options){const opt=validateOptions_(payload.options);if(deck.slides.length!==opt.slideCount)throw Error('指定枚数とJSONの枚数が一致しません。');if(opt.includeCover&&deck.slides[0].layout!=='cover')throw Error('表紙を含む設定です。1枚目をcoverにしてください。');if(opt.includeClosing&&deck.slides[deck.slides.length-1].layout!=='closing')throw Error('締めを含む設定です。最終ページをclosingにしてください。');}const cfg=getAppConfig();if(!cfg.templateId)throw Error('先にテンプレートを設定してください。');
 const src=DriveApp.getFileById(cfg.templateId);let copy;
 const title=String(deck.title||'資料').slice(0,100)+' - '+Utilities.formatDate(new Date(),Session.getScriptTimeZone(),'yyyyMMdd-HHmm');
 copy=cfg.outputFolder?src.makeCopy(title,DriveApp.getFolderById(cfg.outputFolder)):src.makeCopy(title);
 try{
  const p=SlidesApp.openById(copy.getId());const seeds={};p.getSlides().forEach(sl=>{const txt=sl.getPageElements().filter(e=>e.getPageElementType()===SlidesApp.PageElementType.SHAPE).map(e=>e.asShape().getText().asString()).join('\n');const m=txt.match(/\[\[LAYOUT:([a-z_]+)\]\]/);if(m)seeds[m[1]]=sl;});
  deck.slides.forEach((item,i)=>{
   if(!seeds[item.layout]) throw Error('テンプレート内に [[LAYOUT:'+item.layout+']] がありません。');
   const sl=seeds[item.layout].duplicate();sl.move(i);removeLayoutMarker_(sl);
   const values={TITLE:item.title,SUBTITLE:item.subtitle||'',MESSAGE:item.message||'',BODY:item.body||'',LEFT:item.left||'',RIGHT:item.right||'',SOURCE:formatSource_(item)};
   Object.keys(values).forEach(k=>sl.replaceAllText('{{'+k+'}}',String(values[k]).slice(0,2400)));
   insertImages_(sl,item.images||{});
   clearResidualTags_(sl);
   if(item.source) try{sl.getNotesPage().getSpeakerNotesShape().getText().setText('出典: '+formatSource_(item));}catch(e){}
  });
  Object.keys(seeds).forEach(k=>seeds[k].remove());p.saveAndClose();
  const baseline=mt3SaveBaseline_(SlidesApp.openById(copy.getId()));
  return {id:copy.getId(),url:'https://docs.google.com/presentation/d/'+copy.getId()+'/edit',count:deck.slides.length,baselineFileId:baseline.fileId};
 }catch(e){copy.setTrashed(true);throw e;}
}
function removeLayoutMarker_(slide){slide.getPageElements().forEach(e=>{if(e.getPageElementType()===SlidesApp.PageElementType.SHAPE&&/^\[\[LAYOUT:/.test(e.asShape().getText().asString().trim()))e.remove();});}
function formatSource_(s){const src=s.source||{};return [src.file||'',src.page?'p.'+src.page:'',src.note||''].filter(Boolean).join(' / ').slice(0,260);}
function insertImages_(slide,images){
 Object.keys(images).forEach(key=>{
  if(!/^IMAGE_[1-3]$/.test(key))return;
  const id=parseDriveId_(images[key]);if(!id)throw Error(key+' のDrive画像IDが不正です。');
  const f=DriveApp.getFileById(id);if(!/^image\/(png|jpeg|gif)$/.test(f.getMimeType()))throw Error('画像はPNG/JPEG/GIFを指定してください。');
  const boxes=slide.getPageElements().filter(e=>e.getPageElementType()===SlidesApp.PageElementType.SHAPE&&e.asShape().getText().asString().includes('{{'+key+'}}'));
  boxes.forEach(box=>{const rect={left:box.getLeft(),top:box.getTop(),width:box.getWidth(),height:box.getHeight()};box.remove();slide.insertImage(f.getBlob(),rect.left,rect.top,rect.width,rect.height);});
 });
}
function clearResidualTags_(slide){slide.getPageElements().forEach(e=>{if(e.getPageElementType()===SlidesApp.PageElementType.SHAPE){const t=e.asShape().getText();if(t.asString().match(/\{\{[A-Z_0-9]+\}\}/g))t.setText(t.asString().replace(/\{\{[A-Z_0-9]+\}\}/g,''));}});}
function uploadCrop(dataUrl,name){
 const m=String(dataUrl||'').match(/^data:image\/(png|jpeg);base64,([A-Za-z0-9+/=]+)$/);if(!m)throw Error('PNG/JPEG画像のみアップロード可能です。');
 const bytes=Utilities.base64Decode(m[2]);if(bytes.length>MT.MAX_IMAGE_BYTES)throw Error('画像サイズは8MB以下にしてください。');
 const blob=Utilities.newBlob(bytes,'image/'+m[1],String(name||'crop').replace(/[^\w.\-ぁ-んァ-ヶ一-龥]/g,'_').slice(0,80)+'.'+(m[1]==='jpeg'?'jpg':'png'));
 const cfg=getAppConfig();const f=cfg.mediaFolder?DriveApp.getFolderById(cfg.mediaFolder).createFile(blob):DriveApp.createFile(blob);
 return {id:f.getId(),name:f.getName(),url:f.getUrl()};
}
