# MediToku Slide Studio — 独立実装版 MVP

## 目的
既存の第三者スライド生成コードをコピーせず、Google公式のApps Script / Drive / Slidesの機能と、ユーザーがGemini/NotebookLMで生成した構成JSONを組み合わせる。追加の有料Gemini APIは不要。

## セットアップ
1. script.google.com で新規スタンドアロン Apps Scriptを作成。`Code.gs` とHTMLファイル `Index` を作り、各ファイル内容を貼り付ける。
2. Apps Scriptのプロジェクト設定でタイムゾーン `Asia/Tokyo` を指定。
3. `makeStarterTemplate` を一度実行して認可。返却されたURLを開き、サンプルの色・ロゴ・文字位置を会社仕様に変更。`[[LAYOUT:...]]` と `{{...}}` のタグは残す。
4. デプロイ > 新しいデプロイ > ウェブアプリ。実行ユーザーは「自分」または社内運用ポリシーに応じ「アクセスしているユーザー」。アクセス範囲は社内に限定する。共有環境では、ドライブの権限と実行ユーザー設定を確認する。
5. Webアプリの初期設定でテンプレートURLと、任意で出力先・画像保存フォルダを指定。
6. PDF投入→プロンプトをコピー→Google AI ProまたはWorkspaceのGemini/NotebookLMで構成JSON生成→貼り付け→PDF図表をドラッグ切り抜き→画像IDを該当スライドの `images.IMAGE_1` に入力→Google Slidesを作成。

## JSON例
```json
{"title":"営業提案書","slides":[{"layout":"cover","title":"外来DXのご提案","subtitle":"2026年9月"},{"layout":"evidence","title":"現状の課題","body":"窓口の業務負荷が集中する。","source":{"file":"調査資料.pdf","page":4,"note":"図1"},"images":{"IMAGE_1":"DRIVE_IMAGE_FILE_ID"}},{"layout":"closing","title":"次の進め方","message":"導入範囲を決定する。"}]}
```

## テンプレート仕様
テンプレート原本は、`[[LAYOUT:cover]]` `[[LAYOUT:statement]]` `[[LAYOUT:evidence]]` `[[LAYOUT:two_column]]` `[[LAYOUT:closing]]` をそれぞれ1枚ずつ含む。本文プレースホルダは `{{TITLE}}`, `{{SUBTITLE}}`, `{{MESSAGE}}`, `{{BODY}}`, `{{LEFT}}`, `{{RIGHT}}`, `{{SOURCE}}`, `{{IMAGE_1}}`。複製したテンプレートから使用ページをコピーして差し替える。通常のテキストと図形はSlides上で編集可能、元資料の切り抜きは画像として編集可能（画像内文字は画像のまま）。

## 現時点の制約・次期実装
- Geminiアプリ/NotebookLMのUIをGASから無断操作することはせず、分析JSONを手動で貼り付ける。Google AI ProとWorkspaceのサブスクリプションをAPI認証に転用しない。
- PDFのテキスト抽出はブラウザ内で最大50ページ/ファイル、各ファイル最大14万字。画像だけのPDFはOCRしていない。PDFはブラウザ内に保持し、明示的に選んだ切り抜きだけDriveへアップロードする。
- 複数のPDFや巨大画像では、Apps Scriptの実行/転送上限に注意。切り抜き画像は8MB以下。
- 表・グラフをGoogle Slidesネイティブ図表へ変換する機能、画像中の文字の編集、AIによる切り抜き座標の全自動特定、JSON自動受信、視覚QA、ページ溢れの自動修正、承認フローは未実装。
- 原稿の誤りや出典確認は最終的に人間が行う。機密資料を個人AIアカウントへ送る前に組織の情報管理ルールを確認する。
- フォントは閲覧環境で代替表示される可能性あり。

## 権利
この実装は新規に書き起こしたコードであり、添付された第三者コード・デザイン・素材は含めない。自社独自のロゴやテンプレート素材は権利処理済みのものを利用する。最終的な契約判断は原契約書・ライセンスと必要に応じて専門家の確認による。


## v2: 作成条件とプリセット
- 1〜40枚の指定枚数（表紙・締め込み）をプロンプトとサーバーの両方で検査。枚数違いは生成せず修正を促す。
- 用途、対象読者、文章密度、文体、数値の出典方針、画像方針、必須/除外事項、追加条件を指定。
- 個人ごとに最大20件の条件プリセットをUserPropertiesへ保存。AIサービス契約やAPIキーは不要。
- Workspace Studio連携は設計済みの拡張候補であり、このZIPにはカスタムステップの配備やGemの自動呼出しは含まない。管理者許可と利用可否の確認が必要。
- 「Gemini Spark」はサービス名称が曖昧なため、Gem（カスタムAI）とGoogle AI Studio Buildを区別して運用する。
